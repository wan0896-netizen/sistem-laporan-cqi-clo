-- ============================================================================
-- 0001_init.sql — Sistem Laporan CQI Pencapaian CLO (JKM POLISAS)
-- PostgreSQL DDL mirroring prisma/schema.prisma (PRD v3.0 Section 13.3).
--
-- Apply with EITHER:
--   (a) Supabase Dashboard -> SQL Editor -> paste & Run, or
--   (b) supabase db push after `supabase link --project-ref pqvdalbvqkkvbjsddisr`
--
-- Recommended alternative: swap Prisma datasource to postgresql
-- (prisma/schema.postgres.prisma) and run `prisma db push` — Prisma then owns
-- the DDL. Both paths produce the same structure.
--
-- Conventions (identical to Prisma postgres output):
--   * IDs are TEXT PRIMARY KEY (cuid/uuid generated app-side); a uuid default
--     is added so ad-hoc SQL inserts also work.
--   * JSON payloads (settingsUsed, results, causeTags, sectionAIssues,
--     layout, fieldRules, verificationChain, before/after) are TEXT — the app
--     lib layer serialises/parses them, matching the SQLite build.
--   * Required FK -> ON DELETE RESTRICT ON UPDATE CASCADE
--     Optional FK -> ON DELETE SET NULL  ON UPDATE CASCADE
--     onDelete: Cascade -> ON DELETE CASCADE
-- ============================================================================

create extension if not exists "pgcrypto";

-- ---------- Identity & access (FR-AUTH-01/02) ----------

create table if not exists "Profile" (
  "id" text primary key default gen_random_uuid()::text,
  "email" text not null unique,
  "passwordHash" text not null,
  "fullName" text not null,
  "staffId" text,
  "department" text not null default 'Jabatan Kejuruteraan Mekanikal',
  "active" boolean not null default true,
  "createdAt" timestamp(3) not null default current_timestamp,
  "updatedAt" timestamp(3) not null default current_timestamp
);

create table if not exists "UserRole" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "Profile"("id") on delete cascade on update cascade,
  "role" text not null,
  "programmeId" text references "Programme"("id") on delete set null on update cascade,
  "updatedAt" timestamp(3) not null default current_timestamp,
  "createdAt" timestamp(3) not null default current_timestamp,
  constraint "UserRole_userId_role_programmeId_key" unique ("userId", "role", "programmeId")
);
create index if not exists "UserRole_userId_idx" on "UserRole"("userId");

-- ---------- Master data (FR-MD-01..05) ----------

create table if not exists "Programme" (
  "id" text primary key default gen_random_uuid()::text,
  "code" text not null unique,
  "name" text not null,
  "level" text not null default 'Diploma',
  "verificationChain" text not null default '["KK","KPRO","KJ"]'
);

create table if not exists "Plo" (
  "id" text primary key default gen_random_uuid()::text,
  "programmeId" text not null references "Programme"("id") on delete cascade on update cascade,
  "code" text not null,
  "statement" text not null,
  constraint "Plo_programmeId_code_key" unique ("programmeId", "code")
);

create table if not exists "Course" (
  "id" text primary key default gen_random_uuid()::text,
  "code" text not null unique,
  "name" text not null,
  "credit" integer not null default 3
);

create table if not exists "CourseProgramme" (
  "courseId" text not null references "Course"("id") on delete cascade on update cascade,
  "programmeId" text not null references "Programme"("id") on delete cascade on update cascade,
  constraint "CourseProgramme_pkey" primary key ("courseId", "programmeId")
);

create table if not exists "Clo" (
  "id" text primary key default gen_random_uuid()::text,
  "courseId" text not null references "Course"("id") on delete cascade on update cascade,
  "code" text not null,
  "statement" text not null,
  "domain" text not null default 'Cognitive',
  "version" integer not null default 1,
  constraint "Clo_courseId_code_key" unique ("courseId", "code")
);

create table if not exists "CloPloMap" (
  "cloId" text not null references "Clo"("id") on delete cascade on update cascade,
  "ploId" text not null references "Plo"("id") on delete cascade on update cascade,
  constraint "CloPloMap_pkey" primary key ("cloId", "ploId")
);

-- Sesi I/II YYYY/YYYY with chronological ordering
create table if not exists "Session" (
  "id" text primary key default gen_random_uuid()::text,
  "label" text not null unique,
  "year" text not null,
  "term" integer not null,
  "seqNo" integer not null unique,
  "startDate" timestamp(3),
  "endDate" timestamp(3),
  "deadline" timestamp(3),
  "status" text not null default 'OPEN'
);
create index if not exists "Session_seqNo_idx" on "Session"("seqNo");

create table if not exists "Offering" (
  "id" text primary key default gen_random_uuid()::text,
  "courseId" text not null references "Course"("id") on delete restrict on update cascade,
  "sessionId" text not null references "Session"("id") on delete restrict on update cascade,
  "programmeId" text not null references "Programme"("id") on delete restrict on update cascade,
  "coordinatorId" text references "Profile"("id") on delete set null on update cascade,
  "status" text not null default 'ACTIVE',
  "createdAt" timestamp(3) not null default current_timestamp,
  constraint "Offering_courseId_sessionId_programmeId_key" unique ("courseId", "sessionId", "programmeId")
);
create index if not exists "Offering_programmeId_sessionId_idx" on "Offering"("programmeId", "sessionId");

create table if not exists "Section" (
  "id" text primary key default gen_random_uuid()::text,
  "offeringId" text not null references "Offering"("id") on delete cascade on update cascade,
  "code" text not null,
  "lecturerId" text references "Profile"("id") on delete set null on update cascade,
  "studentCount" integer not null default 0,
  constraint "Section_offeringId_code_key" unique ("offeringId", "code")
);
create index if not exists "Section_offeringId_idx" on "Section"("offeringId");

-- ---------- Assessment & marks (FR-AS-*, FR-MK-*) ----------

create table if not exists "Assessment" (
  "id" text primary key default gen_random_uuid()::text,
  "offeringId" text not null references "Offering"("id") on delete cascade on update cascade,
  "name" text not null,
  "type" text not null default 'Coursework',
  "weight" integer not null default 0
);
create index if not exists "Assessment_offeringId_idx" on "Assessment"("offeringId");

create table if not exists "AssessmentItem" (
  "id" text primary key default gen_random_uuid()::text,
  "assessmentId" text not null references "Assessment"("id") on delete cascade on update cascade,
  "label" text not null,
  "maxMarks" double precision not null default 100,
  "cloId" text references "Clo"("id") on delete set null on update cascade
);
create index if not exists "AssessmentItem_assessmentId_idx" on "AssessmentItem"("assessmentId");

create table if not exists "Mark" (
  "id" text primary key default gen_random_uuid()::text,
  "offeringId" text not null references "Offering"("id") on delete cascade on update cascade,
  "sectionId" text not null references "Section"("id") on delete cascade on update cascade,
  "matric" text not null,
  "itemId" text not null references "AssessmentItem"("id") on delete cascade on update cascade,
  "score" double precision,
  "status" text,
  "updatedAt" timestamp(3) not null default current_timestamp,
  constraint "Mark_sectionId_matric_itemId_key" unique ("sectionId", "matric", "itemId")
);
create index if not exists "Mark_sectionId_idx" on "Mark"("sectionId");
create index if not exists "Mark_offeringId_idx" on "Mark"("offeringId");

create table if not exists "CloResult" (
  "id" text primary key default gen_random_uuid()::text,
  "offeringId" text not null references "Offering"("id") on delete cascade on update cascade,
  "sectionId" text references "Section"("id") on delete set null on update cascade,
  "matric" text not null,
  "cloId" text not null references "Clo"("id") on delete cascade on update cascade,
  "percent" double precision not null,
  constraint "CloResult_sectionId_matric_cloId_key" unique ("sectionId", "matric", "cloId")
);
create index if not exists "CloResult_offeringId_idx" on "CloResult"("offeringId");

-- ---------- Attainment & reports ----------

create table if not exists "AttainmentSnapshot" (
  "id" text primary key default gen_random_uuid()::text,
  "offeringId" text not null references "Offering"("id") on delete cascade on update cascade,
  "reportId" text references "CqiReport"("id") on delete set null on update cascade,
  "computedAt" timestamp(3) not null default current_timestamp,
  "computedBy" text,
  "settingsUsed" text not null,
  "results" text not null
);
create index if not exists "AttainmentSnapshot_offeringId_idx" on "AttainmentSnapshot"("offeringId");

create table if not exists "CqiReport" (
  "id" text primary key default gen_random_uuid()::text,
  "offeringId" text not null references "Offering"("id") on delete restrict on update cascade,
  "templateVersion" text not null default '3.2',
  "status" text not null default 'DRAFT',
  "version" integer not null default 1,
  "overallType" text,
  "submittedById" text references "Profile"("id") on delete set null on update cascade,
  "submittedAt" timestamp(3),
  "amendedFromId" text,
  "sectionAIssues" text not null default '[]',
  "comparisonNote" text,
  "createdAt" timestamp(3) not null default current_timestamp,
  "updatedAt" timestamp(3) not null default current_timestamp,
  constraint "CqiReport_offeringId_version_key" unique ("offeringId", "version")
);
create index if not exists "CqiReport_status_idx" on "CqiReport"("status");

create table if not exists "CqiRow" (
  "id" text primary key default gen_random_uuid()::text,
  "reportId" text not null references "CqiReport"("id") on delete cascade on update cascade,
  "cloId" text references "Clo"("id") on delete set null on update cascade,
  "cqiType" text not null,
  "suggestedType" text,
  "overrideReason" text,
  "causeTags" text not null default '[]',
  "causeText" text,
  "proposal" text not null default '',
  "outcome" text,
  "ownerId" text references "Profile"("id") on delete set null on update cascade,
  "targetDate" timestamp(3),
  "sortOrder" integer not null default 0
);
create index if not exists "CqiRow_reportId_idx" on "CqiRow"("reportId");

create table if not exists "CqiAction" (
  "id" text primary key default gen_random_uuid()::text,
  "originReportId" text not null references "CqiReport"("id") on delete cascade on update cascade,
  "cloId" text references "Clo"("id") on delete set null on update cascade,
  "description" text not null,
  "ownerId" text references "Profile"("id") on delete set null on update cascade,
  "targetDate" timestamp(3),
  "status" text not null default 'PLANNED',
  "implementedDate" timestamp(3),
  "impact" text,
  "impactText" text,
  "verifiedInReportId" text references "CqiReport"("id") on delete set null on update cascade,
  "unplanned" boolean not null default false,
  "createdAt" timestamp(3) not null default current_timestamp,
  "updatedAt" timestamp(3) not null default current_timestamp
);
create index if not exists "CqiAction_originReportId_idx" on "CqiAction"("originReportId");
create index if not exists "CqiAction_status_idx" on "CqiAction"("status");

create table if not exists "EvidenceFile" (
  "id" text primary key default gen_random_uuid()::text,
  "actionId" text references "CqiAction"("id") on delete cascade on update cascade,
  "feedbackId" text references "CurriculumFeedback"("id") on delete set null on update cascade,
  "storagePath" text not null,
  "fileName" text not null,
  "mime" text not null,
  "size" integer not null,
  "uploadedById" text references "Profile"("id") on delete set null on update cascade,
  "createdAt" timestamp(3) not null default current_timestamp
);
create index if not exists "EvidenceFile_actionId_idx" on "EvidenceFile"("actionId");

create table if not exists "CurriculumFeedback" (
  "id" text primary key default gen_random_uuid()::text,
  "reportId" text references "CqiReport"("id") on delete set null on update cascade,
  "courseId" text not null references "Course"("id") on delete restrict on update cascade,
  "sessionId" text references "Session"("id") on delete set null on update cascade,
  "topic" text not null,
  "text" text not null,
  "status" text not null default 'NEW',
  "createdAt" timestamp(3) not null default current_timestamp
);
create index if not exists "CurriculumFeedback_topic_idx" on "CurriculumFeedback"("topic");
create index if not exists "CurriculumFeedback_courseId_idx" on "CurriculumFeedback"("courseId");

create table if not exists "Verification" (
  "id" text primary key default gen_random_uuid()::text,
  "reportId" text not null references "CqiReport"("id") on delete cascade on update cascade,
  "role" text not null,
  "userId" text not null references "Profile"("id") on delete restrict on update cascade,
  "decision" text not null,
  "comment" text,
  "signedAt" timestamp(3) not null default current_timestamp
);
create index if not exists "Verification_reportId_idx" on "Verification"("reportId");

create table if not exists "FormTemplate" (
  "id" text primary key default gen_random_uuid()::text,
  "versionLabel" text not null unique,
  "effectiveDate" timestamp(3) not null,
  "updatedDate" timestamp(3) not null,
  "layout" text not null,
  "fieldRules" text not null,
  "active" boolean not null default true
);

create table if not exists "Lookup" (
  "id" text primary key default gen_random_uuid()::text,
  "type" text not null,
  "code" text not null,
  "labelBm" text not null,
  "labelEn" text not null,
  "sortOrder" integer not null default 0,
  "active" boolean not null default true,
  constraint "Lookup_type_code_key" unique ("type", "code")
);
create index if not exists "Lookup_type_idx" on "Lookup"("type");

create table if not exists "Setting" (
  "key" text primary key,
  "value" text not null,
  "updatedAt" timestamp(3) not null default current_timestamp
);

create table if not exists "Notification" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "Profile"("id") on delete cascade on update cascade,
  "type" text not null,
  "refId" text,
  "messageBm" text not null,
  "messageEn" text not null,
  "link" text,
  "read" boolean not null default false,
  "createdAt" timestamp(3) not null default current_timestamp
);
create index if not exists "Notification_userId_read_idx" on "Notification"("userId", "read");

create table if not exists "AuditLog" (
  "id" text primary key default gen_random_uuid()::text,
  "actorId" text references "Profile"("id") on delete set null on update cascade,
  "action" text not null,
  "tableName" text not null,
  "rowId" text,
  "before" text,
  "after" text,
  "at" timestamp(3) not null default current_timestamp
);
create index if not exists "AuditLog_tableName_rowId_idx" on "AuditLog"("tableName", "rowId");
create index if not exists "AuditLog_at_idx" on "AuditLog"("at");

-- ============================================================================
-- Storage (FR-PCQI-05): private bucket for evidence files.
-- Run in the SQL editor as the service role (owner privileges required).
-- ============================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'evidence', 'evidence', false,
  5242880,  -- 5MB cap, matching the API validation
  array['application/pdf', 'image/jpeg', 'image/png',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
)
on conflict (id) do nothing;

-- The app authorises every Storage read/write through its own API routes
-- (lib/api-auth + permission matrix), connecting as the postgres user, which
-- bypasses RLS. No anon storage policies are intentionally created: with only
-- the publishable key, all bucket access is denied (private by design).
