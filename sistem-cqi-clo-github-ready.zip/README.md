# Sistem Laporan CQI Pencapaian CLO — JKM POLISAS

Sistem web untuk pengurusan **Laporan CQI Pencapaian CLO** (Continuous Quality
Improvement — Course Learning Outcome Attainment) bagi **Jabatan Kejuruteraan
Mekanikal, Politeknik Sultan Haji Ahmad Shah**. Dibina mengikut **PRD v3.0**
dan selaras dengan **Borang Laporan CQI Kursus Ver. 3.2** (kuat kuasa Jan 2026,
dikemas kini Jun 2026).

Stack PRD v3.0: **Next.js 16 (App Router) · TypeScript · Prisma ·
Supabase PostgreSQL · Tailwind CSS · Z.ai (GLM)** — sasaran pelancaran
**Vercel + Supabase**.

## Modul utama

| Modul | Ringkasan |
| --- | --- |
| Autentikasi & peranan | 6 peranan (Penyelaras Kursus, Ketua Kursus, Ketua Program, Ketua Jabatan, Unit Kualiti, Pentadbir) dengan matriks kebenaran di pelayan dan sesi bertandatangan HMAC |
| Markah & pencapaian CLO | Kemasukan markah berperingkat, pengiraan pencapaian CLO automatik (kaedah `THRESHOLD`/`AVERAGE` boleh dikonfigur), peraturan ambang 55% dan penurunan ≥ 5 mata dengan perbandingan 3 sesi |
| Laporan CQI Ver. 3.2 | Borang penuh Seksyen A/B, cadangan pembaikan/pencegahan, enam faktor punca, draf AI (GLM) atas data tanpa nama, togol BM/EN |
| Aliran kerja semakan | Rantai pengesahan boleh konfigur mengikut program (KK → KPro), ulasan, baca-sahaja selepas pengesahan, pembetulan sebagai versi baharu, peringatan tarikh akhir T-7/T-3/T-1 dengan eskalasi |
| Bukti (FR-PCQI-05) | Muat naik PDF/JPG/PNG/DOCX (had 5MB) ke bucket peribadi Supabase Storage |
| Dashboard & eksport | PDF Ver. 3.2 (carta + bar kaki versi), Excel, papan pemuka pensyarah/program/jabatan, eksport konsolidated |
| Pentadbiran | Tetapan sistem (ambang, kaedah, rantai pengesahan), audit log tidak berubah, tab status Supabase |

## Mulakan dengan cepat

Prasyarat: **Node.js 20+** (npm), atau Bun; akses kepada projek Supabase.

```bash
git clone https://github.com/<ORG>/<REPO>.git
cd <REPO>
npm install                 # atau: bun install
cp .env.example .env        # isi kata lalau DB & kunci (lihat jadual di bawah)
npm run db:generate         # janakan Prisma Client
npm run db:push             # 27 jadual → Supabase PostgreSQL
npx tsx scripts/seed.ts     # data rujukan + demo (padam & isi semula; idempotent)
npm run dev                 # http://localhost:3000
```

Ujian & lint:

```bash
npx vitest run      # enjin pengiraan pencapaian CLO (PRD Seksyen 16)
npm run lint
```

## Akaun demo (kata laluan semua: `Polisas#2026`)

| Peranan | E-mel |
| --- | --- |
| Penyelaras Kursus | penyelaras.dja@polisas.edu.my |
| Ketua Kursus (KK) | kk.dja@polisas.edu.my |
| Ketua Program (KPro, DAD) | kpro.dad@polisas.edu.my |
| Ketua Jabatan (KJ) | kj.jkm@polisas.edu.my |
| Unit Kualiti | quality@polisas.edu.my |
| Pentadbir Sistem | admin@polisas.edu.my |

Data demo: DJA30132 (DAD) — Sesi I 2025/2026 = 74 pelajar, laporan
**VERIFIED** dengan tindakan CQI; Sesi II 2025/2026 = 12 pelajar, markah
lengkap dan laporan **SUBMITTED** (menunggu KPro). CLO 2 = 41.7% (< 55% →
*Corrective*), CLO 3 = 72.7% dengan penurunan −8.1 mata (≥ 5 → *Preventive*).

## Pembolehubah persekitaran

| Pembolehubah | Awam/RAHSIA | Kegunaan |
| --- | --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Awam | URL projek Supabase (pelayar) |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Awam | Kunci publishable (`sb_publishable_...`) |
| `SUPABASE_PROJECT_REF` | Awam | Ref projek (log/_status_) |
| `SUPABASE_DATABASE_URL` | **RAHSIA** | Sambungan Prisma — session pooler 5432 (migrasi + pelayan panjang) |
| `DATABASE_URL` | **RAHSIA** | Nilai sama, untuk alat generik |
| `SUPABASE_SECRET_KEY` | **RAHSIA** | Kunci `sb_secret_...` untuk Storage (pilihan; tanpanya bukti ke store cakera tempatan) |
| `SUPABASE_DB_URL` / `SUPABASE_POOLER_URL` | **RAHSIA** | Rujukan: endpoint terus (IPv6) / transaction pooler 6543 untuk runtime Vercel |

Contoh lengkap: [.env.example](.env.example). **Jangan commit `.env` sebenar.**

## Pangkalan data

- **Aktif:** Supabase PostgreSQL melalui *session pooler* (port 5432) — migrasi
  Prisma dan pelayan berumur panjang.
- **Vercel runtime:** *transaction pooler* (port 6543, `pgbouncer=true`) —
  set sebagai `SUPABASE_DATABASE_URL` pada Vercel; jangan jalankan migrasi padanya.
- **DDL rujukan:** [`supabase/migrations/0001_init.sql`](supabase/migrations/0001_init.sql)
  (27 jadual + bucket `evidence`).
- **Rollback SQLite tempatan:** `prisma/schema.sqlite.bak.prisma`
  (lihat [docs/supabase.md](docs/supabase.md) §3).

## Struktur projek

```
src/
  app/            # App Router — halaman + route handlers API
    (app)/        # halaman berperanan (dashboard, markah, laporan, admin ...)
    api/          # REST: auth, markah, laporan, workflow, bukti, cron, system
  lib/            # prisma, supabase, api-auth (matriks kebenaran), pengiraan CLO, AI provider
  components/     # komponen UI
prisma/           # schema.prisma (PostgreSQL aktif) + varian SQLite
supabase/         # migrations/0001_init.sql + config.toml
scripts/          # seed.ts, verify-seed.ts, find-pooler-region.ts
tests/            # vitest — enjin pengiraan (PRD Seksyen 16)
docs/             # dokumentasi lanjut + contoh output
```

## Dokumentasi lanjut

- [docs/sistem.md](docs/sistem.md) — seni bina, penyesuaian PRD, penjejakan
  FR/NFR (Fasa 1 P0 lengkap), nota penukaran production.
- [docs/supabase.md](docs/supabase.md) — sambungan DB & pooler region,
  pengaktifan Storage, CLI, senarai semak penghantaran Vercel.
- [docs/contoh/](docs/contoh) — contoh output: PDF Laporan CQI Ver. 3.2 dan
  Excel konsolidated.

## Peta jalan ke pengeluaran (PRD v3.0)

1. Kunci `sb_secret_...` → Storage bukti aktif (badge Storan hijau).
2. RLS pada jadual `public` — cermin matriks kebenaran `src/lib/permissions.ts`.
3. Supabase Auth menggantikan sesi HMAC (matriks kebenaran kekal).
4. Cron peringatan (T-7/T-3/T-1) dijadualkan pada Vercel dengan `CRON_SECRET`.
5. Point-in-time recovery (pelan Pro) untuk sandaran harian.
