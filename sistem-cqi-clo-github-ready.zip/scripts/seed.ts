/**
 * Seed: Sistem Laporan CQI Pencapaian CLO - JKM POLISAS
 * Builds the PRD v3.0 demo scenario:
 *  - DJA30132 three-session story: Sesi II 2024/2025 (no data "-"), Sesi I
 *    2025/2026 (74 students, verified report + CQI actions), Sesi II
 *    2025/2026 (12 students, current session awaiting report).
 *  - Roles per permission matrix, configurable lookups, settings and the
 *    Ver. 3.2 form template.
 * Run: bun scripts/seed.ts
 */
import { PrismaClient } from '@prisma/client';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const db = new PrismaClient({ log: ['error'] });

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

const PASSWORD = 'Polisas#2026';

// deterministic PRNG so repeated seeds are stable
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface CloPlan {
  code: string;
  belowCount: number; // students scoring below the 50% threshold
}
interface OfferingPlan {
  courseCode: string;
  sessionSeq: number;
  programmeCode: string;
  sections: { code: string; students: string[]; lecturerEmail: string | null; coordinatorEmail: string | null }[];
  cloPlans: CloPlan[];
  seed: number;
  totalStudents: number;
}

function matrics(programme: string, sessionYear: string, section: string, count: number, start = 1): string[] {
  // plausible Malaysian polytechnic matric format: 01DAD23A1001
  const prefix = `01${programme}${sessionYear}${section.replace(programme, '')}`;
  return Array.from({ length: count }, (_, i) => `${prefix}${String(start + i).padStart(3, '0')}`);
}

async function main() {
  console.log('Seeding CQI CLO system...');

  // ---- clean (FK-safe order) ----
  const tables = [
    'auditLog', 'notification', 'verification', 'curriculumFeedback', 'evidenceFile',
    'cqiAction', 'cqiRow', 'cqiReport', 'attainmentSnapshot', 'mark', 'cloResult',
    'assessmentItem', 'assessment', 'section', 'offering', 'cloPloMap', 'clo',
    'courseProgramme', 'plo', 'programme', 'course', 'session', 'userRole', 'profile',
    'formTemplate', 'lookup', 'setting',
  ];
  for (const t of tables) {
    const delegate = (db as unknown as Record<string, { deleteMany: () => Promise<unknown> } | undefined>)[t];
    if (!delegate || typeof delegate.deleteMany !== 'function') {
      throw new Error(`No delegate for table: ${t}`);
    }
    await delegate.deleteMany();
  }

  // ---- settings (business parameters configurable, never hard-coded) ----
  const settings: Record<string, string> = {
    cloTarget: '55',
    dropThreshold: '5',
    comparisonWindow: '2',
    attainmentMethod: 'THRESHOLD',
    cloScoreThresholdPercent: '50',
    excludeAbsentBarred: 'true',
    lowSampleThreshold: '20',
    aiEnabled: 'true',
    aiMaxCallsPerUserPerDay: '20',
    aiMonthlyTokenBudget: '1000000',
    allowedEmailDomains: 'polisas.edu.my',
    departmentName: 'Jabatan Kejuruteraan Mekanikal (JKM)',
    institutionName: 'Politeknik Sultan Haji Ahmad Shah (POLISAS), Kuantan, Malaysia',
  };
  for (const [key, value] of Object.entries(settings)) await db.setting.create({ data: { key, value } });

  // ---- form template Ver 3.2 (Section 3.7, FR-RPT-02) ----
  await db.formTemplate.create({
    data: {
      versionLabel: '3.2',
      effectiveDate: new Date('2026-01-01'),
      updatedDate: new Date('2026-06-01'),
      active: true,
      layout: JSON.stringify({
        titleBm: 'Laporan Penambahbaikan Kualiti Berterusan (CQI) Pencapaian CLO',
        titleEn: 'Continuous Quality Improvement (CQI) Report: CLO Attainment',
        footerBm: 'Borang Laporan CQI Kursus Ver. 3.2',
        sections: {
          header: 'Maklumat Kursus',
          a: 'Seksyen A: Laporan Analisis Pencapaian CLO',
          aRecord: 'Rekod Pencapaian CLO Kurang 55% Mengikut Sesi',
          b: 'Seksyen B: Laporan/Status Pelaksanaan CQI Terdahulu',
          c: 'Seksyen C: Cadangan Pelaksanaan CQI (Sesi Akan Datang)',
          d: 'Seksyen D: Maklumbalas Kurikulum',
          e: 'Seksyen E: Pengesahan',
        },
        columns: {
          b: ['Bil.', 'Tindakan/Aktiviti', 'Impak Terhadap Pencapaian CLO', 'Tarikh Pelaksanaan', 'Dokumen/Bukti Pelaksanaan'],
          c: ['Bil.', 'Punca', 'Cadangan CQI', 'Jenis CQI'],
          d: ['Bil.', 'Perkara', 'Maklumbalas/Cadangan'],
        },
      }),
      fieldRules: JSON.stringify({
        cloTarget: 55,
        cqiTypeRule: 'highest-priority-present',
        cadanganMandatory: true,
        puncaMandatoryFor: ['CORRECTIVE', 'PREVENTIVE'],
      }),
    },
  });

  // ---- lookups (FR-MD-05 admin-managed dropdowns) ----
  const lookups: { type: string; code: string; labelBm: string; labelEn: string; sort: number }[] = [
    { type: 'ISSUE_CATEGORY', code: 'PDP', labelBm: 'Kaedah PdP tidak menepati keperluan pelajar', labelEn: 'PdP method does not match student needs', sort: 1 },
    { type: 'ISSUE_CATEGORY', code: 'ASAS', labelBm: 'Penguasaan asas pelajar lemah', labelEn: 'Weak foundational mastery', sort: 2 },
    { type: 'ISSUE_CATEGORY', code: 'KEHADIRAN', labelBm: 'Kehadiran dan penglibatan rendah', labelEn: 'Low attendance and engagement', sort: 3 },
    { type: 'ISSUE_CATEGORY', code: 'FASILITI', labelBm: 'Kekangan bahan/fasiliti latihan', labelEn: 'Training aids/facilities constraints', sort: 4 },
    { type: 'ISSUE_CATEGORY', code: 'SILIBUS', labelBm: 'Padanan silibus/kandungan kursus', labelEn: 'Syllabus/content alignment', sort: 5 },
    { type: 'ISSUE_CATEGORY', code: 'PENTAKSIRAN', labelBm: 'Reka bentuk pentaksiran tidak sepadan', labelEn: 'Assessment design misalignment', sort: 6 },
    { type: 'FEEDBACK_TOPIC', code: 'CLO', labelBm: 'CLO', labelEn: 'CLO', sort: 1 },
    { type: 'FEEDBACK_TOPIC', code: 'MAPPING_CLO', labelBm: 'Pemetaan CLO', labelEn: 'CLO Mapping', sort: 2 },
    { type: 'FEEDBACK_TOPIC', code: 'PLO', labelBm: 'PLO', labelEn: 'PLO', sort: 3 },
    { type: 'FEEDBACK_TOPIC', code: 'KAEDAH_PDP_PENTAKSIRAN', labelBm: 'Kaedah Pengajaran dan Kaedah Pentaksiran', labelEn: 'Teaching Method and Assessment Method', sort: 4 },
    { type: 'FEEDBACK_TOPIC', code: 'SLT', labelBm: 'Agihan SLT', labelEn: 'Distribution of SLT', sort: 5 },
    { type: 'FEEDBACK_TOPIC', code: 'RUJUKAN', labelBm: 'Rujukan', labelEn: 'References', sort: 6 },
    { type: 'FEEDBACK_TOPIC', code: 'SILIBUS', labelBm: 'Silibus Kursus', labelEn: 'Course Syllabus', sort: 7 },
    { type: 'FEEDBACK_TOPIC', code: 'AST', labelBm: 'AST', labelEn: 'AST', sort: 8 },
    { type: 'FEEDBACK_TOPIC', code: 'LAIN', labelBm: 'Lain-lain', labelEn: 'Other', sort: 9 },
    { type: 'CQI_TYPE', code: 'CORRECTIVE', labelBm: 'Pembetulan', labelEn: 'Corrective', sort: 1 },
    { type: 'CQI_TYPE', code: 'PREVENTIVE', labelBm: 'Pencegahan', labelEn: 'Preventive', sort: 2 },
    { type: 'CQI_TYPE', code: 'ENHANCEMENT', labelBm: 'Penambahbaikan/Pemantapan', labelEn: 'Enhancement/Sustaining', sort: 3 },
  ];
  for (const l of lookups) {
    await db.lookup.create({ data: { type: l.type, code: l.code, labelBm: l.labelBm, labelEn: l.labelEn, sortOrder: l.sort, active: true } });
  }

  // ---- sessions ----
  const now = new Date();
  const daysFrom = (n: number) => new Date(now.getTime() + n * 86400_000);
  const ses10 = await db.session.create({ data: { label: 'Sesi II 2024/2025', year: '2024/2025', term: 2, seqNo: 10, startDate: new Date('2025-02-16'), endDate: new Date('2025-08-15'), deadline: daysFrom(-200), status: 'OPEN' } });
  const ses20 = await db.session.create({ data: { label: 'Sesi I 2025/2026', year: '2025/2026', term: 1, seqNo: 20, startDate: new Date('2025-09-20'), endDate: new Date('2026-02-10'), deadline: daysFrom(-60), status: 'OPEN' } });
  const ses30 = await db.session.create({ data: { label: 'Sesi II 2025/2026', year: '2025/2026', term: 2, seqNo: 30, startDate: new Date('2026-03-01'), endDate: new Date('2026-08-10'), deadline: daysFrom(10), status: 'OPEN' } });
  const ses40 = await db.session.create({ data: { label: 'Sesi I 2026/2027', year: '2026/2027', term: 1, seqNo: 40, startDate: new Date('2026-09-20'), endDate: new Date('2027-02-10'), deadline: daysFrom(300), status: 'OPEN' } });

  // ---- programmes (verification chain configurable per programme - FR-WF-03) ----
  const dad = await db.programme.create({ data: { code: 'DAD', name: 'Diploma Kejuruteraan Automotif', level: 'Diploma', verificationChain: '["KK","KPRO","KJ"]' } });
  const djm = await db.programme.create({ data: { code: 'DJM', name: 'Diploma Kejuruteraan Mekanikal', level: 'Diploma', verificationChain: '["KPRO","KJ"]' } });

  const ploData = [
    ['PLO 1', 'Berpikir kritis dan penyelesaian masalah / Critical thinking and problem solving'],
    ['PLO 2', 'Kemahiran praktikal dan teknikal / Practical and technical skills'],
    ['PLO 3', 'Komunikasi / Communication'],
    ['PLO 4', 'Kerjasama pasukan / Teamwork'],
    ['PLO 5', 'Kemahiran pembelajaran berterusan / Continuous learning skills'],
    ['PLO 6', 'Etika profesional / Professional ethics'],
    ['PLO 7', 'Keusahawanan / Entrepreneurship'],
    ['PLO 8', 'Kepimpinan dan pengurusan / Leadership and management'],
  ];
  const plos: Record<string, Record<string, string>> = { DAD: {}, DJM: {} };
  for (const prog of [dad, djm]) {
    for (const [code, statement] of ploData) {
      const plo = await db.plo.create({ data: { programmeId: prog.id, code, statement } });
      plos[prog.code][code] = plo.id;
    }
  }

  // ---- courses + CLOs ----
  async function mkCourse(code: string, name: string, credit: number, programmeIds: string[], clos: { code: string; statement: string; domain: string; plos: string[] }[]) {
    const course = await db.course.create({ data: { code, name, credit } });
    for (const pid of programmeIds) await db.courseProgramme.create({ data: { courseId: course.id, programmeId: pid } });
    for (const c of clos) {
      const clo = await db.clo.create({ data: { courseId: course.id, code: c.code, statement: c.statement, domain: c.domain, version: 1 } });
      for (const ploCode of c.plos) {
        for (const pid of programmeIds) {
          const progCode = pid === djm.id ? 'DJM' : 'DAD';
          const ploId = plos[progCode][ploCode];
          if (ploId) await db.cloPloMap.create({ data: { cloId: clo.id, ploId } });
        }
      }
    }
    return course;
  }

  const dja30132 = await mkCourse('DJA30132', 'Automotive Workshop Practice 2', 3, [dad.id], [
    { code: 'CLO 1', statement: 'Mengamalkan prosedur keselamatan bengkel automotif mengikut SOP industri / Apply automotive workshop safety procedures according to industry SOP', domain: 'Psikomotor', plos: ['PLO 2', 'PLO 6'] },
    { code: 'CLO 2', statement: 'Mendiagnosis kerosakan sistem enjin dan sistem penghantaran kuasa / Diagnose faults in engine and powertrain systems', domain: 'Kognitif', plos: ['PLO 1', 'PLO 2'] },
    { code: 'CLO 3', statement: 'Menunjukkan kerjasama pasukan dan tanggungjawab dalam kerja bengkel / Demonstrate teamwork and responsibility in workshop tasks', domain: 'Afektif', plos: ['PLO 4', 'PLO 6'] },
  ]);
  const dja20113 = await mkCourse('DJA20113', 'Automotive Electrical and Electronics', 3, [dad.id], [
    { code: 'CLO 1', statement: 'Menerangkan prinsip sistem elektrik dan elektronik automotif / Explain automotive electrical and electronic system principles', domain: 'Kognitif', plos: ['PLO 1'] },
    { code: 'CLO 2', statement: 'Menguji dan membaiki litar elektrik automotif / Test and repair automotive electrical circuits', domain: 'Psikomotor', plos: ['PLO 2'] },
    { code: 'CLO 3', statement: 'Menghargai kepentingan ketepatan dalam kerja elektrik / Value precision in electrical work', domain: 'Afektif', plos: ['PLO 6'] },
  ]);
  const djm20073 = await mkCourse('DJM20073', 'Thermofluid', 3, [djm.id], [
    { code: 'CLO 1', statement: 'Menerangkan konsep termodinamik dan pemindahan haba / Explain thermodynamics and heat transfer concepts', domain: 'Kognitif', plos: ['PLO 1'] },
    { code: 'CLO 2', statement: 'Menyelesaikan masalah kejuruteraan berkaitan bendalir / Solve engineering problems related to fluids', domain: 'Kognitif', plos: ['PLO 1'] },
    { code: 'CLO 3', statement: 'Melaksanakan eksperimen termofluid mengikut prosedur / Conduct thermofluid experiments according to procedures', domain: 'Psikomotor', plos: ['PLO 2', 'PLO 3'] },
  ]);
  const djm20063 = await mkCourse('DJM20063', 'Applied Mechanics', 3, [djm.id], [
    { code: 'CLO 1', statement: 'Mengaplikasikan prinsip statik dalam penyelesaian masalah / Apply statics principles to problem solving', domain: 'Kognitif', plos: ['PLO 1'] },
    { code: 'CLO 2', statement: 'Menganalisis sistem mekanikal asas / Analyse basic mechanical systems', domain: 'Kognitif', plos: ['PLO 1'] },
    { code: 'CLO 3', statement: 'Menyediakan laporan eksperimen yang kemas / Prepare well-organised experiment reports', domain: 'Afektif', plos: ['PLO 3'] },
  ]);

  // ---- users ----
  async function mkUser(email: string, fullName: string, staffId: string, roles: { role: string; programmeId?: string | null }[]) {
    const profile = await db.profile.create({
      data: {
        email,
        passwordHash: hashPassword(PASSWORD),
        fullName,
        staffId,
        department: 'Jabatan Kejuruteraan Mekanikal',
        active: true,
        userRoles: { create: roles.map((r) => ({ role: r.role, programmeId: r.programmeId ?? null })) },
      },
    });
    return profile;
  }

  const admin = await mkUser('admin@polisas.edu.my', 'Pentadbir Sistem JKM', 'JKM-ADM-001', [{ role: 'admin' }]);
  const kj = await mkUser('kj.jkm@polisas.edu.my', 'Ir. Hj. Rosli bin Hasan', 'JKM-KJ-001', [{ role: 'kj' }]);
  const kproDad = await mkUser('kpro.dad@polisas.edu.my', 'Cik Nurain binti Ahmad', 'JKM-KP-011', [{ role: 'kpro', programmeId: dad.id }]);
  const kproDjm = await mkUser('kpro.djm@polisas.edu.my', 'Encik Faizal bin Kamarudin', 'JKM-KP-012', [{ role: 'kpro', programmeId: djm.id }]);
  const kkDja = await mkUser('kk.dja@polisas.edu.my', 'Encik Shahrul bin Nizam', 'JKM-KK-021', [{ role: 'kk', programmeId: dad.id }]);
  const coord1 = await mkUser('penyelaras.dja@polisas.edu.my', 'Encik Ahmad Zulfadli bin Rosli', 'JKM-P-101', [{ role: 'coordinator', programmeId: dad.id }, { role: 'lecturer', programmeId: dad.id }]);
  const lecturer1 = await mkUser('pensyarah1@polisas.edu.my', 'Puan Faridah binti Mansor', 'JKM-P-102', [{ role: 'lecturer', programmeId: dad.id }]);
  const lecturerDjm = await mkUser('pensyarah.djm@polisas.edu.my', 'Encik Hafiz bin Sulaiman', 'JKM-P-201', [{ role: 'coordinator', programmeId: djm.id }, { role: 'lecturer', programmeId: djm.id }]);
  const lecturerDjm2 = await mkUser('pensyarah.djm2@polisas.edu.my', 'Cik Illyana binti Mohd Isa', 'JKM-P-202', [{ role: 'lecturer', programmeId: djm.id }]);
  await mkUser('quality@polisas.edu.my', 'Puan Rosnah binti Karim (Unit Kualiti)', 'JKM-Q-001', [{ role: 'quality' }]);
  void admin;

  // ---- assessment structures ----
  async function mkAssessments(offeringId: string, plan: { name: string; type: string; weight: number; items: { label: string; maxMarks: number; cloCode: string }[] }[], closByCode: Record<string, string>) {
    for (const a of plan) {
      const assessment = await db.assessment.create({ data: { offeringId, name: a.name, type: a.type, weight: a.weight } });
      for (const item of a.items) {
        await db.assessmentItem.create({ data: { assessmentId: assessment.id, label: item.label, maxMarks: item.maxMarks, cloId: closByCode[item.cloCode] } });
      }
    }
  }

  // ---- score generation ----
  function genMarks(offeringId: string, sections: { id: string; students: string[] }[], items: { id: string; maxMarks: number; cloCode: string }[], cloPlans: CloPlan[], seed: number) {
    const rng = mulberry32(seed);
    const allStudents = sections.flatMap((s) => s.students.map((m) => ({ sectionId: s.id, matric: m })));
    const rows: { offeringId: string; sectionId: string; matric: string; itemId: string; score: number | null; status: string | null }[] = [];
    const lastCloCode = cloPlans[cloPlans.length - 1].code;
    const total = allStudents.length;
    // one ability per (student, CLO) shared across ALL items of that CLO,
    // so below-threshold counts are exact
    const abilityByStudentClo = new Map<string, number>();
    const absentStudents = new Set<number>([total - 1]); // demo FR-MK-04 statuses
    for (const plan of cloPlans) {
      const belowSet = new Set<number>();
      while (belowSet.size < Math.min(plan.belowCount, total)) belowSet.add(Math.floor(rng() * total));
      allStudents.forEach((_, idx) => {
        const below = belowSet.has(idx);
        abilityByStudentClo.set(`${plan.code}||${idx}`, below ? 0.28 + rng() * 0.17 : 0.56 + rng() * 0.33);
      });
    }
    for (const item of items) {
      allStudents.forEach((student, idx) => {
        const ability = Math.min(0.98, Math.max(0.12, abilityByStudentClo.get(`${item.cloCode}||${idx}`)! + (rng() - 0.5) * 0.05));
        let score = Math.round(item.maxMarks * ability);
        let status: string | null = null;
        if (absentStudents.has(idx) && item.cloCode === lastCloCode) {
          status = 'ABSENT';
          score = null;
        }
        rows.push({ offeringId, sectionId: student.sectionId, matric: student.matric, itemId: item.id, score, status });
      });
    }
    return db.mark.createMany({ data: rows });
  }

  // ---- offerings ----
  const closDja = await db.clo.findMany({ where: { courseId: dja30132.id }, orderBy: { code: 'asc' } });
  const closDjaByCode = Object.fromEntries(closDja.map((c) => [c.code, c.id]));
  const closDja20113 = await db.clo.findMany({ where: { courseId: dja20113.id }, orderBy: { code: 'asc' } });
  const closDja20113ByCode = Object.fromEntries(closDja20113.map((c) => [c.code, c.id]));
  const closDjm20073 = await db.clo.findMany({ where: { courseId: djm20073.id }, orderBy: { code: 'asc' } });
  const closDjm20073ByCode = Object.fromEntries(closDjm20073.map((c) => [c.code, c.id]));
  const closDjm20063 = await db.clo.findMany({ where: { courseId: djm20063.id }, orderBy: { code: 'asc' } });
  const closDjm20063ByCode = Object.fromEntries(closDjm20063.map((c) => [c.code, c.id]));

  const djaAssessments = [
    { name: 'Praktikal Berterusan', type: 'Coursework', weight: 40, items: [{ label: 'PRA1', maxMarks: 100, cloCode: 'CLO 1' }, { label: 'PRA2', maxMarks: 100, cloCode: 'CLO 3' }] },
    { name: 'Ujian Amali', type: 'Practical', weight: 30, items: [{ label: 'UA1', maxMarks: 100, cloCode: 'CLO 2' }] },
    { name: 'Tugasan Kumpulan', type: 'Coursework', weight: 30, items: [{ label: 'TP1', maxMarks: 100, cloCode: 'CLO 2' }] },
  ];
  const dja20113Assessments = [
    { name: 'Ujian 1', type: 'Exam', weight: 30, items: [{ label: 'U1', maxMarks: 50, cloCode: 'CLO 1' }] },
    { name: 'Ujian 2', type: 'Exam', weight: 20, items: [{ label: 'U2', maxMarks: 40, cloCode: 'CLO 2' }] },
    { name: 'Praktikal', type: 'Practical', weight: 50, items: [{ label: 'PRA1', maxMarks: 100, cloCode: 'CLO 2' }, { label: 'PRA2', maxMarks: 100, cloCode: 'CLO 3' }] },
  ];
  const djm20073Assessments = [
    { name: 'Ujian 1', type: 'Exam', weight: 20, items: [{ label: 'U1', maxMarks: 30, cloCode: 'CLO 1' }] },
    { name: 'Ujian 2', type: 'Exam', weight: 30, items: [{ label: 'U2', maxMarks: 40, cloCode: 'CLO 2' }] },
    { name: 'Makmal', type: 'Practical', weight: 20, items: [{ label: 'LM1', maxMarks: 100, cloCode: 'CLO 3' }] },
    { name: 'Peperiksaan Akhir', type: 'Exam', weight: 30, items: [{ label: 'E1', maxMarks: 60, cloCode: 'CLO 2' }] },
  ];
  const djm20063Assessments = [
    { name: 'Ujian 1', type: 'Exam', weight: 25, items: [{ label: 'U1', maxMarks: 30, cloCode: 'CLO 1' }] },
    { name: 'Ujian 2', type: 'Exam', weight: 25, items: [{ label: 'U2', maxMarks: 40, cloCode: 'CLO 2' }] },
    { name: 'Laporan Makmal', type: 'Coursework', weight: 50, items: [{ label: 'LR1', maxMarks: 100, cloCode: 'CLO 3' }] },
  ];

  async function mkOffering(courseId: string, sessionId: string, programmeId: string, coordinatorId: string, sectionPlan: { code: string; students: string[]; lecturerId: string | null }[]) {
    const offering = await db.offering.create({ data: { courseId, sessionId, programmeId, coordinatorId, status: 'ACTIVE' } });
    for (const s of sectionPlan) {
      await db.section.create({ data: { offeringId: offering.id, code: s.code, lecturerId: s.lecturerId, studentCount: s.students.length } });
    }
    return offering;
  }

  // 1) DJA30132 Sesi II 2024/2025 - offered but NO marks data ("-" demo)
  await mkOffering(dja30132.id, ses10.id, dad.id, coord1.id, [{ code: 'DAD2A', students: [], lecturerId: null }]);

  // 2) DJA30132 Sesi I 2025/2026 - 74 students in 3 sections
  const ses20Sections = [
    { code: 'DAD3A', students: matrics('DAD', '23', 'DAD3A', 25, 1), lecturerId: coord1.id },
    { code: 'DAD3B', students: matrics('DAD', '23', 'DAD3B', 24, 1), lecturerId: lecturer1.id },
    { code: 'DAD3C', students: matrics('DAD', '23', 'DAD3C', 25, 1), lecturerId: lecturer1.id },
  ];
  const off20 = await mkOffering(dja30132.id, ses20.id, dad.id, coord1.id, ses20Sections);
  await mkAssessments(off20.id, djaAssessments, closDjaByCode);
  const off20Full = await db.offering.findUnique({ where: { id: off20.id }, include: { sections: true, assessments: { include: { items: true } } } })!;
  const items20 = off20Full!.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, maxMarks: i.maxMarks, cloCode: closDja.find((c) => c.id === i.cloId)!.code })));
  // CLO1 87.8%, CLO2 51.4% (below -> corrective then), CLO3 81.1%
  await genMarks(off20.id, off20Full!.sections.map((s, idx) => ({ id: s.id, students: ses20Sections[idx].students })), items20, [
    { code: 'CLO 1', belowCount: 9 },
    { code: 'CLO 2', belowCount: 36 },
    { code: 'CLO 3', belowCount: 14 },
  ], 101);

  // 3) DJA30132 Sesi II 2025/2026 - 12 students, current session
  const off30 = await mkOffering(dja30132.id, ses30.id, dad.id, coord1.id, [{ code: 'DAD3A', students: matrics('DAD', '23', 'DAD3A', 12, 1), lecturerId: coord1.id }]);
  await mkAssessments(off30.id, djaAssessments, closDjaByCode);
  const off30Full = await db.offering.findUnique({ where: { id: off30.id }, include: { sections: true, assessments: { include: { items: true } } } })!;
  const items30 = off30Full!.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, maxMarks: i.maxMarks, cloCode: closDja.find((c) => c.id === i.cloId)!.code })));
  // CLO1 91.7%, CLO2 41.7% (below target -> Corrective), CLO3 63.6% (drop >= 5 -> Preventive)
  await genMarks(off30.id, off30Full!.sections.map((s, idx) => ({ id: s.id, students: matrics('DAD', '23', 'DAD3A', 12, 1) })), items30, [
    { code: 'CLO 1', belowCount: 1 },
    { code: 'CLO 2', belowCount: 7 },
    { code: 'CLO 3', belowCount: 4 },
  ], 202);

  // 4) DJA20113 Sesi II 2025/2026 - marks but no report yet
  const offDja20113 = await mkOffering(dja20113.id, ses30.id, dad.id, coord1.id, [{ code: 'DAD2A', students: matrics('DAD', '24', 'DAD2A', 22, 1), lecturerId: lecturer1.id }]);
  await mkAssessments(offDja20113.id, dja20113Assessments, closDja20113ByCode);
  const offDja20113Full = await db.offering.findUnique({ where: { id: offDja20113.id }, include: { sections: true, assessments: { include: { items: true } } } })!;
  await genMarks(offDja20113.id, offDja20113Full!.sections.map((s, idx) => ({ id: s.id, students: matrics('DAD', '24', 'DAD2A', 22, 1) })), offDja20113Full!.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, maxMarks: i.maxMarks, cloCode: closDja20113.find((c) => c.id === i.cloId)!.code }))), [
    { code: 'CLO 1', belowCount: 8 },
    { code: 'CLO 2', belowCount: 6 },
    { code: 'CLO 3', belowCount: 10 },
  ], 303);

  // 5) DJM20073 Sesi I 2025/2026 (comparison window for DJM)
  const offDjm20 = await mkOffering(djm20073.id, ses20.id, djm.id, lecturerDjm.id, [{ code: 'DJM2A', students: matrics('DJM', '23', 'DJM2A', 30, 1), lecturerId: lecturerDjm2.id }]);
  await mkAssessments(offDjm20.id, djm20073Assessments, closDjm20073ByCode);
  const offDjm20Full = await db.offering.findUnique({ where: { id: offDjm20.id }, include: { sections: true, assessments: { include: { items: true } } } })!;
  await genMarks(offDjm20.id, offDjm20Full!.sections.map((s, idx) => ({ id: s.id, students: matrics('DJM', '23', 'DJM2A', 30, 1) })), offDjm20Full!.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, maxMarks: i.maxMarks, cloCode: closDjm20073.find((c) => c.id === i.cloId)!.code }))), [
    { code: 'CLO 1', belowCount: 4 },
    { code: 'CLO 2', belowCount: 13 },
    { code: 'CLO 3', belowCount: 10 },
  ], 404);

  // 6) DJM20073 Sesi II 2025/2026 - report UNDER_VERIFICATION (awaiting KPro per DJM chain)
  const offDjm30 = await mkOffering(djm20073.id, ses30.id, djm.id, lecturerDjm.id, [{ code: 'DJM2A', students: matrics('DJM', '23', 'DJM2A', 30, 1), lecturerId: lecturerDjm2.id }]);
  await mkAssessments(offDjm30.id, djm20073Assessments, closDjm20073ByCode);
  const offDjm30Full = await db.offering.findUnique({ where: { id: offDjm30.id }, include: { sections: true, assessments: { include: { items: true } } } })!;
  await genMarks(offDjm30.id, offDjm30Full!.sections.map((s, idx) => ({ id: s.id, students: matrics('DJM', '23', 'DJM2A', 30, 1) })), offDjm30Full!.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, maxMarks: i.maxMarks, cloCode: closDjm20073.find((c) => c.id === i.cloId)!.code }))), [
    { code: 'CLO 1', belowCount: 4 },
    { code: 'CLO 2', belowCount: 14 },
    { code: 'CLO 3', belowCount: 12 },
  ], 505);

  // 7) DJM20063 Sesi II 2025/2026 - DRAFT report
  const offDjm20063 = await mkOffering(djm20063.id, ses30.id, djm.id, lecturerDjm.id, [{ code: 'DJM2B', students: matrics('DJM', '24', 'DJM2B', 28, 1), lecturerId: lecturerDjm2.id }]);
  await mkAssessments(offDjm20063.id, djm20063Assessments, closDjm20063ByCode);
  const offDjm20063Full = await db.offering.findUnique({ where: { id: offDjm20063.id }, include: { sections: true, assessments: { include: { items: true } } } })!;
  await genMarks(offDjm20063.id, offDjm20063Full!.sections.map((s, idx) => ({ id: s.id, students: matrics('DJM', '24', 'DJM2B', 28, 1) })), offDjm20063Full!.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, maxMarks: i.maxMarks, cloCode: closDjm20063.find((c) => c.id === i.cloId)!.code }))), [
    { code: 'CLO 1', belowCount: 3 },
    { code: 'CLO 2', belowCount: 10 },
    { code: 'CLO 3', belowCount: 9 },
  ], 606);

  console.log('Offerings and marks seeded');

  // ---- verified report for DJA30132 Sesi I 2025/2026 (FR-WF, FR-PCQI demo) ----
  const report20 = await db.cqiReport.create({
    data: {
      offeringId: off20.id,
      templateVersion: '3.2',
      status: 'VERIFIED',
      version: 1,
      overallType: 'CORRECTIVE',
      submittedById: coord1.id,
      submittedAt: daysFrom(-45),
      sectionAIssues: JSON.stringify([
        { sessionLabel: ses20.label, sessionId: ses20.id, isCurrent: true, hasData: true, belowClos: [{ code: 'CLO 2', attainment: 51.4 }], issueCode: 'PDP', cloInvolved: 'CLO 2', focus: 'Kaedah amali bengkel yang lebih berstruktur dan ujian diagnostik awal' },
        { sessionLabel: ses10.label, sessionId: ses10.id, isCurrent: false, hasData: false, belowClos: [], issueCode: null, cloInvolved: null, focus: null },
      ]),
    },
  });
  const row20 = await db.cqiRow.create({
    data: {
      reportId: report20.id,
      cloId: closDjaByCode['CLO 2'],
      cqiType: 'CORRECTIVE',
      suggestedType: 'CORRECTIVE',
      causeTags: JSON.stringify(['PDP', 'DEMOGRAFI']),
      causeText: 'Kaedah PdP amali kurang berstruktur; latar belakang kemahiran asas pelajar tidak seragam.',
      proposal: 'Bengkel penguasaan asas sistem enjin sebelum kitaran amali utama dan ujian diagnostik awal semester bagi mengesan pelajar berisiko.',
      outcome: 'Sekurang-kurangnya 80% pelajar sasaran mencapai paras CLO 2 dalam ujian selepas bengkel.',
      ownerId: coord1.id,
      targetDate: daysFrom(-20),
      sortOrder: 0,
    },
  });
  // Section B demo: the proposed action implemented, impact observed
  await db.cqiAction.create({
    data: {
      originReportId: report20.id,
      cloId: closDjaByCode['CLO 2'],
      description: 'Bengkel penguasaan asas sistem enjin (2 sesi) dan ujian diagnostik awal semester',
      ownerId: coord1.id,
      targetDate: daysFrom(-20),
      status: 'IMPLEMENTED',
      implementedDate: daysFrom(-30),
      impact: 'DECLINED',
      impactText: 'Pencapaian masih di bawah sasaran pada separuh penggal; bengkel lanjutan diperlukan',
      verifiedInReportId: null,
    },
  });
  await db.cqiAction.create({
    data: {
      originReportId: report20.id,
      cloId: closDjaByCode['CLO 1'],
      description: 'Kemaskini carta alir SOP keselamatan bengkel dan papan panduan visual',
      ownerId: coord1.id,
      targetDate: daysFrom(-15),
      status: 'IMPLEMENTED',
      implementedDate: daysFrom(-25),
      impact: 'IMPROVED',
      impactText: 'Pematuhan SOP meningkat; pencapaian CLO 1 mengekalkan paras tinggi',
      unplanned: true,
    },
  });
  // snapshot for the verified report (FR-CLO-08)
  await db.attainmentSnapshot.create({
    data: {
      offeringId: off20.id,
      reportId: report20.id,
      computedAt: daysFrom(-45),
      computedBy: coord1.id,
      settingsUsed: JSON.stringify({ cloTarget: 55, dropThreshold: 5, comparisonWindow: 2, attainmentMethod: 'THRESHOLD' }),
      results: JSON.stringify({
        summary: 'Sesi I 2025/2026 - CLO 2 below target (51.4%), corrective CQI proposed and implemented',
        studentCount: 74,
        byClo: { 'CLO 1': 87.8, 'CLO 2': 51.4, 'CLO 3': 64.9 },
      }),
    },
  });
  // verifications per chain KK -> KPRO -> KJ (DAD)
  await db.verification.create({ data: { reportId: report20.id, role: 'KK', userId: kkDja.id, decision: 'VERIFIED', comment: 'Analisis pencapaian munasabah. Cadangan CQI selari dengan isu pencapaian.', signedAt: daysFrom(-42) } });
  await db.verification.create({ data: { reportId: report20.id, role: 'KPRO', userId: kproDad.id, decision: 'VERIFIED', comment: 'Disahkan. Tindakan bengkel asas perlu dipantau impaknya pada sesi akan datang.', signedAt: daysFrom(-41) } });
  await db.verification.create({ data: { reportId: report20.id, role: 'KJ', userId: kj.id, decision: 'VERIFIED', comment: 'Laporan lengkap dan disahkan untuk rekod jabatan.', signedAt: daysFrom(-40) } });
  // Section D curriculum feedback
  await db.curriculumFeedback.create({ data: { reportId: report20.id, courseId: dja30132.id, sessionId: ses20.id, topic: 'SLT', text: 'Agihan SLT praktikal (4 jam/minggu) difikirkan kurang untuk kitaran diagnosis penuh. Dicadangkan pertimbangan semula kepada 5 jam untuk modul diagnosis.' } });
  await db.curriculumFeedback.create({ data: { reportId: report20.id, courseId: dja30132.id, sessionId: ses20.id, topic: 'AST', text: 'Penegasan UA1 kepada aspek diagnosis sistem penghantaran kuasa bagi menepati AST.' } });

  // ---- DJM20073 report UNDER_VERIFICATION (awaiting KPro - first in DJM chain) ----
  const reportDjm = await db.cqiReport.create({
    data: {
      offeringId: offDjm30.id,
      templateVersion: '3.2',
      status: 'UNDER_VERIFICATION',
      version: 1,
      overallType: 'CORRECTIVE',
      submittedById: lecturerDjm.id,
      submittedAt: daysFrom(-2),
      sectionAIssues: JSON.stringify([]),
    },
  });
  await db.cqiRow.create({
    data: {
      reportId: reportDjm.id,
      cloId: closDjm20073ByCode['CLO 2'],
      cqiType: 'CORRECTIVE',
      suggestedType: 'CORRECTIVE',
      causeTags: JSON.stringify(['ASAS']),
      causeText: 'Penguasaan matematik bendalir pelajar lemah; latihan berbimbing kurang.',
      proposal: 'Tutorian penyelesaian masalah mingguan dan bank latihan bertahap sebelum Ujian 2.',
      outcome: 'Pencapaian CLO 2 mencapai sekurang-kurangnya 55% pada sesi akan datang.',
      ownerId: lecturerDjm.id,
      targetDate: daysFrom(30),
      sortOrder: 0,
    },
  });
  await db.attainmentSnapshot.create({
    data: {
      offeringId: offDjm30.id,
      reportId: reportDjm.id,
      computedBy: lecturerDjm.id,
      settingsUsed: JSON.stringify({ cloTarget: 55, dropThreshold: 5, comparisonWindow: 2, attainmentMethod: 'THRESHOLD' }),
      results: JSON.stringify({ summary: 'CLO 2 below target; corrective proposed', studentCount: 30 }),
    },
  });

  // ---- DJM20063 DRAFT report with rows ----
  const reportDjm20063 = await db.cqiReport.create({
    data: {
      offeringId: offDjm20063.id,
      templateVersion: '3.2',
      status: 'DRAFT',
      version: 1,
      overallType: 'ENHANCEMENT',
      sectionAIssues: JSON.stringify([]),
    },
  });
  await db.cqiRow.create({
    data: {
      reportId: reportDjm20063.id,
      cloId: null,
      cqiType: 'ENHANCEMENT',
      suggestedType: 'ENHANCEMENT',
      proposal: 'Kekalkan strategi makmal berpandukan rubrik dan tambah sesi rujukan balas laporan sebelum penghantaran akhir.',
      outcome: 'Pencapaian ketiga-tiga CLO kekal di atas sasaran.',
      ownerId: lecturerDjm.id,
      targetDate: daysFrom(40),
      sortOrder: 0,
    },
  });

  // ---- demo evidence file ----
  const evidenceDir = path.join(process.cwd(), 'uploads', 'evidence');
  fs.mkdirSync(evidenceDir, { recursive: true });
  const tinyPdf = Buffer.from(
    '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 300 120]/Contents 4 0 R>>endobj\n4 0 obj<</Length 60>>stream\nBT /F1 10 Tf 20 70 Td (Bukti: Rekod kehadiran bengkel asas - demo) Tj ET\nendstream\nendobj\ntrailer<</Root 1 0 R>>',
    'utf8',
  );
  const evidencePath = path.join(evidenceDir, 'evidence-demo-1.pdf');
  fs.writeFileSync(evidencePath, tinyPdf);

  // ---- notifications (FR-NT-01 demo) ----
  await db.notification.createMany({
    data: [
      { userId: coord1.id, type: 'VERIFIED', refId: report20.id, messageBm: 'Laporan CQI DJA30132 (Sesi I 2025/2026) telah disahkan oleh KJ.', messageEn: 'DJA30132 CQI report (Sesi I 2025/2026) has been verified by KJ.', link: '/offerings/' + off20.id, read: true },
      { userId: kkDja.id, type: 'SUBMITTED', refId: reportDjm.id, messageBm: 'Laporan DJM20073 (Sesi II 2025/2026) menunggu pengesahan.', messageEn: 'DJM20073 report (Sesi II 2025/2026) is awaiting verification.', link: '/verification', read: false },
      { userId: kproDjm.id, type: 'SUBMITTED', refId: reportDjm.id, messageBm: 'Laporan DJM20073 (Sesi II 2025/2026) menunggu pengesahan KPro.', messageEn: 'DJM20073 report (Sesi II 2025/2026) awaits KPro verification.', link: '/verification', read: false },
      { userId: coord1.id, type: 'REMINDER', refId: off30.id, messageBm: 'Peringatan: Laporan CQI DJA30132 (Sesi II 2025/2026) perlu dihantar. Tarikh akhir dalam 10 hari.', messageEn: 'Reminder: DJA30132 CQI report (Sesi II 2025/2026) is due in 10 days.', link: '/offerings/' + off30.id, read: false },
    ],
  });

  const cqiAction = row20;
  void cqiAction;
  console.log('Seed complete.');
  console.log('Demo password for all accounts:', PASSWORD);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
