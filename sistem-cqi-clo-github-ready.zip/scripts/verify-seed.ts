/** Verify seeded attainment figures for the DJA30132 demo story. */
import { PrismaClient } from '@prisma/client';

const db = new PrismaClient({ log: ['error'] });

async function main() {
  const settings = { cloTarget: 55, dropThreshold: 5, comparisonWindow: 2, attainmentMethod: 'THRESHOLD' as const, cloScoreThresholdPercent: 50, excludeAbsentBarred: true, lowSampleThreshold: 20 };
  const offering = await db.offering.findFirst({
    where: { course: { code: 'DJA30132' }, session: { seqNo: 30 } },
    include: { course: { include: { clos: true } }, assessments: { include: { items: true } }, marks: true, sections: true },
  });
  if (!offering) throw new Error('no offering');
  const items = offering.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, label: i.label, maxMarks: i.maxMarks, cloId: i.cloId })));
  const marks = offering.marks.map((m) => ({ matric: m.matric, itemId: m.itemId, score: m.score, status: m.status, sectionId: m.sectionId }));
  const clos = offering.course.clos.map((c) => ({ id: c.id, code: c.code, statement: c.statement, domain: c.domain, version: c.version }));

  const { computeStudentCloPercents, attainForCohort, buildComparison } = await import('../src/lib/calculation/index');
  const percents = computeStudentCloPercents(marks, items, settings);
  const att = attainForCohort(percents, clos, settings);
  console.log('Current session (Sesi II 2025/2026):');
  for (const a of att) console.log(`  ${a.code}: ${a.attainment}% (n=${a.studentCount}) met=${a.met}`);

  // window
  const windowOfferings = [] as any[];
  for (const seq of [30, 20, 10]) {
    const off = await db.offering.findFirst({
      where: { course: { code: 'DJA30132' }, session: { seqNo: seq } },
      include: { session: true, course: { include: { clos: true } }, assessments: { include: { items: true } }, marks: true, sections: true },
    });
    if (!off) continue;
    windowOfferings.push({
      sessionId: off.sessionId,
      seqNo: off.session.seqNo,
      label: off.session.label,
      term: off.session.term,
      year: off.session.year,
      clos: off.course.clos.map((c) => ({ id: c.id, code: c.code, statement: c.statement, domain: c.domain, version: c.version })),
      items: off.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, label: i.label, maxMarks: i.maxMarks, cloId: i.cloId }))),
      marks: off.marks.map((m) => ({ matric: m.matric, itemId: m.itemId, score: m.score, status: m.status, sectionId: m.sectionId })),
      sections: off.sections.map((s) => ({ id: s.id, code: s.code })),
      distinctStudents: new Set(off.marks.map((m) => m.matric)).size,
    });
  }
  const cmp = buildComparison(windowOfferings, settings);
  console.log('\nSeries student counts:', cmp.series.map((s) => `${s.label}=${s.studentCount ?? '-'}`).join(', '));
  console.log('\nComparisons:');
  for (const c of cmp.comparisons) {
    console.log(`  ${c.code}: series=[${c.series.map((v) => v ?? '-').join(', ')}] delta=${c.delta} met=${c.met} declined=${c.declined}`);
  }
  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
