/**
 * Find the correct Supabase pooler region for project pqvdalbvqkkvbjsddisr.
 * The pooler routes tenants by username "postgres.<project-ref>" and answers
 * "tenant/user ... not found" when the project is hosted in another region.
 * The region whose pooler does NOT answer with that error is the right one.
 */
import { Client } from 'pg';

const REF = 'pqvdalbvqkkvbjsddisr';
const PASSWORD = process.env.SUPABASE_DB_PASSWORD_OVERRIDE ?? '';

const REGIONS = [
  'aws-0-ap-southeast-1', 'aws-0-ap-southeast-2', 'aws-0-ap-southeast-3',
  'aws-0-ap-southeast-4', 'aws-0-ap-southeast-5', 'aws-0-ap-south-1',
  'aws-0-ap-south-2', 'aws-0-ap-northeast-1', 'aws-0-ap-northeast-2',
  'aws-0-ap-northeast-3', 'aws-0-eu-west-1', 'aws-0-eu-west-2',
  'aws-0-eu-west-3', 'aws-0-eu-central-1', 'aws-0-eu-central-2',
  'aws-0-eu-north-1', 'aws-0-us-east-1', 'aws-0-us-east-2',
  'aws-0-us-west-1', 'aws-0-us-west-2', 'aws-0-ca-central-1', 'aws-0-sa-east-1',
  'aws-1-ap-southeast-1', 'aws-1-ap-southeast-2', 'aws-1-ap-south-1',
  'aws-1-ap-northeast-1', 'aws-1-ap-northeast-2', 'aws-1-eu-west-1',
  'aws-1-eu-west-2', 'aws-1-eu-central-1', 'aws-1-us-east-1', 'aws-1-us-east-2',
  'aws-1-us-west-1', 'aws-1-us-west-2',
];

async function probe(region: string): Promise<string> {
  const host = `${region}.pooler.supabase.com`;
  const client = new Client({
    connectionString: `postgresql://postgres.${REF}:${PASSWORD}@${host}:5432/postgres`,
    ssl: { rejectUnauthorized: false },
    connectionTimeoutMillis: 6000,
  });
  try {
    await client.connect();
    const r = await client.query('select current_user, inet_server_addr()::text as ip');
    const row = r.rows[0];
    await client.end();
    return `SUCCESS user=${row.current_user} server=${row.ip}`;
  } catch (err) {
    try { await client.end(); } catch { /* ignore */ }
    return err instanceof Error ? err.message : String(err);
  }
}

for (const region of REGIONS) {
  const result = await probe(region);
  const notFound = /not found/i.test(result);
  console.log(`${notFound ? '  miss' : '>>> HIT '} ${region}: ${result.slice(0, 110)}`);
  if (!notFound && result.startsWith('SUCCESS')) {
    console.log(`\nREGION FOUND: ${region}`);
    break;
  }
}
