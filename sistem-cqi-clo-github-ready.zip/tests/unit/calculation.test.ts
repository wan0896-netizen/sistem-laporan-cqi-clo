import { describe, it, expect } from 'vitest';
import {
  DEFAULT_CALC_SETTINGS,
  computeStudentCloPercents,
  attainForCohort,
  buildComparison,
  suggestCqiTypes,
  overallCqiType,
  suggestImpact,
  type MarkLike,
  type ItemLike,
  type CloLike,
  type CalcSettings,
} from '../../src/lib/calculation';

const settings: CalcSettings = { ...DEFAULT_CALC_SETTINGS };

const clos: CloLike[] = [
  { id: 'clo1', code: 'CLO 1', statement: 'Apply workshop safety procedures', domain: 'Psychomotor', version: 1 },
  { id: 'clo2', code: 'CLO 2', statement: 'Diagnose automotive systems', domain: 'Cognitive', version: 1 },
  { id: 'clo3', code: 'CLO 3', statement: 'Demonstrate teamwork', domain: 'Affective', version: 1 },
];

const items: ItemLike[] = [
  { id: 'i1', label: 'T1', maxMarks: 100, cloId: 'clo1' },
  { id: 'i2', label: 'A1', maxMarks: 100, cloId: 'clo2' },
  { id: 'i3', label: 'A2', maxMarks: 100, cloId: 'clo2' },
  { id: 'i4', label: 'Q1', maxMarks: 100, cloId: 'clo3' },
];

function mark(matric: string, itemId: string, score: number | null, status: string | null = null): MarkLike {
  return { matric, itemId, score, status, sectionId: 's1' };
}

describe('Per-student CLO percentage (8.2)', () => {
  it('computes pooled percentage across items mapped to the same CLO', () => {
    const marks = [mark('M1', 'i2', 60), mark('M1', 'i3', 40)]; // 100/200 = 50%
    const out = computeStudentCloPercents(marks, items, settings);
    const m1clo2 = out.find((p) => p.matric === 'M1' && p.cloId === 'clo2');
    expect(m1clo2?.percent).toBe(50);
  });

  it('treats EXEMPTED item as removed from the denominator', () => {
    const marks = [mark('M1', 'i2', 90, null), mark('M1', 'i3', null, 'EXEMPTED')];
    const out = computeStudentCloPercents(marks, items, settings);
    expect(out.find((p) => p.matric === 'M1' && p.cloId === 'clo2')?.percent).toBe(90);
  });

  it('flags ABSENT/BARRED students for exclusion when configured', () => {
    const marks = [mark('M1', 'i2', null, 'BARRED'), mark('M1', 'i3', 80)];
    const out = computeStudentCloPercents(marks, items, settings);
    expect(out.find((p) => p.matric === 'M1' && p.cloId === 'clo2')?.excluded).toBe(true);
  });
});

describe('Attainment + 55% target (FR-CLO-01/03)', () => {
  it('THRESHOLD method: percentage of students meeting the threshold', () => {
    // 4 students: 80, 60, 45, 30 -> threshold 50 => 2/4 = 50%
    const percents = [80, 60, 45, 30].map((p, i) => ({ cloId: 'clo1', matric: `M${i}`, percent: p, excluded: false }));
    const att = attainForCohort(percents, [clos[0]], settings);
    expect(att[0].attainment).toBe(50);
    expect(att[0].met).toBe(false); // 50 < 55
    expect(att[0].studentCount).toBe(4);
  });

  it('AVERAGE method: class average of CLO percentages', () => {
    const s = { ...settings, attainmentMethod: 'AVERAGE' as const };
    const percents = [70, 50].map((p, i) => ({ cloId: 'clo1', matric: `M${i}`, percent: p, excluded: false }));
    const att = attainForCohort(percents, [clos[0]], s);
    expect(att[0].attainment).toBe(60);
    expect(att[0].met).toBe(true); // 60 >= 55
  });

  it('boundary: attainment exactly at target counts as met', () => {
    const percents = [
      { cloId: 'clo1', matric: 'A', percent: 60, excluded: false },
      { cloId: 'clo1', matric: 'B', percent: 45, excluded: false },
    ];
    // THRESHOLD: 1 of 2 students meet the 50% student threshold -> 50 (not met)
    const att = attainForCohort(percents, [clos[0]], settings);
    expect(att[0].attainment).toBe(50);
    expect(att[0].met).toBe(false);
    // AVERAGE: (60+45)/2 = 52.5 -> not met
    const s = { ...settings, attainmentMethod: 'AVERAGE' as const };
    const att2 = attainForCohort(percents, [clos[0]], s);
    expect(att2[0].attainment).toBe(52.5);
    expect(att2[0].met).toBe(false);
    // exactly-at-target case: AVERAGE (60+50)/2 = 55 -> met (>= 55 inclusive)
    const att3 = attainForCohort(
      [percents[0], { cloId: 'clo1', matric: 'C', percent: 50, excluded: false }],
      [clos[0]],
      s,
    );
    expect(att3[0].attainment).toBe(55);
    expect(att3[0].met).toBe(true);
  });

  it('no data -> null attainment and met=null ("-" handling)', () => {
    const att = attainForCohort([], [clos[0]], settings);
    expect(att[0].attainment).toBeNull();
    expect(att[0].met).toBeNull();
  });

  it('low-sample cohort flagged (open question 8, threshold 20)', () => {
    const percents = [{ cloId: 'clo1', matric: 'A', percent: 80, excluded: false }];
    const att = attainForCohort(percents, [clos[0]], settings);
    expect(att[0].lowSample).toBe(true);
  });

  it('absent/barred excluded from denominator when configured', () => {
    const percents = [
      { cloId: 'clo1', matric: 'A', percent: 80, excluded: false },
      { cloId: 'clo1', matric: 'B', percent: 20, excluded: true }, // barred
    ];
    const att = attainForCohort(percents, [clos[0]], settings);
    expect(att[0].attainment).toBe(100); // only student A counts (meets threshold)
    expect(att[0].studentCount).toBe(1);
  });
});

describe('Three-session comparison window (FR-CLO-02/04)', () => {
  const mkOffering = (
    seqNo: number,
    label: string,
    term: number,
    year: string,
    scores: { matric: string; itemId: string; score: number | null; status?: string | null }[],
  ) => ({
    sessionId: `sess${seqNo}`,
    seqNo,
    label,
    term,
    year,
    clos,
    items,
    marks: scores.map((s) => ({ matric: s.matric, itemId: s.itemId, score: s.score, status: s.status ?? null, sectionId: 's1' })),
    sections: [{ id: 's1', code: 'DAD3A' }],
    distinctStudents: new Set(scores.map((s) => s.matric)).size,
  });

  it('window = current + 2 previous; sessions without data show "-"', () => {
    const current = mkOffering(30, 'Sesi II 2025/2026', 2, '2025/2026', [
      // CLO2: 5 students -> 60% meet (3/5 = 60)
      { matric: 'A', itemId: 'i2', score: 80 }, { matric: 'A', itemId: 'i3', score: 80 },
      { matric: 'B', itemId: 'i2', score: 60 }, { matric: 'B', itemId: 'i3', score: 60 },
      { matric: 'C', itemId: 'i2', score: 60 }, { matric: 'C', itemId: 'i3', score: 60 },
      { matric: 'D', itemId: 'i2', score: 40 }, { matric: 'D', itemId: 'i3', score: 40 },
      { matric: 'E', itemId: 'i2', score: 40 }, { matric: 'E', itemId: 'i3', score: 40 },
    ]);
    const prev1 = mkOffering(20, 'Sesi I 2025/2026', 1, '2025/2026', [
      { matric: 'A', itemId: 'i2', score: 80 }, { matric: 'A', itemId: 'i3', score: 80 },
      { matric: 'B', itemId: 'i2', score: 80 }, { matric: 'B', itemId: 'i3', score: 80 },
      { matric: 'C', itemId: 'i2', score: 40 }, { matric: 'C', itemId: 'i3', score: 40 },
      { matric: 'D', itemId: 'i2', score: 40 }, { matric: 'D', itemId: 'i3', score: 40 },
      { matric: 'E', itemId: 'i2', score: 40 }, { matric: 'E', itemId: 'i3', score: 40 },
    ]);
    const prev2 = mkOffering(10, 'Sesi II 2024/2025', 2, '2024/2025', []); // no data
    const cmp = buildComparison([current, prev1, prev2], settings);
    expect(cmp.series).toHaveLength(3);
    expect(cmp.series[2].studentCount).toBeNull(); // "-" for earlier session
    expect(cmp.series[0].studentCount).toBe(5);
    // current CLO2: students 80,60,60,40,40 vs threshold 50 -> 3/5 = 60%
    const clo2 = cmp.comparisons.find((c) => c.code === 'CLO 2')!;
    expect(clo2.currentAttainment).toBe(60);
    // prev1 CLO2: 80,80,40,40,40 -> 2/5 = 40%
    expect(clo2.series[1]).toBe(40);
    // delta vs nearest previous WITH data = +20
    expect(clo2.delta).toBe(20);
    expect(clo2.prevLabel).toBe('Sesi I 2025/2026');
    expect(clo2.declined).toBe(false);
  });

  it('flags declines of >= 5 percentage points (FR-CLO-04)', () => {
    const current = mkOffering(30, 'Sesi II 2025/2026', 2, '2025/2026', [
      { matric: 'A', itemId: 'i4', score: 40 },
    ]);
    const prev1 = mkOffering(20, 'Sesi I 2025/2026', 1, '2025/2026', [
      { matric: 'A', itemId: 'i4', score: 80 },
    ]);
    const avg = { ...settings, attainmentMethod: 'AVERAGE' as const };
    const cmp = buildComparison([current, prev1], avg);
    const clo3 = cmp.comparisons.find((c) => c.code === 'CLO 3')!;
    expect(clo3.delta).toBe(-40);
    expect(clo3.declined).toBe(true);
  });

  it('a 4-point drop is NOT a significant decline', () => {
    const current = mkOffering(30, 'Sesi II 2025/2026', 2, '2025/2026', [
      { matric: 'A', itemId: 'i4', score: 56 },
    ]);
    const prev1 = mkOffering(20, 'Sesi I 2025/2026', 1, '2025/2026', [
      { matric: 'A', itemId: 'i4', score: 60 },
    ]);
    const avg = { ...settings, attainmentMethod: 'AVERAGE' as const };
    const cmp = buildComparison([current, prev1], avg);
    const clo3 = cmp.comparisons.find((c) => c.code === 'CLO 3')!;
    expect(clo3.delta).toBe(-4);
    expect(clo3.declined).toBe(false);
  });

  it('first-time course (no previous data) compares without error', () => {
    const current = mkOffering(30, 'Sesi II 2025/2026', 2, '2025/2026', [
      { matric: 'A', itemId: 'i1', score: 70 },
    ]);
    const cmp = buildComparison([current], settings);
    expect(cmp.comparisons[0].delta).toBeNull();
    expect(cmp.comparisons[0].prevLabel).toBeNull();
    expect(cmp.series).toHaveLength(1);
  });

  it('warns when CLO definitions differ between sessions (FR-CLO-09)', () => {
    const changedClos: CloLike[] = [{ ...clos[0], statement: 'Updated statement', version: 2 }];
    const current = {
      sessionId: 's3', seqNo: 30, label: 'Sesi II 2025/2026', term: 2, year: '2025/2026',
      clos: changedClos, items, marks: [mark('A', 'i1', 70)], sections: [{ id: 's1', code: 'DAD3A' }], distinctStudents: 1,
    };
    const prev1 = {
      sessionId: 's2', seqNo: 20, label: 'Sesi I 2025/2026', term: 1, year: '2025/2026',
      clos, items, marks: [mark('A', 'i1', 70)], sections: [{ id: 's1', code: 'DAD3A' }], distinctStudents: 1,
    };
    const cmp = buildComparison([current, prev1], settings);
    expect(cmp.likeForLike).toBe(false);
    expect(cmp.cloDifferences.length).toBeGreaterThan(0);
  });
});

describe('CQI type decision rule (8.3, FR-CQI-02)', () => {
  const cmpOf = (attainments: (number | null)[], deltas: (number | null)[]) => {
    const comparisons = clos.map((c, i) => ({
      cloId: c.id, code: c.code, statement: c.statement, series: [attainments[i]], delta: deltas[i],
      met: attainments[i] === null ? null : attainments[i]! >= 55, declined: deltas[i] !== null && deltas[i]! <= -5,
      prevLabel: deltas[i] === null ? null : 'Sesi I 2025/2026',
      currentAttainment: attainments[i], currentStudentCount: 10,
    }));
    return {
      current: [], perSection: [],
      series: [{ sessionId: 's3', seqNo: 30, label: 'Sesi II 2025/2026', term: 2, year: '2025/2026', studentCount: 10, attainmentByClo: {}, hasData: true, isCurrent: true }],
      comparisons,
      belowTarget: comparisons.filter((c) => c.currentAttainment !== null && c.currentAttainment < 55),
      declined: comparisons.filter((c) => c.declined),
      anyData: true, likeForLike: true, cloDifferences: [],
    };
  };

  it('priority 1: any CLO below target -> Corrective', () => {
    const cmp = cmpOf([50, 70, 70], [null, 5, 0]);
    const sug = suggestCqiTypes(cmp, settings);
    expect(sug[0].suggestedType).toBe('CORRECTIVE');
    expect(sug[0].affected).toBe(true);
  });

  it('priority 2: all meet target but a drop >= 5 -> Preventive', () => {
    const cmp = cmpOf([70, 70, 60], [0, 0, -6]);
    const sug = suggestCqiTypes(cmp, settings);
    expect(sug[2].suggestedType).toBe('PREVENTIVE');
    expect(sug[2].affected).toBe(true);
  });

  it('priority 3: all meet target, no significant drop -> Enhancement', () => {
    const cmp = cmpOf([70, 60, 65], [1, 0, -2]);
    const sug = suggestCqiTypes(cmp, settings);
    expect(sug.every((s) => s.suggestedType === 'ENHANCEMENT')).toBe(true);
    expect(sug.every((s) => !s.affected)).toBe(true);
  });

  it('overall type = highest priority present', () => {
    expect(overallCqiType(['ENHANCEMENT', 'CORRECTIVE', 'PREVENTIVE'])).toBe('CORRECTIVE');
    expect(overallCqiType(['ENHANCEMENT', 'PREVENTIVE'])).toBe('PREVENTIVE');
    expect(overallCqiType(['ENHANCEMENT'])).toBe('ENHANCEMENT');
    expect(overallCqiType([])).toBeNull();
  });
});

describe('Section B impact suggestion (FR-PCQI-03)', () => {
  it('maps delta to IMPROVED / NO_CHANGE / DECLINED', () => {
    expect(suggestImpact(5)).toBe('IMPROVED');
    expect(suggestImpact(0)).toBe('NO_CHANGE');
    expect(suggestImpact(-7)).toBe('DECLINED');
    expect(suggestImpact(null)).toBeNull();
  });
});
