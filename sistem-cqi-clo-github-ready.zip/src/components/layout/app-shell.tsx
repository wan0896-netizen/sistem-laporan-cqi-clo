'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Bell, BookOpenCheck, ClipboardCheck, LayoutDashboard, LogOut, Languages, ShieldCheck, Table2, Wrench, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useLang, useT } from '@/lib/i18n';
import { ROLE_LABELS, type Role } from '@/lib/permissions';
import { cn } from '@/lib/utils';

export interface ShellUser {
  id: string;
  fullName: string;
  email: string;
  roles: Role[];
}

interface NotifItem {
  id: string;
  type: string;
  messageBm: string;
  messageEn: string;
  link: string | null;
  read: boolean;
  createdAt: string;
}

export function AppShell({ user, children }: { user: ShellUser; children: React.ReactNode }) {
  const t = useT();
  const { lang, setLang } = useLang();
  const pathname = usePathname();
  const router = useRouter();
  const [notifs, setNotifs] = useState<NotifItem[]>([]);
  const [unread, setUnread] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  const canVerify = user.roles.some((r) => ['kk', 'kpro', 'kj'].includes(r));
  const canDepartment = user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r));
  const isAdmin = user.roles.includes('admin');

  const links = [
    { href: '/dashboard', label: t('dashboard'), icon: LayoutDashboard, show: true },
    { href: '/offerings', label: t('penawaran'), icon: BookOpenCheck, show: true },
    { href: '/verification', label: t('verification'), icon: ClipboardCheck, show: canVerify },
    { href: '/registers/actions', label: t('registerActions'), icon: Table2, show: true },
    { href: '/registers/feedback', label: t('registerFeedback'), icon: Table2, show: true },
    { href: '/admin', label: t('admin'), icon: Settings2, show: isAdmin },
  ].filter((l) => l.show);

  async function loadNotifs() {
    try {
      const res = await fetch('/api/notifications');
      if (!res.ok) return;
      const data = await res.json();
      setNotifs(data.items ?? []);
      setUnread(data.unread ?? 0);
    } catch {
      /* offline-safe */
    }
  }

  useEffect(() => {
    // initial fetch deferred so state updates happen outside the effect body
    const initial = setTimeout(loadNotifs, 0);
    const timer = setInterval(loadNotifs, 15000);
    return () => {
      clearTimeout(initial);
      clearInterval(timer);
    };
  }, []);

  async function markAll() {
    await fetch('/api/notifications', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ all: true }) });
    loadNotifs();
  }

  async function logout() {
    await fetch('/api/auth/login', { method: 'DELETE' });
    router.push('/login');
    router.refresh();
  }

  const primaryRole = user.roles[0];

  return (
    <div className="min-h-screen flex flex-col bg-muted/40">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="mx-auto max-w-7xl px-4 h-14 flex items-center gap-4">
          <Link href="/dashboard" className="flex items-center gap-2 font-semibold text-sm shrink-0">
            <Wrench className="h-5 w-5 text-primary" aria-hidden />
            <span className="hidden md:inline">CQI CLO · JKM POLISAS</span>
          </Link>
          <nav className="flex items-center gap-1 overflow-x-auto" aria-label="Utama">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={cn(
                  'flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm whitespace-nowrap hover:bg-accent',
                  pathname.startsWith(l.href) ? 'bg-primary text-primary-foreground hover:bg-primary' : 'text-foreground',
                )}
              >
                <l.icon className="h-4 w-4" aria-hidden />
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setLang(lang === 'bm' ? 'en' : 'bm')} aria-label="Bahasa">
              <Languages className="h-4 w-4" aria-hidden />
              {lang === 'bm' ? 'EN' : 'BM'}
            </Button>
            <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="relative" aria-label={`${t('notifications')}${unread > 0 ? ` (${unread})` : ''}`}>
                  <Bell className="h-4 w-4" aria-hidden />
                  {unread > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 h-4 min-w-4 rounded-full bg-destructive text-[10px] text-white flex items-center justify-center px-1">
                      {unread > 9 ? '9+' : unread}
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-96 max-h-96 overflow-y-auto">
                <div className="flex items-center justify-between px-2 py-1.5">
                  <p className="text-sm font-medium">{t('notifications')}</p>
                  <Button variant="ghost" size="sm" onClick={markAll} className="h-7 text-xs">{t('markAllRead')}</Button>
                </div>
                {notifs.length === 0 && <p className="px-2 py-4 text-sm text-muted-foreground">{t('noNotifications')}</p>}
                {notifs.map((n) => (
                  <DropdownMenuItem key={n.id} asChild className={cn(!n.read && 'bg-accent/60')}>
                    <Link href={n.link ?? '/dashboard'} className="flex flex-col gap-0.5">
                      <span className="text-sm">{lang === 'bm' ? n.messageBm : n.messageEn}</span>
                      <span className="text-xs text-muted-foreground">{new Date(n.createdAt).toLocaleString('ms-MY')}</span>
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <div className="hidden sm:flex flex-col items-end leading-tight max-w-56">
              <span className="text-sm font-medium truncate">{user.fullName}</span>
              <span className="text-xs text-muted-foreground truncate">{user.roles.map((r) => ROLE_LABELS[r].bm).join(' / ')}</span>
            </div>
            <Button variant="ghost" size="sm" onClick={logout} aria-label={t('logout')}>
              <LogOut className="h-4 w-4" aria-hidden />
            </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6">{children}</main>
      <footer className="mt-auto border-t bg-background">
        <div className="mx-auto max-w-7xl px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>Sistem Laporan CQI Pencapaian CLO · Jabatan Kejuruteraan Mekanikal · POLISAS</span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="h-3.5 w-3.5" aria-hidden />
            Borang Ver. 3.2 · Berkuatkuasa Jan 2026 · Dikemas kini Jun 2026 · PDPA 2010
          </span>
        </div>
      </footer>
    </div>
  );
}
