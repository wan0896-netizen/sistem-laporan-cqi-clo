'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useLang } from '@/lib/i18n';
import { dash, fmtDate, signedDelta } from '@/lib/format';
import { CAUSE_FACTORS } from '@/lib/calculation';
import { ReportStatusBadge, CqiTypeBadge } from '@/components/shared/ui-bits';
import {
  AlertTriangle, Bot, CheckCircle2, ChevronLeft, ChevronRight, FileDown, FileSpreadsheet,
  Loader2, Plus, Printer, Save, Send, Sparkles, Undo2, Upload, X,
} from 'lucide-react';

// ---------- types mirroring the server payload ----------

interface SeriesEntry { sessionId: string; label: string; studentCount: number | null; hasData: boolean; isCurrent: boolean; term: number; year: string }
interface CloComp {
  cloId: string; code: string; statement: string; series: (number | null)[]; delta: number | null; met: boolean | null; declined: boolean; prevLabel: string | null; currentAttainment: number | null; currentStudentCount: number;
}
interface SectionAIssueRow {
  sessionLabel: string; sessionId: string; isCurrent: boolean; hasData: boolean; belowClos: { cloId: string; attainment: number | null }[];
  issueCode: string | null; cloInvolved: string | null; focus: string | null;
}
interface ActionRow {
  id: string; cloId: string | null; description: string; status: string; implementedDate: string | null; impact: string | null; impactText: string | null; unplanned: boolean;
  clo?: { code: string } | null; owner?: { fullName: string } | null; evidenceFiles: { id: string; fileName: string }[]; suggestedImpact: string | null; originReportId: string;
}
interface CqiRowData {
  id?: string; cloId: string | null; cqiType: string; suggestedType: string | null; overrideReason: string | null;
  causeTags: string[]; causeText: string | null; proposal: string; outcome: string | null; ownerId: string | null; targetDate: string | null;
}
interface FeedbackRow { id?: string; topic: string; text: string }
interface VerificationRow { id: string; role: string; decision: string; comment: string | null; signedAt: string; user: { fullName: string } }

interface ReportPayload {
  report: {
    id: string; status: string; version: number; templateVersion: string; overallType: string | null; comparisonNote: string | null;
    sectionAIssues: string; submittedAt: string | null; offeringId: string; amendedFromId: string | null;
    submittedBy?: { fullName: string } | null;
    rows: (CqiRowData & { id: string; owner?: { fullName: string } | null })[];
    feedback: (FeedbackRow & { id: string })[];
    verifications: VerificationRow[];
  };
  header: { courseCode: string; courseName: string; coordinator: string; programme: string; sectionCodes: string; sessionLabel: string; dept: string; institution: string };
  comparison: { series: SeriesEntry[]; comparisons: CloComp[]; belowTarget: CloComp[]; declined: CloComp[]; likeForLike: boolean; cloDifferences: string[] };
  suggestions: { cloId: string; code: string; attainment: number | null; delta: number | null; affected: boolean; suggestedType: string | null; reasonBm: string; reasonEn: string }[];
  sectionBActions: ActionRow[];
  chain: string[];
  requiredRole: string | null;
  lookupLabels: { issue: Record<string, string>; topic: Record<string, string> };
  settings: { cloTarget: number; dropThreshold: number; lowSampleThreshold: number };
  me?: { id: string; roles: string[] };
}

const STEPS_BM = ['Maklumat Kursus', 'Seksyen A', 'Seksyen B', 'Seksyen C', 'Seksyen D', 'Seksyen E'];

export function ReportEditor({ reportId }: { reportId: string }) {
  const router = useRouter();
  const { lang } = useLang();
  const { toast } = useToast();
  const [data, setData] = useState<ReportPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [aiBusy, setAiBusy] = useState<string | null>(null);
  const [qualityIssues, setQualityIssues] = useState<{ row: number; code: string; bm: string; en: string }[]>([]);
  const [preview, setPreview] = useState(false);

  // editable state
  const [issues, setIssues] = useState<SectionAIssueRow[]>([]);
  const [comparisonNote, setComparisonNote] = useState('');
  const [actionEdits, setActionEdits] = useState<Record<string, { status: string; implementedDate: string | null; impact: string | null; impactText: string | null }>>({});
  const [newActions, setNewActions] = useState<Omit<ActionRow, 'id' | 'evidenceFiles' | 'originReportId' | 'suggestedImpact' | 'clo'>[]>([]);
  const [rows, setRows] = useState<CqiRowData[]>([]);
  const [feedback, setFeedback] = useState<FeedbackRow[]>([]);
  const [aiSuggestion, setAiSuggestion] = useState<{ rowKey: string; field: 'punca' | 'cadangan'; content: string } | null>(null);
  const [uploadActionId, setUploadActionId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [verifyDialog, setVerifyDialog] = useState<'VERIFIED' | 'RETURNED' | null>(null);
  const [verifyComment, setVerifyComment] = useState('');
  const [me, setMe] = useState<{ id: string; roles: string[] } | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [res, meRes] = await Promise.all([fetch(`/api/cqi/report?reportId=${reportId}`), fetch('/api/auth/me')]);
        if (!res.ok) throw new Error((await res.json()).error ?? 'Gagal memuatkan laporan');
        const payload: ReportPayload = await res.json();
        setData(payload);
        setIssues(JSON.parse(payload.report.sectionAIssues || '[]'));
        setComparisonNote(payload.report.comparisonNote ?? '');
        setRows(payload.report.rows.map((r) => ({ ...r, causeTags: JSON.parse((r.causeTags as unknown as string) || '[]') })));
        setFeedback(payload.report.feedback.map((f) => ({ id: f.id, topic: f.topic, text: f.text })));
        setActionEdits(Object.fromEntries(payload.sectionBActions.map((a) => [a.id, { status: a.status, implementedDate: a.implementedDate?.slice(0, 10) ?? null, impact: a.impact, impactText: a.impactText }])));
        setMe((await meRes.json()).user);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Kesalahan');
      }
    })();
  }, [reportId]);

  const editable = data ? ['DRAFT', 'RETURNED'].includes(data.report.status) : false;
  const isCoordinator = !!me && (me.roles.includes('coordinator') || me.roles.includes('admin'));
  const canVerifyNow = !!me && data?.report.status === 'UNDER_VERIFICATION' && data?.requiredRole !== null && me.roles.includes((data?.requiredRole ?? '').toLowerCase());

  const allIssues = useMemo(() => JSON.stringify({ issues }), [issues]);
  void allIssues;

  async function save(silent = false) {
    if (!data) return;
    setSaving(true);
    try {
      const res = await fetch('/api/cqi/report/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reportId,
          sectionAIssues: issues,
          comparisonNote,
          actionUpdates: Object.entries(actionEdits).map(([id, v]) => ({ id, ...v })),
          newActions: newActions.map((a) => ({ ...a, status: 'IMPLEMENTED' })),
          rows,
          feedback,
        }),
      });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: 'Ralat simpan', description: result.error ?? '', variant: 'destructive' });
        return;
      }
      if (!silent) toast({ title: 'Berjaya disimpan' });
    } finally {
      setSaving(false);
    }
  }

  async function runQualityCheck() {
    const res = await fetch('/api/ai/quality-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: rows.map((r) => ({ cqiType: r.cqiType, proposal: r.proposal, outcome: r.outcome, ownerId: r.ownerId, targetDate: r.targetDate })) }),
    });
    const result = await res.json();
    setQualityIssues(result.issues ?? []);
  }

  async function aiDraft(rowKey: string, field: 'punca' | 'cadangan', row: CqiRowData) {
    if (!data) return;
    setAiBusy(`${rowKey}-${field}`);
    try {
      const res = await fetch('/api/ai/cqi-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ offeringId: data.report.offeringId, feature: field === 'punca' ? 'punca' : 'cadangan', cqiType: row.cqiType, factors: row.causeTags }),
      });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: result.message ?? 'AI tidak tersedia', description: result.error, variant: 'destructive' });
        return;
      }
      const label = result.label ?? 'AI suggestion';
      if (field === 'punca') {
        const hypotheses = (result.data?.hypotheses ?? []) as { factor: string; bm: string; en: string }[];
        const text = hypotheses.map((h) => `[${CAUSE_FACTORS.find((f) => f.code === h.factor)?.bm ?? h.factor}] ${h.bm}`).join('\n');
        setAiSuggestion({ rowKey, field, content: `${label}:\n${text}` });
      } else {
        const proposals = (result.data?.proposals ?? []) as { title: string; bm: string; en: string; outcome: string }[];
        const text = proposals.map((p) => `${p.title}: ${p.bm}\nHasil terukur / outcome: ${p.outcome}`).join('\n\n');
        setAiSuggestion({ rowKey, field, content: `${label}:\n${text}` });
      }
    } finally {
      setAiBusy(null);
    }
  }

  function applyAi(rowKey: string, field: 'punca' | 'cadangan') {
    if (!aiSuggestion) return;
    const text = aiSuggestion.content.replace(/^AI suggestion:\n/, '');
    if (field === 'punca') {
      setRows((prev) => prev.map((r, i) => (String(i) === rowKey ? { ...r, causeText: `${r.causeText ? r.causeText + ' ' : ''}${text}` } : r)));
    } else {
      setRows((prev) => prev.map((r, i) => (String(i) === rowKey ? { ...r, proposal: text } : r)));
    }
    setAiSuggestion(null);
  }

  async function submitReport() {
    if (!window.confirm(lang === 'bm'
      ? 'Hantar laporan untuk pengesahan? Angka pencapaian akan dikunci sebagai snapshot tetap dan laporan tidak boleh disunting lagi.'
      : 'Submit report for verification? Attainment figures will be locked as an immutable snapshot and the report becomes read-only.')) return;
    setSubmitting(true);
    try {
      await save(true);
      const res = await fetch('/api/cqi/submit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reportId }) });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: 'Penghantaran gagal', description: Array.isArray(result.errors) ? result.errors.join('\n') : result.error, variant: 'destructive' });
        return;
      }
      toast({ title: 'Laporan dihantar', description: 'Pemberitahuan dihantar kepada pengesah pertama.' });
      router.refresh();
      window.location.reload();
    } finally {
      setSubmitting(false);
    }
  }

  async function verify(decision: 'VERIFIED' | 'RETURNED') {
    setVerifyDialog(null);
    if (decision === 'VERIFIED' && !window.confirm(lang === 'bm' ? 'Sahkan laporan ini (Disahkan)?' : 'Verify this report?')) return;
    const res = await fetch('/api/cqi/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reportId, decision, comment: verifyComment }) });
    const result = await res.json();
    if (!res.ok) {
      toast({ title: 'Gagal', description: result.error, variant: 'destructive' });
      return;
    }
    toast({ title: decision === 'VERIFIED' ? 'Laporan disahkan' : 'Laporan dipulangkan' });
    setVerifyComment('');
    window.location.reload();
  }

  async function amend() {
    if (!window.confirm(lang === 'bm' ? 'Cipta versi pindaan baharu?' : 'Create a new amended version?')) return;
    const res = await fetch('/api/cqi/amend', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reportId }) });
    const result = await res.json();
    if (!res.ok) {
      toast({ title: 'Gagal', description: result.error, variant: 'destructive' });
      return;
    }
    router.push(`/reports/${result.newReportId}`);
  }

  async function uploadEvidence(file: File) {
    if (!uploadActionId) return;
    setUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('actionId', uploadActionId);
      const res = await fetch('/api/evidence/upload', { method: 'POST', body: form });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: 'Muat naik gagal', description: result.error, variant: 'destructive' });
        return;
      }
      toast({ title: 'Bukti dimuat naik', description: result.fileName });
      // refresh evidence list
      const fresh = await fetch(`/api/cqi/report?reportId=${reportId}`);
      if (fresh.ok) {
        const payload: ReportPayload = await fresh.json();
        setData(payload);
        setActionEdits(Object.fromEntries(payload.sectionBActions.map((a) => [a.id, { status: a.status, implementedDate: a.implementedDate?.slice(0, 10) ?? null, impact: a.impact, impactText: a.impactText }])));
      }
    } finally {
      setUploading(false);
      setUploadActionId(null);
    }
  }

  if (error) return <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>;
  if (!data) return <div className="space-y-3"><div className="h-10 w-96 animate-pulse rounded bg-muted" /><div className="h-96 w-full animate-pulse rounded bg-muted" /></div>;

  const { report, header, comparison, suggestions, settings, lookupLabels } = data;
  const issueLookups = Object.entries(lookupLabels.issue);

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="text-xl">Laporan CQI: {header.courseCode}</CardTitle>
              <CardDescription>{header.courseName} · {header.programme} · {header.sessionLabel} · Seksyen {header.sectionCodes}</CardDescription>
              <CardDescription>
                Penyelaras: {header.coordinator} · Versi laporan: v{report.version} · Templat borang: Ver. {report.templateVersion}
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <ReportStatusBadge status={report.status} />
              <CqiTypeBadge type={report.overallType} />
              <a href={`/api/reports/pdf?reportId=${reportId}`}><Button variant="outline" size="sm"><FileDown className="h-4 w-4" /> PDF Ver. 3.2</Button></a>
              <a href={`/api/reports/excel?reportId=${reportId}`}><Button variant="outline" size="sm"><FileSpreadsheet className="h-4 w-4" /> Excel</Button></a>
              <Button variant="outline" size="sm" onClick={() => setPreview(true)}><Printer className="h-4 w-4" /> Pratonton Cetak</Button>
            </div>
          </div>
        </CardHeader>
        {report.status === 'RETURNED' && report.verifications.some((v) => v.decision === 'RETURNED') && (
          <CardContent>
            <Alert className="border-amber-300 bg-amber-50">
              <AlertTitle className="text-amber-900">Laporan dipulangkan - betulkan dan hantar semula</AlertTitle>
              <AlertDescription className="text-amber-900">
                {report.verifications.filter((v) => v.decision === 'RETURNED').map((v) => (
                  <p key={v.id} className="text-xs">{v.role}: {v.comment}</p>
                ))}
              </AlertDescription>
            </Alert>
          </CardContent>
        )}
      </Card>

      {/* Stepper */}
      <div className="flex flex-wrap items-center gap-1.5">
        {STEPS_BM.map((s, i) => (
          <button
            key={s}
            onClick={() => setStep(i)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${i === step ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-accent'}`}
            aria-current={i === step ? 'step' : undefined}
          >
            {i + 1}. {s}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2">
          {editable && (
            <Button variant="outline" size="sm" onClick={() => save()} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Simpan
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={() => setStep(Math.max(0, step - 1))} disabled={step === 0}><ChevronLeft className="h-4 w-4" /> Kembali</Button>
          <Button variant="ghost" size="sm" onClick={() => setStep(Math.min(5, step + 1))} disabled={step === 5}>Seterusnya <ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>

      {/* STEP 0: Header */}
      {step === 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Maklumat Kursus (dijana automatik dari master data)</CardTitle></CardHeader>
          <CardContent>
            <dl className="grid gap-x-6 gap-y-2 sm:grid-cols-2 text-sm">
              <div><dt className="text-muted-foreground">Kod & Nama Kursus</dt><dd className="font-medium">{header.courseCode} - {header.courseName}</dd></div>
              <div><dt className="text-muted-foreground">Nama Penyelaras Kursus</dt><dd className="font-medium">{header.coordinator}</dd></div>
              <div><dt className="text-muted-foreground">Program</dt><dd className="font-medium">{header.programme}</dd></div>
              <div><dt className="text-muted-foreground">Seksyen/Kelas</dt><dd className="font-medium">{header.sectionCodes}</dd></div>
              <div><dt className="text-muted-foreground">Sesi</dt><dd className="font-medium">{header.sessionLabel}</dd></div>
              <div><dt className="text-muted-foreground">Status</dt><dd><ReportStatusBadge status={report.status} /></dd></div>
            </dl>
          </CardContent>
        </Card>
      )}

      {/* STEP 1: Section A */}
      {step === 1 && (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Seksyen A: Laporan Analisis Pencapaian CLO</CardTitle>
              <CardDescription>Sasaran {settings.cloTarget}% · perbandingan sesi semasa + 2 sesi terdahulu · &quot;-&quot; untuk sesi tanpa data</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-56">CLO</TableHead>
                    {comparison.series.map((s) => (
                      <TableHead key={s.sessionId} className="text-center min-w-32">
                        {s.label}
                        <p className="text-xs font-normal text-muted-foreground">Bil. pelajar: {dash(s.studentCount)}</p>
                      </TableHead>
                    ))}
                    <TableHead className="text-center">Perubahan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {comparison.comparisons.map((c) => (
                    <TableRow key={c.cloId}>
                      <TableCell>
                        <span className="font-medium">{c.code}</span>
                        <p className="text-xs text-muted-foreground">{c.statement}</p>
                      </TableCell>
                      {c.series.map((v, si) => (
                        <TableCell key={si} className="text-center">
                          <span className={si === 0 && v !== null && v < settings.cloTarget ? 'font-bold text-red-700' : ''}>{v === null ? '-' : `${v}%`}</span>
                        </TableCell>
                      ))}
                      <TableCell className="text-center text-sm">{signedDelta(c.delta)}{c.delta !== null ? ' m.p.' : ''}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {!comparison.likeForLike && (
                <div className="mt-3 space-y-2">
                  <Alert className="border-amber-300 bg-amber-50">
                    <AlertTriangle className="h-4 w-4 text-amber-700" />
                    <AlertTitle className="text-amber-900">Perbandingan bukan like-for-like (FR-CLO-09)</AlertTitle>
                    <AlertDescription className="text-amber-900">
                      <ul className="list-disc pl-4 text-xs">
                        {comparison.cloDifferences.map((d, i) => <li key={i}>{d}</li>)}
                      </ul>
                    </AlertDescription>
                  </Alert>
                  <div>
                    <Label htmlFor="comparisonNote">Nota perbandingan (wajib sebelum penghantaran)</Label>
                    <Textarea id="comparisonNote" value={comparisonNote} onChange={(e) => setComparisonNote(e.target.value)} disabled={!editable} placeholder="Terangkan perubahan definisi CLO antara sesi..." />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Rekod Pencapaian CLO Kurang {settings.cloTarget}% Mengikut Sesi</CardTitle>
              <CardDescription>Sistem mengesan CLO di bawah sasaran; penyelaras memilih Isu Pencapaian CLO dan CLO Terlibat (FR-CLO-06/07)</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sesi</TableHead>
                    <TableHead>Isu Pencapaian CLO</TableHead>
                    <TableHead>CLO Terlibat</TableHead>
                    <TableHead className="min-w-56">Tumpuan CQI {lang === 'bm' ? '(sesi semasa)' : '(current session)'}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {issues.map((row, i) => {
                    const belowCodes = row.belowClos.map((b) => comparison.comparisons.find((c) => c.cloId === b.cloId)?.code ?? b.cloId);
                    return (
                      <TableRow key={i}>
                        <TableCell className="font-medium">{row.sessionLabel}</TableCell>
                        <TableCell>
                          {!row.hasData || row.belowClos.length === 0 ? (
                            <span className="text-muted-foreground">Tiada</span>
                          ) : editable && row.isCurrent ? (
                            <Select
                              value={row.issueCode ?? ''}
                              onValueChange={(v) => setIssues((prev) => prev.map((r, ri) => (ri === i ? { ...r, issueCode: v || null } : r)))}
                            >
                              <SelectTrigger className="w-full" aria-label="Isu Pencapaian CLO"><SelectValue placeholder="Sila Pilih" /></SelectTrigger>
                              <SelectContent>
                                {issueLookups.map(([code, label]) => <SelectItem key={code} value={code}>{label}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span>{row.issueCode ? lookupLabels.issue[row.issueCode] ?? row.issueCode : <span className="text-muted-foreground">Sila Pilih</span>}</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {!row.hasData || row.belowClos.length === 0 ? (
                            <span className="text-muted-foreground">Tiada</span>
                          ) : editable && row.isCurrent ? (
                            <Select
                              value={row.cloInvolved ?? ''}
                              onValueChange={(v) => setIssues((prev) => prev.map((r, ri) => (ri === i ? { ...r, cloInvolved: v || null } : r)))}
                            >
                              <SelectTrigger className="w-full" aria-label="CLO Terlibat"><SelectValue placeholder="Sila Pilih" /></SelectTrigger>
                              <SelectContent>
                                {belowCodes.map((code, ci) => <SelectItem key={ci} value={code}>{code}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span>{belowCodes.join(', ')}</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {row.isCurrent && row.belowClos.length > 0 ? (
                            <Textarea
                              value={row.focus ?? ''}
                              onChange={(e) => setIssues((prev) => prev.map((r, ri) => (ri === i ? { ...r, focus: e.target.value } : r)))}
                              disabled={!editable}
                              className="min-h-16"
                              placeholder="Tumpuan CQI bagi sesi semasa..."
                            />
                          ) : (
                            <span className="text-muted-foreground">{row.hasData && row.belowClos.length > 0 ? '(sesi lepas)' : '-'}</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      {/* STEP 2: Section B */}
      {step === 2 && (
        <Card>
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-2 space-y-0">
            <div>
              <CardTitle className="text-base">Seksyen B: Laporan/Status Pelaksanaan CQI Terdahulu</CardTitle>
              <CardDescription>Tindakan dari laporan sesi lepas dibawa ke hadapan automatik (FR-PCQI-01); kemaskini status, tarikh, impak dan bukti (FR-PCQI-02)</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => setNewActions((prev) => [...prev, { cloId: null, description: '', status: 'IMPLEMENTED', implementedDate: new Date().toISOString().slice(0, 10), impact: null, impactText: null, unplanned: true, ownerId: me?.id ?? null, targetDate: null }])} disabled={!editable}>
              <Plus className="h-4 w-4" /> Tambah tindakan tidak dirancang
            </Button>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8">Bil.</TableHead>
                  <TableHead className="min-w-48">Tindakan/Aktiviti</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tarikh Pelaksanaan</TableHead>
                  <TableHead>Impak Terhadap Pencapaian CLO</TableHead>
                  <TableHead className="min-w-40">Dokumen/Bukti Pelaksanaan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.sectionBActions.map((a, i) => {
                  const edit = actionEdits[a.id] ?? { status: a.status, implementedDate: a.implementedDate?.slice(0, 10) ?? null, impact: a.impact, impactText: a.impactText };
                  const cloCode = a.clo?.code ?? comparison.comparisons.find((c) => c.cloId === a.cloId)?.code ?? null;
                  return (
                    <TableRow key={a.id}>
                      <TableCell>{i + 1}</TableCell>
                      <TableCell>
                        <span className="font-medium">{a.description}</span>
                        {a.unplanned && <Badge variant="outline" className="ml-1 text-[10px]">tambahan</Badge>}
                        {cloCode && <Badge variant="outline" className="ml-1 text-[10px]">{cloCode}</Badge>}
                        {a.suggestedImpact && (
                          <p className="text-[10px] text-muted-foreground">Saranan impak sistem (FR-PCQI-03): {a.suggestedImpact === 'IMPROVED' ? 'Meningkat' : a.suggestedImpact === 'DECLINED' ? 'Menurun' : 'Tiada perubahan'}</p>
                        )}
                      </TableCell>
                      <TableCell>
                        <Select value={edit.status} onValueChange={(v) => setActionEdits((prev) => ({ ...prev, [a.id]: { ...edit, status: v } }))} disabled={!editable}>
                          <SelectTrigger className="w-36" aria-label="Status"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="PLANNED">Dirancang</SelectItem>
                            <SelectItem value="IMPLEMENTED">Dilaksanakan</SelectItem>
                            <SelectItem value="PARTIAL">Sebahagian</SelectItem>
                            <SelectItem value="NOT_IMPLEMENTED">Tidak dilaksanakan</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input type="date" value={edit.implementedDate ?? ''} onChange={(e) => setActionEdits((prev) => ({ ...prev, [a.id]: { ...edit, implementedDate: e.target.value || null } }))} disabled={!editable} className="w-36" />
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <Select value={edit.impact ?? ''} onValueChange={(v) => setActionEdits((prev) => ({ ...prev, [a.id]: { ...edit, impact: v || null } }))} disabled={!editable}>
                            <SelectTrigger className="w-44" aria-label="Impak"><SelectValue placeholder="Impak..." /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="IMPROVED">Meningkat / Improved</SelectItem>
                              <SelectItem value="NO_CHANGE">Tiada perubahan / No change</SelectItem>
                              <SelectItem value="DECLINED">Menurun / Declined</SelectItem>
                            </SelectContent>
                          </Select>
                          <Input value={edit.impactText ?? ''} onChange={(e) => setActionEdits((prev) => ({ ...prev, [a.id]: { ...edit, impactText: e.target.value } }))} disabled={!editable} placeholder="Huraian impak..." className="h-8" />
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {a.evidenceFiles.map((e) => (
                            <a key={e.id} href={`/api/evidence/${e.id}`} target="_blank" className="block text-xs text-primary hover:underline">{e.fileName}</a>
                          ))}
                          {editable && (
                            <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => setUploadActionId(a.id)} disabled={uploading}>
                              <Upload className="h-3 w-3" /> Muat naik bukti
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {newActions.map((a, i) => (
                  <TableRow key={`new-${i}`}>
                    <TableCell>{data.sectionBActions.length + i + 1}</TableCell>
                    <TableCell>
                      <Textarea value={a.description} onChange={(e) => setNewActions((prev) => prev.map((x, xi) => (xi === i ? { ...x, description: e.target.value } : x)))} placeholder="Tindakan/Aktiviti..." className="min-h-16" />
                      <div className="mt-1">
                        <Select value={a.cloId ?? ''} onValueChange={(v) => setNewActions((prev) => prev.map((x, xi) => (xi === i ? { ...x, cloId: v || null } : x)))}>
                          <SelectTrigger className="w-40" aria-label="CLO"><SelectValue placeholder="CLO (pilihan)" /></SelectTrigger>
                          <SelectContent>
                            {comparison.comparisons.map((c) => <SelectItem key={c.cloId} value={c.cloId}>{c.code}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    </TableCell>
                    <TableCell><Badge variant="outline">IMPLEMENTED</Badge></TableCell>
                    <TableCell>
                      <Input type="date" value={a.implementedDate ?? ''} onChange={(e) => setNewActions((prev) => prev.map((x, xi) => (xi === i ? { ...x, implementedDate: e.target.value || null } : x)))} className="w-36" />
                    </TableCell>
                    <TableCell>
                      <Select value={a.impact ?? ''} onValueChange={(v) => setNewActions((prev) => prev.map((x, xi) => (xi === i ? { ...x, impact: v || null } : x)))}>
                        <SelectTrigger className="w-44" aria-label="Impak"><SelectValue placeholder="Impak..." /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="IMPROVED">Meningkat</SelectItem>
                          <SelectItem value="NO_CHANGE">Tiada perubahan</SelectItem>
                          <SelectItem value="DECLINED">Menurun</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">akan disimpan bersama laporan</TableCell>
                  </TableRow>
                ))}
                {data.sectionBActions.length === 0 && newActions.length === 0 && (
                  <TableRow><TableCell colSpan={6} className="text-muted-foreground">Tiada tindakan CQI terdahulu / No previous CQI actions</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* STEP 3: Section C */}
      {step === 3 && (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Seksyen C: Cadangan Pelaksanaan CQI (Sesi Akan Datang)</CardTitle>
              <CardDescription>
                Baris dicipta automatik untuk CLO di bawah sasaran / menurun ≥ {settings.dropThreshold} mata (FR-CQI-01). Jenis CQI disarankan sistem (8.3) - boleh diubah dengan alasan.
                Cadangan CQI WAJIB di setiap laporan walaupun semua CLO mencapai sasaran (FR-CQI-04); Punca WAJIB untuk baris Pembetulan/Pencegahan (FR-CQI-05).
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {rows.map((row, i) => {
                const sug = suggestions.find((s) => s.cloId === row.cloId);
                const cloCode = comparison.comparisons.find((c) => c.cloId === row.cloId)?.code;
                return (
                  <div key={row.id ?? `row-${i}`} className="rounded-lg border p-4 space-y-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold">Bil. {i + 1}</span>
                      {cloCode && <Badge variant="outline">{cloCode}{sug?.attainment !== null && sug?.attainment !== undefined ? ` (${sug.attainment}%${row.cloId && sug?.delta !== null ? `, ${signedDelta(sug.delta)} m.p.` : ''})` : ''}</Badge>}
                      <CqiTypeBadge type={row.cqiType} />
                      {row.suggestedType && row.cqiType !== row.suggestedType && (
                        <Badge variant="outline" className="bg-amber-50 text-amber-900 border-amber-300">saranan sistem: {row.suggestedType}</Badge>
                      )}
                      <Button variant="ghost" size="sm" className="text-destructive ml-auto" onClick={() => setRows((prev) => prev.filter((_, ri) => ri !== i))} disabled={!editable}><X className="h-4 w-4" /></Button>
                    </div>
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="space-y-1">
                        <Label>Jenis CQI</Label>
                        <Select value={row.cqiType} onValueChange={(v) => setRows((prev) => prev.map((r, ri) => (ri === i ? { ...r, cqiType: v } : r)))} disabled={!editable}>
                          <SelectTrigger aria-label="Jenis CQI"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CORRECTIVE">Pembetulan (Corrective)</SelectItem>
                            <SelectItem value="PREVENTIVE">Pencegahan (Preventive)</SelectItem>
                            <SelectItem value="ENHANCEMENT">Penambahbaikan/Pemantapan (Enhancement)</SelectItem>
                          </SelectContent>
                        </Select>
                        {sug && <p className="text-[11px] text-muted-foreground">{lang === 'bm' ? sug.reasonBm : sug.reasonEn}</p>}
                        {row.cqiType !== row.suggestedType && (
                          <Input value={row.overrideReason ?? ''} onChange={(e) => setRows((prev) => prev.map((r, ri) => (ri === i ? { ...r, overrideReason: e.target.value } : r)))} placeholder="Alasan mengubah saranan sistem (wajib)" disabled={!editable} />
                        )}
                      </div>
                      <div className="space-y-1">
                        <Label>Punca - enam faktor (pilih semua berkaitan)</Label>
                        <div className="flex flex-wrap gap-2">
                          {CAUSE_FACTORS.map((f) => {
                            const checked = row.causeTags.includes(f.code);
                            return (
                              <button
                                key={f.code}
                                type="button"
                                disabled={!editable}
                                onClick={() => setRows((prev) => prev.map((r, ri) => (ri === i ? { ...r, causeTags: checked ? r.causeTags.filter((t) => t !== f.code) : [...r.causeTags, f.code] } : r)))}
                                className={`rounded-full border px-2.5 py-1 text-xs transition-colors ${checked ? 'bg-primary text-primary-foreground border-primary' : 'bg-background hover:bg-accent'}`}
                                aria-pressed={checked}
                              >
                                {f.bm}
                              </button>
                            );
                          })}
                        </div>
                        <Textarea value={row.causeText ?? ''} onChange={(e) => setRows((prev) => prev.map((r, ri) => (ri === i ? { ...r, causeText: e.target.value } : r)))} disabled={!editable} placeholder="Huraian punca..." className="min-h-16" />
                        <Button variant="outline" size="sm" onClick={() => aiDraft(String(i), 'punca', row)} disabled={!editable || aiBusy !== null}>
                          {aiBusy === `${i}-punca` ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />} Draf AI (Punca)
                        </Button>
                      </div>
                      <div className="space-y-1">
                        <Label>Cadangan CQI (sesi akan datang) - wajib</Label>
                        <Textarea value={row.proposal} onChange={(e) => setRows((prev) => prev.map((r, ri) => (ri === i ? { ...r, proposal: e.target.value } : r)))} disabled={!editable} placeholder="Cadangan tindakan untuk sesi akan datang..." className="min-h-20" />
                        <Button variant="outline" size="sm" onClick={() => aiDraft(String(i), 'cadangan', row)} disabled={!editable || aiBusy !== null}>
                          {aiBusy === `${i}-cadangan` ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />} Draf AI (Cadangan)
                        </Button>
                      </div>
                      <div className="space-y-2">
                        <Label>Pelaksana, tarikh sasaran & hasil terukor (FR-CQI-07)</Label>
                        <Input value={row.outcome ?? ''} onChange={(e) => setRows((prev) => prev.map((r, ri) => (ri === i ? { ...r, outcome: e.target.value } : r)))} disabled={!editable} placeholder="Hasil terukur, cth: ≥80% pelajar mencapai paras CLO" />
                        <Input type="date" value={row.targetDate ?? ''} onChange={(e) => setRows((prev) => prev.map((r, ri) => (ri === i ? { ...r, targetDate: e.target.value || null } : r)))} disabled={!editable} aria-label="Tarikh sasaran" />
                      </div>
                    </div>
                  </div>
                );
              })}
              <Button variant="outline" onClick={() => setRows((prev) => [...prev, { cloId: null, cqiType: 'ENHANCEMENT', suggestedType: 'ENHANCEMENT', overrideReason: null, causeTags: [], causeText: '', proposal: '', outcome: '', ownerId: null, targetDate: null }])} disabled={!editable}>
                <Plus className="h-4 w-4" /> Tambah baris CQI
              </Button>
              <div className="flex flex-wrap items-center gap-2">
                <Button variant="outline" onClick={runQualityCheck} size="sm"><Bot className="h-4 w-4" /> Semakan kualiti (AI-03)</Button>
                {qualityIssues.length > 0 && (
                  <Alert className="flex-1 border-sky-300 bg-sky-50">
                    <AlertDescription className="text-sky-900 text-xs">
                      <p className="font-medium">Semakan kualiti (advisory sahaja):</p>
                      <ul className="list-disc pl-4">
                        {qualityIssues.map((q, i) => <li key={i}>Baris {q.row + 1}: {lang === 'bm' ? q.bm : q.en}</li>)}
                      </ul>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* STEP 4: Section D */}
      {step === 4 && (
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base">Seksyen D: Maklumbalas Kurikulum</CardTitle>
              <CardDescription>Perkara daripada senarai borang (CLO, Pemetaan CLO, PLO, Kaedah PdP & Pentaksiran, SLT, Rujukan, Silibus, AST)</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => setFeedback((prev) => [...prev, { topic: 'CLO', text: '' }])} disabled={!editable}><Plus className="h-4 w-4" /> Tambah baris</Button>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8">Bil.</TableHead>
                  <TableHead className="w-56">Perkara</TableHead>
                  <TableHead>Maklumbalas/Cadangan</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {feedback.map((f, i) => (
                  <TableRow key={f.id ?? `fb-${i}`}>
                    <TableCell>{i + 1}</TableCell>
                    <TableCell>
                      <Select value={f.topic} onValueChange={(v) => setFeedback((prev) => prev.map((x, xi) => (xi === i ? { ...x, topic: v } : x)))} disabled={!editable}>
                        <SelectTrigger aria-label="Perkara"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {Object.entries(lookupLabels.topic).map(([code, label]) => <SelectItem key={code} value={code}>{label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Textarea value={f.text} onChange={(e) => setFeedback((prev) => prev.map((x, xi) => (xi === i ? { ...x, text: e.target.value } : x)))} disabled={!editable} className="min-h-16" placeholder="Maklumbalas/Cadangan..." />
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" className="text-destructive" onClick={() => setFeedback((prev) => prev.filter((_, xi) => xi !== i))} disabled={!editable}><X className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
                {feedback.length === 0 && <TableRow><TableCell colSpan={4} className="text-muted-foreground">Tiada maklumbalas kurikulum lagi.</TableCell></TableRow>}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* STEP 5: Section E */}
      {step === 5 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Seksyen E: Pengesahan</CardTitle>
            <CardDescription>
              Disediakan oleh direkod automatik semasa penghantaran (FR-WF-02); rantai pengesahan program ini: {data.chain.join(' → ')} (boleh dikonfigur per program, FR-WF-03)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-lg border p-4">
                <p className="text-sm font-semibold">Disediakan oleh</p>
                <p className="mt-2 text-sm">{report.submittedBy?.fullName ?? header.coordinator}</p>
                <p className="text-xs text-muted-foreground">Penyelaras Kursus</p>
                <p className="text-xs text-muted-foreground">Tarikh: {fmtDate(report.submittedAt)}</p>
              </div>
              <div className="rounded-lg border p-4">
                <p className="text-sm font-semibold">Disahkan oleh</p>
                {report.verifications.length === 0 ? (
                  <p className="mt-2 text-sm text-muted-foreground">(menunggu pengesahan)</p>
                ) : (
                  <ul className="mt-2 space-y-1.5 text-sm">
                    {report.verifications.map((v) => (
                      <li key={v.id}>
                        <span className="font-medium">{v.user.fullName}</span> ({v.role}) - {v.decision === 'VERIFIED' ? 'Disahkan' : 'Dipulangkan'} - {fmtDate(v.signedAt)}
                        {v.comment && <p className="text-xs text-muted-foreground">Ulasan: {v.comment}</p>}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            <div className="rounded-lg border p-4 space-y-2">
              <p className="text-sm font-semibold">Rantai pengesahan</p>
              <div className="flex flex-wrap items-center gap-2 text-sm">
                {data.chain.map((role, i) => {
                  const v = report.verifications.find((x) => x.role === role && x.decision === 'VERIFIED');
                  return (
                    <span key={role} className="inline-flex items-center gap-1.5">
                      {i > 0 && <span className="text-muted-foreground">→</span>}
                      <Badge variant="outline" className={v ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : role === data.requiredRole && report.status === 'UNDER_VERIFICATION' ? 'bg-sky-50 text-sky-900 border-sky-300' : ''}>
                        {v ? <CheckCircle2 className="mr-1 inline h-3 w-3" /> : null}
                        {role}{v ? ' ✓' : ''}
                      </Badge>
                    </span>
                  );
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-2">
              {editable && isCoordinator && (
                <Button onClick={submitReport} disabled={submitting}>
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  {report.status === 'RETURNED' ? 'Hantar Semula' : 'Hantar Laporan'}
                </Button>
              )}
              {report.status === 'UNDER_VERIFICATION' && canVerifyNow && (
                <>
                  <Button onClick={() => setVerifyDialog('VERIFIED')} className="bg-emerald-700 hover:bg-emerald-800"><CheckCircle2 className="h-4 w-4" /> Sahkan (Disahkan)</Button>
                  <Button variant="destructive" onClick={() => setVerifyDialog('RETURNED')}><Undo2 className="h-4 w-4" /> Pulangkan dengan Ulasan</Button>
                </>
              )}
              {['VERIFIED', 'CLOSED'].includes(report.status) && isCoordinator && (
                <Button variant="outline" onClick={amend}><Plus className="h-4 w-4" /> Pinda (versi baharu)</Button>
              )}
              <Link href={`/offerings/${report.offeringId}`} className="ml-auto"><Button variant="ghost">Kembali ke penawaran</Button></Link>
            </div>
            {report.status === 'UNDER_VERIFICATION' && !canVerifyNow && (
              <p className="text-xs text-muted-foreground">Menunggu pengesahan {data.requiredRole}. Peranan lain boleh melihat sahaja.</p>
            )}
          </CardContent>
        </Card>
      )}

      {/* AI suggestion dialog (AI-01/02/04: labelled, human edit required) */}
      <Dialog open={!!aiSuggestion} onOpenChange={(open) => !open && setAiSuggestion(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Sparkles className="h-4 w-4" /> Cadangan AI</DialogTitle>
            <DialogDescription>Wajib disemak dan disunting oleh pensyarah/penyelaras sebelum diterima (never auto-submitted).</DialogDescription>
          </DialogHeader>
          <pre className="whitespace-pre-wrap rounded-md border bg-muted/40 p-3 text-xs max-h-72 overflow-y-auto">{aiSuggestion?.content}</pre>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAiSuggestion(null)}>Batal</Button>
            <Button onClick={() => aiSuggestion && applyAi(aiSuggestion.rowKey, aiSuggestion.field)}>Terima &amp; masukkan (boleh disunting)</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Evidence upload dialog */}
      <Dialog open={!!uploadActionId} onOpenChange={(open) => !open && setUploadActionId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Muat naik bukti pelaksanaan</DialogTitle>
            <DialogDescription>PDF/JPG/PNG/DOCX, maksimum 5MB (FR-PCQI-05)</DialogDescription>
          </DialogHeader>
          <Input
            type="file"
            accept=".pdf,.jpg,.jpeg,.png,.docx"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) uploadEvidence(f);
            }}
          />
          {uploading && <p className="text-xs text-muted-foreground">Sedang memuat naik...</p>}
        </DialogContent>
      </Dialog>

      {/* Verify comment dialog (FR-WF-04 Ulasan) */}
      <Dialog open={!!verifyDialog} onOpenChange={(open) => !open && setVerifyDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{verifyDialog === 'VERIFIED' ? 'Sahkan laporan' : 'Pulangkan laporan'}</DialogTitle>
            <DialogDescription>{verifyDialog === 'RETURNED' ? 'Ulasan wajib apabila memulangkan laporan.' : 'Ulasan (pilihan) akan direkod sebagai sebahagian Seksyen E.'}</DialogDescription>
          </DialogHeader>
          <Textarea value={verifyComment} onChange={(e) => setVerifyComment(e.target.value)} placeholder="Ulasan / Comments..." className="min-h-24" />
          <DialogFooter>
            <Button variant="outline" onClick={() => setVerifyDialog(null)}>Batal</Button>
            <Button
              variant={verifyDialog === 'RETURNED' ? 'destructive' : 'default'}
              disabled={verifyDialog === 'RETURNED' && !verifyComment.trim()}
              onClick={() => verifyDialog && verify(verifyDialog)}
            >
              {verifyDialog === 'VERIFIED' ? 'Sahkan' : 'Pulangkan'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Print preview overlay (mirrors PDF layout, PRD 14) */}
      {preview && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-white p-6" role="dialog" aria-label="Pratonton cetak">
          <div className="mx-auto max-w-3xl">
            <div className="mb-4 flex items-center justify-between print:hidden">
              <p className="text-sm text-muted-foreground">Pratonton cetak - sepadan dengan eksport PDF Ver. 3.2. Gunakan Print → Save as PDF.</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => window.print()}><Printer className="h-4 w-4" /> Cetak</Button>
                <Button variant="outline" size="sm" onClick={() => setPreview(false)}><X className="h-4 w-4" /> Tutup</Button>
              </div>
            </div>
            <div className="text-[11px] leading-snug text-black" style={{ fontFamily: 'Georgia, serif' }}>
              <div className="text-center mb-2">
                <p className="font-bold text-[12px]">POLITEKNIK SULTAN HAJI AHMAD SHAH (POLISAS), KUANTAN, MALAYSIA</p>
                <p className="font-bold text-[11px]">JABATAN KEJURUTERAAN MEKANIKAL (JKM)</p>
                <p className="font-bold mt-2 text-[12px]">Laporan Penambahbaikan Kualiti Berterusan (CQI) Pencapaian CLO</p>
                <p>Sesi: {header.sessionLabel}</p>
              </div>
              <table className="w-full border-collapse border border-gray-600 text-[10px]">
                <tbody>
                  <tr><th className="w-1/3 border border-gray-600 p-1 text-left bg-gray-100">Kod &amp; Nama Kursus</th><td className="border border-gray-600 p-1">{header.courseCode} - {header.courseName}</td></tr>
                  <tr><th className="border border-gray-600 p-1 text-left bg-gray-100">Nama Penyelaras Kursus</th><td className="border border-gray-600 p-1">{header.coordinator}</td></tr>
                  <tr><th className="border border-gray-600 p-1 text-left bg-gray-100">Program</th><td className="border border-gray-600 p-1">{header.programme}</td></tr>
                  <tr><th className="border border-gray-600 p-1 text-left bg-gray-100">Seksyen/Kelas</th><td className="border border-gray-600 p-1">{header.sectionCodes}</td></tr>
                </tbody>
              </table>
              <p className="font-bold mt-3 bg-gray-100 border border-gray-600 p-1">SEKSYEN A: LAPORAN ANALISIS PENCAPAIAN CLO</p>
              <table className="w-full border-collapse border border-gray-600 text-[10px]">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-gray-600 p-1">CLO</th>
                    {comparison.series.map((s) => <th key={s.sessionId} className="border border-gray-600 p-1">{s.label} (Bil. Pelajar: {dash(s.studentCount)})</th>)}
                  </tr>
                </thead>
                <tbody>
                  {comparison.comparisons.map((c) => (
                    <tr key={c.cloId}>
                      <td className="border border-gray-600 p-1">{c.code} - {c.statement}</td>
                      {c.series.map((v, si) => <td key={si} className="border border-gray-600 p-1 text-center">{v === null ? '-' : `${v}%`}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="font-bold mt-3 bg-gray-100 border border-gray-600 p-1">Rekod Pencapaian CLO Kurang {settings.cloTarget}% Mengikut Sesi</p>
              <table className="w-full border-collapse border border-gray-600 text-[10px]">
                <thead><tr className="bg-gray-100"><th className="border border-gray-600 p-1">Sesi</th><th className="border border-gray-600 p-1">Isu Pencapaian CLO</th><th className="border border-gray-600 p-1">CLO Terlibat</th><th className="border border-gray-600 p-1">Tumpuan CQI</th></tr></thead>
                <tbody>
                  {issues.map((r, i) => (
                    <tr key={i}>
                      <td className="border border-gray-600 p-1">{r.sessionLabel}</td>
                      <td className="border border-gray-600 p-1">{!r.hasData || r.belowClos.length === 0 ? 'Tiada' : r.issueCode ? lookupLabels.issue[r.issueCode] ?? r.issueCode : 'Sila Pilih'}</td>
                      <td className="border border-gray-600 p-1">{r.belowClos.length === 0 ? 'Tiada' : r.cloInvolved ?? r.belowClos.map((b) => comparison.comparisons.find((c) => c.cloId === b.cloId)?.code ?? b.cloId).join(', ')}</td>
                      <td className="border border-gray-600 p-1">{r.isCurrent && r.belowClos.length > 0 ? r.focus ?? '-' : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="font-bold mt-3 bg-gray-100 border border-gray-600 p-1">SEKSYEN B: LAPORAN/STATUS PELAKSANAAN CQI TERDAHULU</p>
              <table className="w-full border-collapse border border-gray-600 text-[10px]">
                <thead><tr className="bg-gray-100"><th className="border border-gray-600 p-1">Bil.</th><th className="border border-gray-600 p-1">Tindakan/Aktiviti</th><th className="border border-gray-600 p-1">Impak Terhadap Pencapaian CLO</th><th className="border border-gray-600 p-1">Tarikh Pelaksanaan</th><th className="border border-gray-600 p-1">Dokumen/Bukti</th></tr></thead>
                <tbody>
                  {data.sectionBActions.map((a, i) => (
                    <tr key={a.id}>
                      <td className="border border-gray-600 p-1 text-center">{i + 1}</td>
                      <td className="border border-gray-600 p-1">{a.description}</td>
                      <td className="border border-gray-600 p-1">{(actionEdits[a.id]?.impact ?? a.impact) ?? '-'}{(actionEdits[a.id]?.impactText ?? a.impactText) ? ` - ${actionEdits[a.id]?.impactText ?? a.impactText}` : ''}</td>
                      <td className="border border-gray-600 p-1">{fmtDate(actionEdits[a.id]?.implementedDate ?? a.implementedDate)}</td>
                      <td className="border border-gray-600 p-1">{a.evidenceFiles.map((e) => e.fileName).join(', ') || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="font-bold mt-3 bg-gray-100 border border-gray-600 p-1">SEKSYEN C: CADANGAN PELAKSANAAN CQI (SESI AKAN DATANG)</p>
              <table className="w-full border-collapse border border-gray-600 text-[10px]">
                <thead><tr className="bg-gray-100"><th className="border border-gray-600 p-1">Bil.</th><th className="border border-gray-600 p-1">Punca</th><th className="border border-gray-600 p-1">Cadangan CQI</th><th className="border border-gray-600 p-1">Jenis CQI</th></tr></thead>
                <tbody>
                  {rows.map((r, i) => (
                    <tr key={i}>
                      <td className="border border-gray-600 p-1 text-center">{i + 1}</td>
                      <td className="border border-gray-600 p-1">{comparison.comparisons.find((c) => c.cloId === r.cloId)?.code ?? ''} {r.causeTags.map((t) => CAUSE_FACTORS.find((f) => f.code === t)?.bm).join('; ')} {r.causeText}</td>
                      <td className="border border-gray-600 p-1">{r.proposal}{r.outcome ? ` (Hasil: ${r.outcome})` : ''}</td>
                      <td className="border border-gray-600 p-1">{r.cqiType}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="font-bold mt-3 bg-gray-100 border border-gray-600 p-1">SEKSYEN D: MAKLUMBALAS KURIKULUM</p>
              <table className="w-full border-collapse border border-gray-600 text-[10px]">
                <thead><tr className="bg-gray-100"><th className="border border-gray-600 p-1">Bil.</th><th className="border border-gray-600 p-1">Perkara</th><th className="border border-gray-600 p-1">Maklumbalas/Cadangan</th></tr></thead>
                <tbody>
                  {feedback.map((f, i) => (
                    <tr key={i}>
                      <td className="border border-gray-600 p-1 text-center">{i + 1}</td>
                      <td className="border border-gray-600 p-1">{lookupLabels.topic[f.topic] ?? f.topic}</td>
                      <td className="border border-gray-600 p-1">{f.text}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="font-bold mt-3 bg-gray-100 border border-gray-600 p-1">SEKSYEN E: PENGESAHAN</p>
              <div className="mt-2 grid grid-cols-2 gap-3 text-[10px]">
                <div className="border border-gray-600 p-2 min-h-24">
                  <p className="font-bold">Disediakan oleh:</p>
                  <p className="mt-2">{report.submittedBy?.fullName ?? header.coordinator}</p>
                  <p>Penyelaras Kursus</p>
                  <p>Tarikh: {fmtDate(report.submittedAt)}</p>
                  <p className="mt-6 border-t border-gray-600 pt-1">Tandatangan</p>
                </div>
                <div className="border border-gray-600 p-2 min-h-24">
                  <p className="font-bold">Disahkan oleh:</p>
                  {report.verifications.map((v) => <p key={v.id} className="mt-1">{v.user.fullName} ({v.role}) - {fmtDate(v.signedAt)}</p>)}
                  <p className="mt-6 border-t border-gray-600 pt-1">Tandatangan (KK/KPro/KJ)</p>
                </div>
              </div>
              <p className="mt-4 border-t border-gray-600 pt-1 text-center text-[9px] text-gray-700">
                Borang Laporan CQI Kursus Ver. {report.templateVersion} | Berkuatkuasa: Januari 2026 | Dikemas kini: Jun 2026
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
