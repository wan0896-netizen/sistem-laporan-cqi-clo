'use client';

import { useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Download, Loader2, Plus, Save, Upload } from 'lucide-react';
import { useT } from '@/lib/i18n';

interface MarkRow {
  matric: string;
  itemId: string;
  score: number | null;
  status: string | null;
}

interface MarksOffering {
  id: string;
  sections: { id: string; code: string; studentCount: number }[];
  assessments: { id: string; name: string; type: string; weight: number; items: { id: string; label: string; maxMarks: number; cloId: string | null }[] }[];
  marks: { matric: string; itemId: string; score: number | null; status: string | null; sectionId: string }[];
  course: { clos: { id: string; code: string }[] };
}

const STATUS_OPTIONS = [
  { value: 'ABSENT', label: 'TG / Absent' },
  { value: 'BARRED', label: 'LARANG / Barred' },
  { value: 'EXEMPTED', label: 'BEBAS / Exempted' },
];

export function MarksGrid({ offeringId, data, editable }: { offeringId: string; data: MarksOffering; editable: boolean }) {
  const t = useT();
  const { toast } = useToast();
  const [grid, setGrid] = useState<Record<string, MarkRow>>(() => {
    const init: Record<string, MarkRow> = {};
    for (const m of data.marks) {
      init[`${m.sectionId}|${m.matric}|${m.itemId}`] = { matric: m.matric, itemId: m.itemId, score: m.score, status: m.status };
    }
    return init;
  });
  const [dirty, setDirty] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [importCsv, setImportCsv] = useState('');
  const [importMode, setImportMode] = useState<'MARKS' | 'CLO_RESULTS'>('MARKS');
  const [importReport, setImportReport] = useState<{ ok: boolean; totalRows: number; validRows: number; errors: { row: number; matric: string; error: string }[]; message: string } | null>(null);
  const [importing, setImporting] = useState(false);
  const [sectionFilter, setSectionFilter] = useState<string>('ALL');

  const items = useMemo(() => data.assessments.flatMap((a) => a.items), [data.assessments]);
  const itemById = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);

  // roster: distinct (section, matric) from marks
  const roster = useMemo(() => {
    const map = new Map<string, string>(); // key -> sectionId
    for (const m of data.marks) map.set(`${m.sectionId}|${m.matric}`, m.sectionId);
    for (const s of data.sections) {
      // ensure placeholders exist even without marks
    }
    return map;
  }, [data.marks, data.sections]);

  const visibleRoster = useMemo(() => {
    const rows = [...roster.keys()].sort();
    return sectionFilter === 'ALL' ? rows : rows.filter((k) => k.startsWith(`${sectionFilter}|`));
  }, [roster, sectionFilter]);

  function setCell(key: string, patch: Partial<MarkRow>) {
    setGrid((prev) => {
      const cur = prev[key];
      if (!cur) return prev;
      return { ...prev, [key]: { ...cur, ...patch } };
    });
    setDirty((prev) => new Set(prev).add(key));
  }

  function addStudent() {
    const sectionId = data.sections[0]?.id;
    if (!sectionId) return;
    const matric = window.prompt('No. Matrik pelajar baharu / New student matric number:');
    if (!matric) return;
    setGrid((prev) => {
      const next = { ...prev };
      for (const item of items) {
        const key = `${sectionId}|${matric.toUpperCase()}|${item.id}`;
        if (!next[key]) next[key] = { matric: matric.toUpperCase(), itemId: item.id, score: null, status: null };
      }
      return next;
    });
    setDirty((prev) => {
      const next = new Set(prev);
      for (const item of items) next.add(`${sectionId}|${matric.toUpperCase()}|${item.id}`);
      return next;
    });
  }

  async function save() {
    setSaving(true);
    try {
      const changes = [...dirty].map((key) => {
        const [sectionId, matric, itemId] = key.split('|');
        const row = grid[key];
        return { sectionId, matric, itemId, score: row?.score ?? null, status: row?.status ?? null };
      });
      const res = await fetch('/api/marks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ offeringId, changes }),
      });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: t('validationErrors'), description: (result.errors ?? [result.error]).join('\n'), variant: 'destructive' });
        return;
      }
      setDirty(new Set());
      toast({ title: t('saved'), description: `${result.saved} baris disimpan / rows saved` });
    } finally {
      setSaving(false);
    }
  }

  async function runImport(commit: boolean) {
    setImporting(true);
    try {
      const res = await fetch('/api/marks/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ offeringId, csv: importCsv, mode: importMode, commit }),
      });
      const result = await res.json();
      if (commit && res.ok) {
        toast({ title: t('saved'), description: `${result.committed} nilai dikomiti / values committed` });
        setImportOpen(false);
        setImportReport(null);
        setImportCsv('');
        window.location.reload();
        return;
      }
      setImportReport(result);
    } finally {
      setImporting(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-2 space-y-0">
          <div>
            <CardTitle className="text-base">Kemasukan Markah (Grid)</CardTitle>
            <CardDescription>No. Matrik sahaja direkod - PDPA 2010 (tiada nama/IC)</CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select value={sectionFilter} onValueChange={setSectionFilter}>
              <SelectTrigger className="w-36" aria-label="Seksyen"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Semua seksyen</SelectItem>
                {data.sections.map((s) => <SelectItem key={s.id} value={s.id}>{s.code}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={addStudent} disabled={!editable}>
              <Plus className="h-4 w-4" /> {t('addStudent')}
            </Button>
            <Button variant="outline" size="sm" onClick={() => setImportOpen(true)} disabled={!editable}>
              <Upload className="h-4 w-4" /> {t('importMarks')}
            </Button>
            <a href={`/api/marks/template?offeringId=${offeringId}&mode=MARKS`} download>
              <Button variant="ghost" size="sm"><Download className="h-4 w-4" /> {t('downloadTemplate')}</Button>
            </a>
            <Button size="sm" onClick={save} disabled={!editable || saving || dirty.size === 0}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {t('save')}{dirty.size > 0 ? ` (${dirty.size})` : ''}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('matric')}</TableHead>
                {items.map((i) => (
                  <TableHead key={i.id} className="min-w-24">
                    {i.label}
                    <p className="text-xs font-normal text-muted-foreground">max {i.maxMarks}</p>
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {visibleRoster.map((key) => {
                const [sectionId, matric] = key.split('|');
                return (
                  <TableRow key={key}>
                    <TableCell className="font-mono text-xs">
                      {matric}
                      <p className="text-[10px] text-muted-foreground">{data.sections.find((s) => s.id === sectionId)?.code}</p>
                    </TableCell>
                    {items.map((item) => {
                      const cellKey = `${sectionId}|${matric}|${item.id}`;
                      const cell = grid[cellKey];
                      if (!cell) return <TableCell key={item.id} className="text-muted-foreground">-</TableCell>;
                      return (
                        <TableCell key={item.id}>
                          <div className="flex items-center gap-1">
                            <Input
                              type="number"
                              min={0}
                              max={item.maxMarks}
                              value={cell.score ?? ''}
                              disabled={!editable || cell.status !== null}
                              onChange={(e) => setCell(cellKey, { score: e.target.value === '' ? null : Number(e.target.value) })}
                              className="h-8 w-20"
                              aria-label={`${matric} ${item.label}`}
                            />
                            <Select value={cell.status ?? 'NORMAL'} onValueChange={(v) => setCell(cellKey, { status: v === 'NORMAL' ? null : v, score: v === 'NORMAL' ? cell.score : null })} disabled={!editable}>
                              <SelectTrigger className="h-8 w-[86px]" aria-label="Status">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="NORMAL">Biasa</SelectItem>
                                {STATUS_OPTIONS.map((s) => (
                                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('importMarks')}</DialogTitle>
            <DialogDescription>{t('validateFirst')} - muat turun templat untuk format betul.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Select value={importMode} onValueChange={(v) => setImportMode(v as 'MARKS' | 'CLO_RESULTS')}>
              <SelectTrigger aria-label="Mod import"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="MARKS">Markah mengikut item (No. Matrik, item...)</SelectItem>
                <SelectItem value="CLO_RESULTS">Hasil CLO dikira (No. Matrik, CLO %...) - FR-MK-05</SelectItem>
              </SelectContent>
            </Select>
            <a href={`/api/marks/template?offeringId=${offeringId}&mode=${importMode}`} download className="text-sm text-primary hover:underline inline-flex items-center gap-1">
              <Download className="h-3.5 w-3.5" /> {t('downloadTemplate')} ({importMode})
            </a>
            <textarea
              className="min-h-40 w-full rounded-md border bg-background p-2 font-mono text-xs"
              placeholder="01DAD23A001,85,90,72,..."
              value={importCsv}
              onChange={(e) => setImportCsv(e.target.value)}
              aria-label="CSV"
            />
            {importReport && (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="bg-emerald-50 text-emerald-800 border-emerald-300">{importReport.validRows} {t('rowsValid')}</Badge>
                  {importReport.errors?.length > 0 && <Badge variant="outline" className="bg-red-50 text-red-800 border-red-300">{importReport.errors.length} {t('rowsError')}</Badge>}
                  <span className="text-xs text-muted-foreground">{importReport.message}</span>
                </div>
                {importReport.errors?.length > 0 && (
                  <Alert variant="destructive">
                    <AlertDescription>
                      <ul className="max-h-32 overflow-y-auto text-xs list-disc pl-4">
                        {importReport.errors.slice(0, 15).map((e, i) => (
                          <li key={i}>Baris {e.row} ({e.matric}): {e.error}</li>
                        ))}
                      </ul>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => runImport(false)} disabled={importing || !importCsv.trim()}>
              {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Sahkan (dry-run)
            </Button>
            <Button onClick={() => runImport(true)} disabled={importing || !importReport?.ok || !importCsv.trim()}>
              {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} {t('commit')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
