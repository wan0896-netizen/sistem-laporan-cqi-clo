'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine, ResponsiveContainer } from 'recharts';
import { useLang } from '@/lib/i18n';
import { AttainmentBadge } from '@/components/shared/ui-bits';
import { dash, signedDelta } from '@/lib/format';
import { CAUSE_FACTORS } from '@/lib/calculation';

interface Comparison {
  current: { cloId: string; code: string; statement: string; attainment: number | null; studentCount: number; met: boolean | null; lowSample: boolean }[];
  perSection: { sectionId: string; sectionCode: string; attainments: { cloId: string; attainment: number | null; studentCount: number }[] }[];
  series: { sessionId: string; label: string; studentCount: number | null; hasData: boolean; isCurrent: boolean; attainmentByClo: Record<string, number | null> }[];
  comparisons: {
    cloId: string; code: string; statement: string; series: (number | null)[]; delta: number | null; met: boolean | null; declined: boolean; prevLabel: string | null; currentAttainment: number | null; currentStudentCount: number;
  }[];
  likeForLike: boolean;
  cloDifferences: string[];
}

interface Suggestion {
  cloId: string; code: string; attainment: number | null; delta: number | null; affected: boolean; suggestedType: string | null; reasonBm: string; reasonEn: string;
}

export function AttainmentView({ offeringId, settings }: { offeringId: string; settings: { cloTarget: number; dropThreshold: number } }) {
  const { lang } = useLang();
  const [data, setData] = useState<{ comparison: Comparison; suggestions: Suggestion[]; overallType: string | null } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/attainment/compute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ offeringId }),
    })
      .then(async (r) => {
        if (!r.ok) throw new Error((await r.json()).error ?? 'Gagal');
        return r.json();
      })
      .then(setData)
      .catch((e) => setError(String(e.message ?? e)));
  }, [offeringId]);

  if (error) return <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>;
  if (!data) return <div className="space-y-3"><Skeleton className="h-8 w-full" /><Skeleton className="h-64 w-full" /></div>;

  const { comparison, suggestions } = data;
  const chartData = comparison.comparisons.map((c) => {
    const row: Record<string, string | number | null> = { clo: c.code };
    comparison.series.forEach((s, si) => {
      row[s.label] = c.series[si];
    });
    return row;
  });
  const sessionColors = ['#155e75', '#7c3aed', '#ea580c', '#16a34a'];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Jadual Perbandingan Pencapaian CLO (3 Sesi)</CardTitle>
          <CardDescription>
            Sasaran {settings.cloTarget}% · penurunan signifikan ≥ {settings.dropThreshold} mata peratusan · sesi tanpa data dipaparkan &quot;-&quot;
          </CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-64">CLO</TableHead>
                {comparison.series.map((s) => (
                  <TableHead key={s.sessionId} className="text-center min-w-36">
                    {s.label}
                    <p className="text-xs font-normal text-muted-foreground">Bil. pelajar: {dash(s.studentCount)}</p>
                  </TableHead>
                ))}
                <TableHead className="text-center">Perubahan</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {comparison.comparisons.map((c) => (
                <TableRow key={c.cloId}>
                  <TableCell>
                    <span className="font-medium">{c.code}</span>
                    <p className="text-xs text-muted-foreground">{c.statement}</p>
                  </TableCell>
                  {c.series.map((v, si) => (
                    <TableCell key={si} className="text-center">
                      <span className="font-medium">{v === null ? '-' : `${v}%`}</span>
                      {si === 0 && v !== null && (
                        <p className={`text-[10px] ${v < settings.cloTarget ? 'text-red-700' : c.declined ? 'text-amber-700' : 'text-emerald-700'}`}>
                          {v < settings.cloTarget ? 'TIDAK MENCAPAI SASARAN' : c.declined ? 'MENURUN ≥ 5%' : 'MENCAPAI SASARAN'}
                        </p>
                      )}
                    </TableCell>
                  ))}
                  <TableCell className="text-center">
                    <span className={c.declined ? 'font-semibold text-amber-700' : ''}>{signedDelta(c.delta)} m.p.{c.delta !== null ? ` vs ${c.prevLabel}` : ''}</span>
                  </TableCell>
                  <TableCell>
                    <AttainmentBadge met={c.met} declined={c.declined} lowSample={c.currentStudentCount > 0 && c.currentStudentCount < 20} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {!comparison.likeForLike && (
        <Alert variant="destructive">
          <AlertDescription>
            <p className="font-medium">Amaran like-for-like (FR-CLO-09): definisi CLO berbeza antara sesi dalam tetingkap perbandingan.</p>
            <ul className="mt-1 list-disc pl-5 text-xs">
              {comparison.cloDifferences.map((d, i) => <li key={i}>{d}</li>)}
            </ul>
            <p className="mt-1 text-xs">Nota perbandingan diperlukan dalam editor laporan sebelum penghantaran.</p>
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Graf Perbandingan (garis sasaran {settings.cloTarget}%)</CardTitle>
        </CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="clo" />
              <YAxis domain={[0, 100]} unit="%" />
              <Tooltip formatter={(v: number | string) => (v === null || v === undefined ? '-' : `${v}%`)} />
              <Legend />
              <ReferenceLine y={settings.cloTarget} stroke="#dc2626" strokeDasharray="6 3" label={{ value: `Sasaran ${settings.cloTarget}%`, fill: '#dc2626', fontSize: 12 }} />
              {comparison.series.map((s, si) => (
                <Bar key={s.sessionId} dataKey={s.label} fill={sessionColors[si % sessionColors.length]} radius={[3, 3, 0, 0]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Per-section breakdown (PRD 8.4) */}
      {comparison.perSection.length > 1 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Pencapaian Mengikut Seksyen</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Seksyen</TableHead>
                  {comparison.comparisons.map((c) => <TableHead key={c.cloId} className="text-center">{c.code}</TableHead>)}
                </TableRow>
              </TableHeader>
              <TableBody>
                {comparison.perSection.map((s) => (
                  <TableRow key={s.sectionId}>
                    <TableCell className="font-medium">{s.sectionCode}</TableCell>
                    {s.attainments.map((a) => (
                      <TableCell key={a.cloId} className="text-center">{a.attainment === null ? '-' : `${a.attainment}% (n=${a.studentCount})`}</TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* CQI suggestions (8.3 / FR-CQI-02 preview) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Saranan Jenis CQI (Peraturan 8.3)</CardTitle>
          <CardDescription>Sistem menyarankan; pensyarah/penyelaras boleh mengubah dengan alasan dalam editor laporan</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {suggestions.map((s) => (
            <div key={s.cloId} className="rounded-lg border p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{s.code}</span>
                {s.affected && <span className="rounded bg-red-100 px-1.5 py-0.5 text-[10px] font-semibold text-red-800">TERJEKAS</span>}
                {s.suggestedType && (
                  <span className="rounded bg-sky-100 px-1.5 py-0.5 text-[10px] font-semibold text-sky-900">
                    {lang === 'bm' ? 'Cadangan:' : 'Suggested:'} {s.suggestedType === 'CORRECTIVE' ? 'Pembetulan' : s.suggestedType === 'PREVENTIVE' ? 'Pencegahan' : 'Penambahbaikan'}
                  </span>
                )}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">{lang === 'bm' ? s.reasonBm : s.reasonEn}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Form factors reference */}
      <Card>
        <CardHeader><CardTitle className="text-base">Enam Faktor Punca (Borang Ver. 3.2)</CardTitle></CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 text-sm space-y-1">
            {CAUSE_FACTORS.map((f) => <li key={f.code}>{f.bm} <span className="text-xs text-muted-foreground">/ {f.en}</span></li>)}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
