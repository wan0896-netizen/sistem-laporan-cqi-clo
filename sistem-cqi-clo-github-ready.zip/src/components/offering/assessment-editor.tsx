'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Copy, Loader2, Plus, Save, Trash2 } from 'lucide-react';
import { useT } from '@/lib/i18n';

interface AssessOffering {
  id: string;
  sessionId: string;
  programmeId: string;
  course: { code: string };
  assessments: {
    id: string;
    name: string;
    type: string;
    weight: number;
    items: { id: string; label: string; maxMarks: number; cloId: string | null }[];
  }[];
  course: { clos: { id: string; code: string; statement: string }[] };
}

/** FR-AS-01/02/03: assessment structure with one-CLO-per-item mapping + validation. */
export function AssessmentEditor({ offeringId, data, editable, previousOfferingId }: { offeringId: string; data: AssessOffering; editable: boolean; previousOfferingId: string | null }) {
  const t = useT();
  const { toast } = useToast();
  const [assessments, setAssessments] = useState(data.assessments);
  const [saving, setSaving] = useState(false);
  const [cloning, setCloning] = useState(false);

  const totalWeight = assessments.reduce((acc, a) => acc + (a.weight || 0), 0);
  const coveredCloIds = new Set(assessments.flatMap((a) => a.items.map((i) => i.cloId).filter(Boolean)));
  const allCloCovered = data.course.clos.every((c) => coveredCloIds.has(c.id));
  const itemsWithClo = assessments.every((a) => a.items.every((i) => i.cloId !== null));
  const valid = totalWeight === 100 && allCloCovered && itemsWithClo && assessments.length > 0;

  function addAssessment() {
    setAssessments((prev) => [...prev, { id: `new-${prev.length}`, name: 'Penilaian Baharu', type: 'Coursework', weight: 0, items: [{ id: `newitem-${prev.length}-0`, label: 'ITEM1', maxMarks: 100, cloId: data.course.clos[0]?.id ?? null }] }]);
  }

  function patchAssessment(id: string, patch: Partial<(typeof assessments)[number]>) {
    setAssessments((prev) => prev.map((a) => (a.id === id ? { ...a, ...patch } : a)));
  }

  function addItem(aId: string) {
    setAssessments((prev) =>
      prev.map((a) => (a.id === aId ? { ...a, items: [...a.items, { id: `newitem-${aId}-${a.items.length}`, label: `ITEM${a.items.length + 1}`, maxMarks: 100, cloId: data.course.clos[0]?.id ?? null }] } : a)),
    );
  }

  function patchItem(aId: string, itemId: string, patch: Partial<(typeof assessments)[number]['items'][number]>) {
    setAssessments((prev) => prev.map((a) => (a.id === aId ? { ...a, items: a.items.map((i) => (i.id === itemId ? { ...i, ...patch } : i)) } : a)));
  }

  function removeItem(aId: string, itemId: string) {
    setAssessments((prev) => prev.map((a) => (a.id === aId ? { ...a, items: a.items.filter((i) => i.id !== itemId) } : a)));
  }

  function removeAssessment(aId: string) {
    setAssessments((prev) => prev.filter((a) => a.id !== aId));
  }

  async function save() {
    if (!valid) return;
    setSaving(true);
    try {
      // persist the whole structure: replace assessments for the offering
      for (const a of assessments) {
        const payload = {
          entity: 'assessmentStructure',
          offeringId,
          name: a.name,
          type: a.type,
          weight: a.weight,
          items: a.items.map((i) => ({ label: i.label, maxMarks: i.maxMarks, cloId: i.cloId })),
        };
        const res = await fetch('/api/admin/master', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ entity: 'assessment', action: assessments.some((x) => x.id === a.id) ? 'noop' : 'create', data: payload }) });
        void res;
      }
      // dedicated endpoint keeps this clean
      const res = await fetch('/api/assessments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ offeringId, assessments }),
      });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: 'Ralat', description: result.error ?? 'Gagal menyimpan', variant: 'destructive' });
        return;
      }
      toast({ title: t('saved') });
      window.location.reload();
    } finally {
      setSaving(false);
    }
  }

  async function clonePrevious() {
    if (!previousOfferingId) return;
    setCloning(true);
    try {
      const res = await fetch('/api/assessments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ offeringId, cloneFrom: previousOfferingId }),
      });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: 'Ralat', description: result.error ?? 'Gagal klon', variant: 'destructive' });
        return;
      }
      toast({ title: 'Struktur penilaian diklon dari sesi lepas' });
      window.location.reload();
    } finally {
      setCloning(false);
    }
  }

  return (
    <Card>
      <CardHeader className="flex-row flex-wrap items-center justify-between gap-2 space-y-0">
        <div>
          <CardTitle className="text-base">Struktur Penilaian</CardTitle>
          <CardDescription>Setiap item dinilai dipetakan kepada SATU CLO (FR-AS-01)</CardDescription>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {previousOfferingId && (
            <Button variant="outline" size="sm" onClick={clonePrevious} disabled={!editable || cloning}>
              {cloning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Copy className="h-4 w-4" />} Klon dari sesi lepas (FR-AS-03)
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={addAssessment} disabled={!editable}><Plus className="h-4 w-4" /> Tambah Penilaian</Button>
          <Button size="sm" onClick={save} disabled={!editable || saving || !valid}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {t('save')}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2 text-xs">
          <Badge variant="outline" className={totalWeight === 100 ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'bg-red-50 text-red-800 border-red-300'}>
            Jumlah pemberat: {totalWeight}% (mesti 100%)
          </Badge>
          <Badge variant="outline" className={allCloCovered ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'bg-red-50 text-red-800 border-red-300'}>
            Semua CLO diliputi: {allCloCovered ? 'Ya' : 'Tidak'}
          </Badge>
          <Badge variant="outline" className={itemsWithClo ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'bg-red-50 text-red-800 border-red-300'}>
            Semua item dipetakan CLO: {itemsWithClo ? 'Ya' : 'Tidak'}
          </Badge>
        </div>
        {!valid && <Alert><AlertDescription>Pengesahan FR-AS-02: pemberat mesti berjumlah 100% dan setiap CLO diliputi sekurang-kurangnya satu item.</AlertDescription></Alert>}
        {assessments.map((a) => (
          <div key={a.id} className="rounded-lg border p-3 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <Input value={a.name} onChange={(e) => patchAssessment(a.id, { name: e.target.value })} className="w-56 h-8" disabled={!editable} aria-label="Nama penilaian" />
              <Input value={a.type} onChange={(e) => patchAssessment(a.id, { type: e.target.value })} className="w-32 h-8" disabled={!editable} aria-label="Jenis" />
              <div className="flex items-center gap-1">
                <span className="text-xs text-muted-foreground">Pemberat %</span>
                <Input type="number" min={0} max={100} value={a.weight} onChange={(e) => patchAssessment(a.id, { weight: Number(e.target.value) })} className="w-20 h-8" disabled={!editable} aria-label="Pemberat" />
              </div>
              <Button variant="ghost" size="sm" onClick={() => addItem(a.id)} disabled={!editable}><Plus className="h-4 w-4" /> Item</Button>
              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => removeAssessment(a.id)} disabled={!editable}><Trash2 className="h-4 w-4" /></Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Label</TableHead>
                  <TableHead>Markah penuh</TableHead>
                  <TableHead>CLO (satu sahaja)</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {a.items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell><Input value={item.label} onChange={(e) => patchItem(a.id, item.id, { label: e.target.value })} className="h-8 w-28" disabled={!editable} /></TableCell>
                    <TableCell><Input type="number" min={1} value={item.maxMarks} onChange={(e) => patchItem(a.id, item.id, { maxMarks: Number(e.target.value) })} className="h-8 w-24" disabled={!editable} /></TableCell>
                    <TableCell>
                      <select
                        value={item.cloId ?? ''}
                        onChange={(e) => patchItem(a.id, item.id, { cloId: e.target.value || null })}
                        disabled={!editable}
                        className="h-8 w-full rounded-md border bg-background px-2 text-sm"
                        aria-label="CLO"
                      >
                        <option value="">- pilih CLO -</option>
                        {data.course.clos.map((c) => (
                          <option key={c.id} value={c.id}>{c.code} - {c.statement.slice(0, 60)}{c.statement.length > 60 ? '...' : ''}</option>
                        ))}
                      </select>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" className="text-destructive" onClick={() => removeItem(a.id, item.id)} disabled={!editable}><Trash2 className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
