'use client';

import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { STATUS_LABEL, REPORT_STATUS_LABEL, CQI_TYPE_LABEL, ACTION_STATUS_LABEL, statusTone, type StatusTone } from '@/lib/format';
import { useLang } from '@/lib/i18n';

/** Colour + text label: colour is never the only indicator (PRD 12 Usability). */
export function AttainmentBadge({ met, declined, lowSample }: { met: boolean | null; declined: boolean; lowSample?: boolean }) {
  const { lang } = useLang();
  const tone: StatusTone = statusTone(met, declined);
  const label = STATUS_LABEL[tone];
  return (
    <span className="inline-flex items-center gap-1">
      <Badge variant="outline" className={cn('text-xs', label.className)}>
        {lang === 'bm' ? label.bm : label.en}
      </Badge>
      {lowSample && <Badge variant="outline" className="text-xs bg-orange-50 text-orange-800 border-orange-300">{lang === 'bm' ? 'Sampel kecil' : 'Low sample'}</Badge>}
    </span>
  );
}

export function ReportStatusBadge({ status }: { status: string }) {
  const { lang } = useLang();
  const label = REPORT_STATUS_LABEL[status];
  if (!label) return <Badge variant="outline">{status}</Badge>;
  return <Badge variant="outline" className={label.className}>{lang === 'bm' ? label.bm : label.en}</Badge>;
}

export function CqiTypeBadge({ type }: { type: string | null }) {
  const { lang } = useLang();
  if (!type) return <span>-</span>;
  const label = CQI_TYPE_LABEL[type];
  const className =
    type === 'CORRECTIVE' ? 'bg-red-50 text-red-800 border-red-300' : type === 'PREVENTIVE' ? 'bg-amber-50 text-amber-900 border-amber-300' : 'bg-emerald-50 text-emerald-800 border-emerald-300';
  return <Badge variant="outline" className={className}>{label ? (lang === 'bm' ? label.bm : label.en) : type}</Badge>;
}

export function ActionStatusBadge({ status }: { status: string }) {
  const { lang } = useLang();
  const label = ACTION_STATUS_LABEL[status];
  const className =
    status === 'IMPLEMENTED' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : status === 'PARTIAL' ? 'bg-amber-50 text-amber-900 border-amber-300' : status === 'NOT_IMPLEMENTED' ? 'bg-red-50 text-red-800 border-red-300' : 'bg-gray-50 text-gray-700 border-gray-300';
  return <Badge variant="outline" className={className}>{label ? (lang === 'bm' ? label.bm : label.en) : status}</Badge>;
}
