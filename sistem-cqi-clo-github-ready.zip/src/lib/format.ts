/** Shared formatting helpers - Malaysian conventions. */

export function fmtDate(d: Date | string | null | undefined): string {
  if (!d) return '-';
  const date = typeof d === 'string' ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return '-';
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  return `${dd}/${mm}/${date.getFullYear()}`;
}

export function fmtDateTime(d: Date | string | null | undefined): string {
  if (!d) return '-';
  const date = typeof d === 'string' ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return '-';
  const hh = String(date.getHours()).padStart(2, '0');
  const mi = String(date.getMinutes()).padStart(2, '0');
  return `${fmtDate(date)} ${hh}:${mi}`;
}

/** "-" per PRD: a session with no data shows "-" and is excluded without error. */
export function dash(value: number | null | undefined, suffix = ''): string {
  if (value === null || value === undefined) return '-';
  return `${value}${suffix}`;
}

export function signedDelta(delta: number | null): string {
  if (delta === null) return '-';
  return delta > 0 ? `+${delta}` : `${delta}`;
}

export type StatusTone = 'met' | 'notMet' | 'declined' | 'none';

export function statusTone(met: boolean | null, declined: boolean): StatusTone {
  if (met === null) return 'none';
  if (!met) return 'notMet';
  if (declined) return 'declined';
  return 'met';
}

/** Colour never the only status indicator - each tone carries a text label (PRD 12 Usability). */
export const STATUS_LABEL: Record<StatusTone, { bm: string; en: string; className: string }> = {
  met: { bm: 'Mencapai Sasaran', en: 'Target Met', className: 'bg-emerald-50 text-emerald-800 border-emerald-300' },
  notMet: { bm: 'Tidak Mencapai Sasaran', en: 'Not Achieved', className: 'bg-red-50 text-red-800 border-red-300' },
  declined: { bm: 'Menurun ≥ 5%', en: 'Declined ≥ 5%', className: 'bg-amber-50 text-amber-900 border-amber-300' },
  none: { bm: 'Tiada Data', en: 'No Data', className: 'bg-gray-50 text-gray-600 border-gray-300' },
};

export const REPORT_STATUS_LABEL: Record<string, { bm: string; en: string; className: string }> = {
  DRAFT: { bm: 'Draf', en: 'Draft', className: 'bg-gray-100 text-gray-700 border-gray-300' },
  UNDER_VERIFICATION: { bm: 'Sedang Pengesahan', en: 'Under Verification', className: 'bg-sky-50 text-sky-800 border-sky-300' },
  RETURNED: { bm: 'Dipulangkan', en: 'Returned', className: 'bg-amber-50 text-amber-900 border-amber-300' },
  VERIFIED: { bm: 'Disahkan', en: 'Verified', className: 'bg-emerald-50 text-emerald-800 border-emerald-300' },
  CLOSED: { bm: 'Tutup (Arkib)', en: 'Closed (Archived)', className: 'bg-stone-100 text-stone-700 border-stone-300' },
  SUBMITTED: { bm: 'Dihantar', en: 'Submitted', className: 'bg-sky-50 text-sky-800 border-sky-300' },
  NOT_STARTED: { bm: 'Belum Mula', en: 'Not Started', className: 'bg-orange-50 text-orange-800 border-orange-300' },
};

export const CQI_TYPE_LABEL: Record<string, { bm: string; en: string }> = {
  CORRECTIVE: { bm: 'Pembetulan', en: 'Corrective' },
  PREVENTIVE: { bm: 'Pencegahan', en: 'Preventive' },
  ENHANCEMENT: { bm: 'Penambahbaikan/Pemantapan', en: 'Enhancement/Sustaining' },
};

export const ACTION_STATUS_LABEL: Record<string, { bm: string; en: string }> = {
  PLANNED: { bm: 'Dirancang', en: 'Planned' },
  IMPLEMENTED: { bm: 'Dilaksanakan', en: 'Implemented' },
  PARTIAL: { bm: 'Sebahagian', en: 'Partial' },
  NOT_IMPLEMENTED: { bm: 'Tidak Dilaksanakan', en: 'Not Implemented' },
};

export const IMPACT_LABEL: Record<string, { bm: string; en: string }> = {
  IMPROVED: { bm: 'Meningkat', en: 'Improved' },
  NO_CHANGE: { bm: 'Tiada Perubahan', en: 'No Change' },
  DECLINED: { bm: 'Menurun', en: 'Declined' },
};
