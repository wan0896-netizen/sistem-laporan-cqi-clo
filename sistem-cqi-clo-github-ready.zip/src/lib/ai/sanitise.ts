/**
 * Server-side data sanitiser (PRD 11.3): "Send only aggregated, anonymised
 * data (no names, no matric numbers) to the model; strip identifiers in a
 * server-side sanitiser before every call."
 *
 * This is the last line of defence before any payload leaves for the model.
 * It removes/derives identifiers by pattern (matric numbers, emails, staff
 * IDs, NRIC-style numbers, phone numbers, lecturer/user names) and rejects
 * payloads that still look unsafe.
 */

const PATTERNS: [RegExp, string][] = [
  // matric numbers e.g. 01DAD23A1001, 08DAD20123001
  [/\b\d{2}[A-Z]{2,4}\d{1,2}[A-Z]?\d{3,6}\b/g, '[MATRIC]'],
  [/\b\d{6,12}\b/g, '[ID]'],
  // emails
  [/[\w.+-]+@[\w-]+\.[\w.]+/g, '[EMAIL]'],
  // NRIC style (Malaysian IC) e.g. 850101-01-5501
  [/\b\d{6}-\d{2}-\d{4}\b/g, '[IC]'],
  // phone numbers
  [/\b(?:\+?6?01\d[-\s]?\d{3,4}[-\s]?\d{4})\b/g, '[PHONE]'],
];

export interface SanitiseResult {
  text: string;
  removedCount: number;
}

export function sanitiseText(input: string): SanitiseResult {
  let out = input;
  let removed = 0;
  for (const [pattern, replacement] of PATTERNS) {
    out = out.replace(pattern, () => {
      removed += 1;
      return replacement;
    });
  }
  return { text: out, removedCount: removed };
}

/**
 * Structural anonymisation: build the model payload from aggregated figures
 * only. Names and matric numbers never enter this structure.
 */
export function buildAnonymousPayload(input: {
  courseCode: string;
  cqiType: string;
  factors?: string[];
  cloStats: { code: string; attainment: number | null; delta: number | null; met: boolean | null; studentCount: number }[];
  previousActions?: { description: string; status: string; impact?: string | null }[];
  studentCounts: Record<string, number | null>;
}): string {
  const payload = {
    kursus: sanitiseText(input.courseCode).text, // course code only, no names
    jenis_cqi: input.cqiType,
    faktor_dipilih: (input.factors ?? []).map((f) => sanitiseText(f).text),
    pencapaian_clo: input.cloStats.map((c) => ({
      clo: c.code,
      pencapaian_peratus: c.attainment === null ? 'tiada_data' : Math.round(c.attainment),
      perubahan_mata: c.delta,
      capaian_sasaran: c.met === null ? 'tiada_data' : c.met ? 'ya' : 'tidak',
      bil_pelajar: c.studentCount,
    })),
    bilangan_pelajar_mengikut_sesi: Object.fromEntries(
      Object.entries(input.studentCounts).map(([k, v]) => [k, v === null ? 'tiada' : v]),
    ),
    tindakan_terdahulu: (input.previousActions ?? []).map((a) => ({
      tindakan: sanitiseText(a.description).text,
      status: a.status,
      impak: a.impact ?? 'tiada',
    })),
  };
  return JSON.stringify(payload);
}
