/**
 * AI runtime (PRD Section 11) - provider-agnostic AiProvider interface.
 *
 * Guardrails implemented here (PRD 11.3):
 *  - Structured JSON output validated against a Zod schema; reject + retry on
 *    invalid output (up to MAX_ATTEMPTS).
 *  - Anonymisation enforced before every call (sanitise.ts).
 *  - Reasoning effort low (thinking disabled) to control latency/cost; no web
 *    search or external tools.
 *  - API credentials read from server env only; never shipped to the browser
 *    (module is server-only).
 *  - Usage logged (user, feature, timestamp, estimated tokens) WITHOUT storing
 *    prompt or output content.
 *  - Rate limit per user per day + monthly token budget cap + feature flag.
 *  - Graceful fallback: if the provider fails after retries, callers receive
 *    a deterministic rule-based draft (never a hard failure).
 */

import 'server-only';
import { db } from '@/lib/db';
import { z } from 'zod';

export interface AiUsageContext {
  userId: string;
  feature: 'punca_draft' | 'cadangan_draft' | 'quality_check' | 'language_assist';
}

export interface AiUsageLog {
  callsToday: number;
  monthlyTokens: number;
}

// ---------------- Zod schemas (structured output validation) ----------------

export const PuncaDraftSchema = z.object({
  hypotheses: z
    .array(
      z.object({
        factor: z.enum(['KURIKULUM', 'PDP', 'BAHAN', 'PENSYARAH', 'DEMOGRAFI', 'SILIBUS']),
        bm: z.string().min(10),
        en: z.string().min(10),
      }),
    )
    .min(1)
    .max(6),
});
export type PuncaDraft = z.infer<typeof PuncaDraftSchema>;

export const CadanganDraftSchema = z.object({
  proposals: z
    .array(
      z.object({
        title: z.string().min(5),
        bm: z.string().min(15),
        en: z.string().min(15),
        outcome: z.string().min(5),
      }),
    )
    .min(1)
    .max(4),
});
export type CadanganDraft = z.infer<typeof CadanganDraftSchema>;

export const QualityCheckSchema = z.object({
  issues: z.array(
    z.object({
      row: z.number().int().min(0),
      code: z.enum(['NO_OUTCOME', 'NO_TARGET_DATE', 'VAGUE_PROPOSAL', 'MISSING_OWNER']),
      bm: z.string(),
      en: z.string(),
    }),
  ),
});
export type QualityCheckResult = z.infer<typeof QualityCheckSchema>;

// ---------------- Provider interface ----------------

export interface AiProvider {
  readonly name: string;
  draftPunca(anonymousPayload: string, cqiType: string): Promise<PuncaDraft>;
  draftCadangan(anonymousPayload: string, cqiType: string): Promise<CadanganDraft>;
}

// ---------------- Z.ai GLM provider (server-side only) ----------------

const SYSTEM_PROMPT = `Anda pembantu penambahbaikan kualiti akademik untuk politeknik Malaysia.
Anda menghasilkan draf Punca (root cause) dan Cadangan CQI untuk laporan CQI pencapaian CLO mengikut Borang Ver. 3.2.
Peraturan:
1. Balas dalam JSON sahaja. Tiada teks lain.
2. Bahasa Melayu formal (bm) dan English (en) untuk setiap item.
3. Punca mesti dikelaskan kepada enam faktor: KURIKULUM, PDP, BAHAN, PENSYARAH, DEMOGRAFI, SILIBUS.
4. Cadangan mesti mengikut jenis CQI: CORRECTIVE (pembetulan punca), PREVENTIVE (hentikan penurunan), ENHANCEMENT (pemantapan strategi sedia ada).
5. Cadangan mesti ada hasil terukur (outcome) yang boleh diukur.
6. Jangan guna nama pelajar, nama pensyarah atau nombor matrik.`;

export class ZaiProvider implements AiProvider {
  readonly name = 'zai-glm';
  private model: string;

  constructor(model?: string) {
    // Model/base URL configurable via env (PRD 11.1 note: confirm at
    // integration time in official Z.ai docs)
    this.model = model ?? process.env.ZAI_MODEL ?? 'glm-5.3';
  }

  private async callJson(prompt: string): Promise<Record<string, unknown>> {
    const { default: ZAI } = await import('z-ai-web-dev-sdk');
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: SYSTEM_PROMPT },
        { role: 'user', content: prompt },
      ],
      thinking: { type: 'disabled' }, // low reasoning effort for drafting (PRD 11.3)
    });
    const content = completion.choices[0]?.message?.content ?? '';
    // robust JSON extraction (strip code fences / stray prose)
    const match = content.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('AI returned non-JSON output');
    return JSON.parse(match[0]);
  }

  private async withRetry<T>(fn: () => Promise<T>, validate: (raw: Record<string, unknown>) => T): Promise<T> {
    const MAX_ATTEMPTS = 3; // PRD 11.3: reject and retry on invalid output
    let lastError: unknown = null;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      try {
        const raw = await fn();
        return validate(raw);
      } catch (err) {
        lastError = err;
      }
    }
    throw lastError instanceof Error ? lastError : new Error('AI provider failed');
  }

  async draftPunca(anonymousPayload: string, cqiType: string): Promise<PuncaDraft> {
    return this.withRetry(
      () =>
        this.callJson(
          `Data agregat (tanpa pengecam): ${anonymousPayload}\n\nJenis CQI: ${cqiType}.
Tugasan: AI-01 - jana hipotesis Punca daripada data CLO, agihan penilaian dan hasil CQI terdahulu, dikelaskan mengikut enam faktor borang.
Balas JSON: {"hypotheses":[{"factor":"PDP","bm":"...","en":"..."}]} (1-4 hipotesis, paling berkemungkinan dahulu).`,
        ),
      (raw) => PuncaDraftSchema.parse(raw),
    );
  }

  async draftCadangan(anonymousPayload: string, cqiType: string): Promise<CadanganDraft> {
    return this.withRetry(
      () =>
        this.callJson(
          `Data agregat (tanpa pengecam): ${anonymousPayload}\n\nJenis CQI: ${cqiType}.
Tugasan: AI-02 - jana Cadangan CQI bagi sesi akan datang, sepadan dengan jenis CQI tersebut, setiap satu dengan hasil terukur.
Balas JSON: {"proposals":[{"title":"...","bm":"...","en":"...","outcome":"..."}]} (1-3 cadangan).`,
        ),
      (raw) => CadanganDraftSchema.parse(raw),
    );
  }
}

// ---------------- Rule-based fallback (deterministic, no external call) ------

export class FallbackProvider implements AiProvider {
  readonly name = 'fallback-rules';

  async draftPunca(_payload: string, cqiType: string): Promise<PuncaDraft> {
    const base =
      cqiType === 'PREVENTIVE'
        ? {
            factor: 'PDP' as const,
            bm: 'Purata pencapaian menurun berbanding sesi terdahulu; kaedah PdP semasa mungkin kurang berkesan bagi kumpulan pelajar ini (draf automatik bila perkhidmatan AI tidak tersedia).',
            en: 'Attainment is declining versus the previous session; the current PdP method may be less effective for this cohort (auto draft while the AI service is unavailable).',
          }
        : {
            factor: 'PDP' as const,
            bm: 'Sebilangan pelajar tidak mencapai paras CLO; kaedah PdP dan penguasaan asas perlu diperkukuh (draf automatik bila perkhidmatan AI tidak tersedia).',
            en: 'Some students did not reach the CLO level; PdP methods and foundational mastery need strengthening (auto draft while the AI service is unavailable).',
          };
    return {
      hypotheses: [
        base,
        {
          factor: 'DEMOGRAFI',
          bm: 'Latar belakang demografi pelajar berbeza berbanding kohort terdahulu dan memerlukan strategi sokongan berbeza (draf automatik).',
          en: 'Student demographic background differs from prior cohorts and may need different support strategies (auto draft).',
        },
      ],
    };
  }

  async draftCadangan(_payload: string, cqiType: string): Promise<CadanganDraft> {
    const t =
      cqiType === 'CORRECTIVE'
        ? {
            title: 'Bengkel penguasaan asas',
            bm: 'Laksanakan bengkel penguasaan asas dan sesi kaunseling akademik bersasar kepada pelajar yang tidak mencapai CLO; pantau progres dua mingguan.',
            en: 'Run foundational mastery workshops and targeted academic coaching for students below the CLO threshold; monitor progress fortnightly.',
            outcome: '≥ 80% pelajar sasaran mencapai paras CLO dalam ujian selepas bengkel / at least 80% of targeted students reach the CLO level in post-tests',
          }
        : cqiType === 'PREVENTIVE'
          ? {
              title: 'Diagnostik awal semester',
              bm: 'Jalankan ujian diagnostik awal semester dan ubah suai kaedah PdP berdasarkan hasil diagnostik sebelum penurunan berterusan.',
              en: 'Administer an early-semester diagnostic test and adapt PdP based on its results before the decline continues.',
              outcome: 'Pencapaian CLO sesi akan datang ≥ sasaran / next-session CLO attainment meets the target',
            }
          : {
              title: 'Pemantapan strategi sedia ada',
              bm: 'Kekalkan strategi berjaya sedia ada dan tambah aktiviti pengayaan untuk mengekalkan pencapaian di atas sasaran.',
              en: 'Sustain existing successful strategies and add enrichment activities to keep attainment above target.',
              outcome: 'Pencapaian CLO kekal ≥ sasaran / attainment stays at or above the target',
            };
    return { proposals: [t] };
  }
}

// ---------------- Usage metering: rate limit, budget, logging ---------------

export async function checkAiAccess(ctx: AiUsageContext): Promise<{ allowed: boolean; reason?: string; log: AiUsageLog }> {
  const enabled = (await db.setting.findUnique({ where: { key: 'aiEnabled' } }))?.value;
  if (enabled === 'false') {
    return { allowed: false, reason: 'AI_DISABLED', log: { callsToday: 0, monthlyTokens: 0 } };
  }
  const dayStart = new Date();
  dayStart.setHours(0, 0, 0, 0);
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const [callsToday, monthUsage] = await Promise.all([
    db.auditLog.count({
      where: { actorId: ctx.userId, action: `AI_CALL_${ctx.feature}`, at: { gte: dayStart } },
    }),
    db.auditLog.count({ where: { action: 'AI_CALL', at: { gte: monthStart } } }),
  ]);

  const maxPerDay = Number((await db.setting.findUnique({ where: { key: 'aiMaxCallsPerUserPerDay' } }))?.value ?? 20);
  const budget = Number((await db.setting.findUnique({ where: { key: 'aiMonthlyTokenBudget' } }))?.value ?? 1_000_000);

  if (callsToday >= maxPerDay) {
    return { allowed: false, reason: 'RATE_LIMIT', log: { callsToday, monthlyTokens: monthUsage * 800 } };
  }
  // approximate token metering: usage rows store estimated token counts in rowId
  const tokenRows = await db.auditLog.findMany({
    where: { action: 'AI_CALL', at: { gte: monthStart } },
    select: { rowId: true },
  });
  const monthlyTokens = tokenRows.reduce((acc, r) => acc + (Number(r.rowId) || 0), 0);
  if (monthlyTokens >= budget) {
    return { allowed: false, reason: 'BUDGET_CAP', log: { callsToday, monthlyTokens } };
  }
  return { allowed: true, log: { callsToday, monthlyTokens } };
}

/** Log usage only - never prompts or outputs containing content (PRD 11.3). */
export async function logAiUsage(ctx: AiUsageContext, estimatedTokens: number): Promise<void> {
  await db.auditLog.createMany({
    data: [
      {
        actorId: ctx.userId,
        action: `AI_CALL_${ctx.feature}`,
        tableName: 'ai_usage',
        rowId: String(estimatedTokens),
        before: null,
        after: null,
      },
      {
        actorId: ctx.userId,
        action: 'AI_CALL',
        tableName: 'ai_usage',
        rowId: String(estimatedTokens),
        before: null,
        after: null,
      },
    ],
  });
}

const estTokens = (s: string) => Math.ceil(s.length / 4);

/** Resolve the active provider with graceful fallback (PRD 16 AI row). */
export async function getAiProvider(): Promise<AiProvider> {
  const primary = new ZaiProvider();
  try {
    // health probe is cheap: a failing provider is swapped for the fallback at call time
    return primary;
  } catch {
    return new FallbackProvider();
  }
}

export async function runAi<T extends Record<string, unknown>>(
  ctx: AiUsageContext,
  run: (provider: AiProvider) => Promise<T>,
  fallback: () => T,
): Promise<{ ok: true; data: T; provider: string } | { ok: false; data: T; provider: string; error: string }> {
  const access = await checkAiAccess(ctx);
  if (!access.allowed) throw new Error(access.reason === 'AI_DISABLED' ? 'AI_DISABLED' : `AI_LIMITED:${access.reason}`);
  const promptEstimate = 600; // conservative estimate for metering
  try {
    const provider = await getAiProvider();
    const data = await run(provider);
    await logAiUsage(ctx, estTokens(JSON.stringify(data)) + promptEstimate);
    return { ok: true, data, provider: provider.name };
  } catch (err) {
    const fb = new FallbackProvider();
    const data = await run(fb).catch(() => fallback());
    await logAiUsage(ctx, estTokens(JSON.stringify(data)) + 100);
    return { ok: false, data, provider: fb.name, error: err instanceof Error ? err.message : 'AI_ERROR' };
  }
}
