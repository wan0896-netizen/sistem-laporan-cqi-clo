/**
 * Excel exports (FR-RPT-03, FR-RPT-07): attainment tables per offering and
 * consolidated semester exports. exceljs is used server-side only.
 */

import 'server-only';
import ExcelJS from 'exceljs';
import type { AssembledReport } from '@/lib/service';
import { dash, signedDelta, statusTone, STATUS_LABEL, REPORT_STATUS_LABEL } from '@/lib/format';

const HEADER_FILL = 'FFE8EEF7';

function styleHeader(sheet: ExcelJS.Worksheet, row: number) {
  const r = sheet.getRow(row);
  r.font = { bold: true };
  r.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HEADER_FILL } };
    cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
  });
}

export async function buildOfferingWorkbook(data: AssembledReport): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Sistem Laporan CQI Pencapaian CLO - JKM POLISAS';
  const { report, header, comparison, settings } = data;

  // Sheet 1: Ringkasan
  const ws = wb.addWorksheet('Pencapaian CLO');
  ws.columns = [
    { width: 34 }, { width: 22 }, { width: 22 }, { width: 22 }, { width: 16 }, { width: 16 }, { width: 24 },
  ];
  const titleRow = ws.addRow([`Laporan CQI Pencapaian CLO - Borang Ver. ${report.templateVersion}`]);
  titleRow.font = { bold: true, size: 13 };
  ws.addRow([`${header.courseCode} - ${header.courseName}`]);
  ws.addRow([`Program: ${header.programme} | Seksyen: ${header.sectionCodes} | Sesi: ${header.sessionLabel}`]);
  ws.addRow([`Penyelaras: ${header.coordinator} | Status: ${REPORT_STATUS_LABEL[report.status]?.bm ?? report.status}`]);
  ws.addRow([]);

  const head = ['CLO', ...comparison.series.map((s) => `${s.label} (Bil. Pelajar: ${dash(s.studentCount)})`), 'Perubahan (m.p.)', 'Status', 'Isu/Notak'];
  ws.addRow(head);
  styleHeader(ws, ws.rowCount);
  for (const c of comparison.comparisons) {
    const tone = statusTone(c.met, c.declined);
    ws.addRow([
      `${c.code} - ${c.statement}`,
      ...c.series.map((v) => (v === null ? '-' : v)),
      signedDelta(c.delta),
      STATUS_LABEL[tone].bm,
      c.declined ? `Menurun ≥ ${settings.dropThreshold} mata` : c.met === false ? `Di bawah sasaran ${settings.cloTarget}%` : '',
    ]);
  }
  ws.addRow([]);
  ws.addRow([`Kaedah pengiraan: ${settings.attainmentMethod === 'THRESHOLD' ? `Peratusan pelajar mencapai paras skor ${settings.cloScoreThresholdPercent}%` : 'Purata kelas'} | Sasaran: ${settings.cloTarget}% | Ambang penurunan: ${settings.dropThreshold} mata peratusan`]);

  // Sheet 2: Per seksyen (PRD 8.4 per-section figures)
  const ws2 = wb.addWorksheet('Mengikut Seksyen');
  ws2.columns = [{ width: 16 }, { width: 18 }, ...data.comparison.comparisons.map(() => ({ width: 14 }))];
  ws2.addRow(['Seksyen', 'Bil. Pelajar', ...data.comparison.comparisons.map((c) => c.code)]);
  styleHeader(ws2, 1);
  for (const s of data.comparison.perSection) {
    const n = s.attainments[0]?.studentCount ?? 0;
    ws2.addRow([s.sectionCode, n, ...s.attainments.map((a) => (a.attainment === null ? '-' : a.attainment))]);
  }

  // Sheet 3: Rekod pencapaian kurang sasaran
  const ws3 = wb.addWorksheet('Rekod Kurang Sasaran');
  ws3.columns = [{ width: 20 }, { width: 34 }, { width: 16 }, { width: 44 }];
  ws3.addRow(['Sesi', 'Isu Pencapaian CLO', 'CLO Terlibat', 'Tumpuan CQI']);
  styleHeader(ws3, 1);
  const issues = JSON.parse(report.sectionAIssues || '[]') as { sessionLabel: string; hasData: boolean; belowClos: unknown[]; issueCode: string | null; cloInvolved: string | null; focus: string | null; isCurrent: boolean }[];
  for (const row of issues) {
    ws3.addRow([
      row.sessionLabel,
      !row.hasData || row.belowClos.length === 0 ? 'Tiada' : data.lookupLabels?.issue?.[row.issueCode ?? ''] ?? row.issueCode ?? '-',
      row.belowClos.length === 0 ? 'Tiada' : row.cloInvolved ?? '-',
      row.isCurrent ? row.focus ?? '-' : '-',
    ]);
  }
  return wb.xlsx.writeBuffer() as Promise<Buffer>;
}

export interface ConsolidatedRow {
  programme: string;
  courseCode: string;
  courseName: string;
  sessionLabel: string;
  coordinator: string;
  studentCount: number;
  cloResults: { code: string; attainment: number | null; met: boolean | null; delta: number | null; declined: boolean }[];
  reportStatus: string;
  overallType: string | null;
  deadline: Date | null;
  daysLeft: number | null;
}

export async function buildConsolidatedWorkbook(rows: ConsolidatedRow[], sessionLabel: string, target: number): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Sistem Laporan CQI Pencapaian CLO - JKM POLISAS';
  const ws = wb.addWorksheet('Ringkasan Sesi');
  ws.columns = [
    { width: 12 }, { width: 14 }, { width: 30 }, { width: 18 }, { width: 22 }, { width: 12 }, { width: 40 }, { width: 18 }, { width: 14 }, { width: 14 },
  ];
  const title = ws.addRow([`Laporan Konsolidated Sesi ${sessionLabel} - Sasaran CLO ${target}%`]);
  title.font = { bold: true, size: 13 };
  ws.addRow([]);
  ws.addRow(['Program', 'Kod Kursus', 'Nama Kursus', 'Sesi', 'Penyelaras', 'Bil. Pelajar', 'Pencapaian CLO (%)', 'Status Laporan', 'Jenis CQI', 'Hari lagi']);
  styleHeader(ws, ws.rowCount);
  for (const r of rows) {
    const cloText = r.cloResults.map((c) => `${c.code}: ${c.attainment === null ? '-' : c.attainment}${c.declined ? ' (▼≥5)' : c.met === false ? ' (<sasaran)' : ''}`).join('; ');
    ws.addRow([
      r.programme,
      r.courseCode,
      r.courseName,
      r.sessionLabel,
      r.coordinator,
      r.studentCount,
      cloText,
      REPORT_STATUS_LABEL[r.reportStatus]?.bm ?? r.reportStatus,
      r.overallType ?? '-',
      r.daysLeft === null ? '-' : r.daysLeft < 0 ? 'LEWAT' : r.daysLeft,
    ]);
  }
  // summary sheet
  const ws2 = wb.addWorksheet('Ringkasan Program');
  const byProg = new Map<string, { total: number; below: number; declined: number; verified: number; submitted: number }>();
  for (const r of rows) {
    const s = byProg.get(r.programme) ?? { total: 0, below: 0, declined: 0, verified: 0, submitted: 0 };
    s.total += 1;
    if (r.cloResults.some((c) => c.met === false)) s.below += 1;
    if (r.cloResults.some((c) => c.declined)) s.declined += 1;
    if (r.reportStatus === 'VERIFIED' || r.reportStatus === 'CLOSED') s.verified += 1;
    if (r.reportStatus !== 'NOT_STARTED' && r.reportStatus !== 'DRAFT') s.submitted += 1;
    byProg.set(r.programme, s);
  }
  ws2.addRow(['Program', 'Jumlah Penawaran', 'Laporan Dihantar', 'Kadar Penyempurnaan', 'Kursus Ada CLO < Sasaran', 'Kursus Menurun ≥ 5 mata', 'Disahkan']);
  styleHeader(ws2, 1);
  for (const [prog, s] of byProg) {
    ws2.addRow([prog, s.total, s.submitted, `${Math.round((s.submitted / Math.max(s.total, 1)) * 100)}%`, s.below, s.declined, s.verified]);
  }
  return wb.xlsx.writeBuffer() as Promise<Buffer>;
}
