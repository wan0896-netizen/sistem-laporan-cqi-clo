/**
 * Permission Matrix - PRD v3.0 Section 6.1
 * Roles mirror the form's stakeholders. Access control is enforced server-side
 * (deny by default), mirroring the RLS policy matrix (PRD 13.4). In production
 * on Supabase these rules are mirrored as RLS policies; in this build they are
 * enforced in the data-access layer with the same deny-by-default semantics.
 */

export const ROLES = ['lecturer', 'coordinator', 'kk', 'kpro', 'kj', 'quality', 'admin'] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABELS: Record<Role, { bm: string; en: string }> = {
  lecturer: { bm: 'Pensyarah', en: 'Lecturer' },
  coordinator: { bm: 'Penyelaras Kursus', en: 'Course Coordinator' },
  kk: { bm: 'Ketua Kursus (KK)', en: 'Course Leader (KK)' },
  kpro: { bm: 'Ketua Program (KPro)', en: 'Programme Leader (KPro)' },
  kj: { bm: 'Ketua Jabatan (KJ)', en: 'Head of Department (KJ)' },
  quality: { bm: 'Unit Kualiti/Akademik', en: 'Quality/Academic Unit' },
  admin: { bm: 'Pentadbir Sistem', en: 'System Administrator' },
};

export type Capability =
  | 'enter_marks'
  | 'view_attainment'
  | 'edit_report'
  | 'submit_report'
  | 'verify_report'
  | 'dashboard_programme'
  | 'dashboard_department'
  | 'manage_master_data'
  | 'view_audit_log'
  | 'manage_feedback_status'
  | 'archive_session'
  | 'view_all_offerings';

const MATRIX: Record<Capability, Role[]> = {
  enter_marks: ['lecturer', 'coordinator', 'admin'],
  view_attainment: ['lecturer', 'coordinator', 'kk', 'kpro', 'kj', 'quality', 'admin'],
  edit_report: ['lecturer', 'coordinator'],
  submit_report: ['coordinator'],
  verify_report: ['kk', 'kpro', 'kj'],
  dashboard_programme: ['kpro', 'kj', 'quality', 'admin', 'kk', 'coordinator'],
  dashboard_department: ['kj', 'quality', 'admin'],
  manage_master_data: ['admin'],
  view_audit_log: ['kj', 'quality', 'admin'],
  manage_feedback_status: ['kpro', 'admin'],
  archive_session: ['admin', 'kj'],
  view_all_offerings: ['kpro', 'kj', 'quality', 'admin', 'kk'],
};

/** Deny-by-default check: user has the capability if ANY of their roles grants it. */
export function can(roles: Role[], capability: Capability): boolean {
  return roles.some((r) => MATRIX[capability].includes(r));
}

export function matrixFor(capability: Capability): Role[] {
  return MATRIX[capability];
}

/** Verification chain roles that can verify a given report step (FR-WF-03). */
export const CHAIN_ROLES = ['KK', 'KPRO', 'KJ'] as const;
export type ChainRole = (typeof CHAIN_ROLES)[number];

export function roleForChain(chainRole: string): Role {
  return chainRole.toLowerCase() as Role;
}

export function isRole(v: string): v is Role {
  return (ROLES as readonly string[]).includes(v);
}
