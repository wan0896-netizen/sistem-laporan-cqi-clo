/**
 * Business parameters live in the settings table, NOT in code (PRD Section 1:
 * "Rules marked (configurable) live in database settings, not code, because
 * the form is revised between versions"). Defaults match Form Ver. 3.2.
 */

import { db } from '@/lib/db';
import { DEFAULT_CALC_SETTINGS, type CalcSettings } from '@/lib/calculation';

export interface AppSettings {
  cloTarget: number;
  dropThreshold: number;
  comparisonWindow: number;
  attainmentMethod: 'THRESHOLD' | 'AVERAGE';
  cloScoreThresholdPercent: number;
  excludeAbsentBarred: boolean;
  lowSampleThreshold: number;
  aiEnabled: boolean;
  aiMaxCallsPerUserPerDay: number;
  aiMonthlyTokenBudget: number;
  allowedEmailDomains: string;
  departmentName: string;
  institutionName: string;
}

const DEFAULTS: AppSettings = {
  ...DEFAULT_CALC_SETTINGS,
  aiEnabled: true,
  aiMaxCallsPerUserPerDay: 20,
  aiMonthlyTokenBudget: 1_000_000,
  allowedEmailDomains: 'polisas.edu.my',
  departmentName: 'Jabatan Kejuruteraan Mekanikal (JKM)',
  institutionName: 'Politeknik Sultan Haji Ahmad Shah (POLISAS), Kuantan, Malaysia',
};

const NUMERIC_KEYS = new Set([
  'cloTarget',
  'dropThreshold',
  'comparisonWindow',
  'cloScoreThresholdPercent',
  'lowSampleThreshold',
  'aiMaxCallsPerUserPerDay',
  'aiMonthlyTokenBudget',
]);

const BOOL_KEYS = new Set(['excludeAbsentBarred', 'aiEnabled']);

export async function getSettings(): Promise<AppSettings> {
  const rows = await db.setting.findMany();
  const map = new Map(rows.map((r) => [r.key, r.value]));
  const out: Record<string, unknown> = { ...DEFAULTS };
  for (const [key, value] of map) {
    if (!key in DEFAULTS) continue;
    if (NUMERIC_KEYS.has(key)) {
      const n = Number(value);
      if (!Number.isNaN(n)) out[key] = n;
    } else if (BOOL_KEYS.has(key)) {
      out[key] = value === 'true';
    } else {
      out[key] = value;
    }
  }
  return out as AppSettings;
}

export async function getCalcSettings(): Promise<CalcSettings> {
  const s = await getSettings();
  return {
    cloTarget: s.cloTarget,
    dropThreshold: s.dropThreshold,
    comparisonWindow: s.comparisonWindow,
    attainmentMethod: s.attainmentMethod,
    cloScoreThresholdPercent: s.cloScoreThresholdPercent,
    excludeAbsentBarred: s.excludeAbsentBarred,
    lowSampleThreshold: s.lowSampleThreshold,
  };
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db.setting.upsert({ where: { key }, update: { value }, create: { key, value } });
}

export async function setSettingsBulk(values: Record<string, string>): Promise<void> {
  for (const [key, value] of Object.entries(values)) {
    await setSetting(key, value);
  }
}
