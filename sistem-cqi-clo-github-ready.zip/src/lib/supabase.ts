/**
 * Supabase integration — Sistem Laporan CQI Pencapaian CLO (JKM POLISAS)
 *
 * PRD v3.0 stack: Supabase (PostgreSQL) + Vercel. This module centralises all
 * Supabase access so the rest of the app never hard-codes project settings:
 *
 *  - Browser/server clients  -> publishable key (safe, RLS enforced)
 *  - Admin client            -> secret key (server only, bypasses RLS);
 *                               optional: enabled when SUPABASE_SECRET_KEY is set
 *  - Evidence storage (FR-PCQI-05) -> private `evidence` bucket; upload/download
 *                               helpers used by /api/evidence routes with a
 *                               graceful disk fallback while the secret key or
 *                               bucket is not yet provisioned
 *  - Database                -> see .env SUPABASE_DB_URL / SUPABASE_POOLER_URL
 *                               (Prisma postgres swap; supabase/migrations holds
 *                               the DDL). Not reachable until the DB password
 *                               placeholder is replaced by the project owner.
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js';

export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
export const SUPABASE_PUBLISHABLE_KEY = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? '';
export const SUPABASE_SECRET_KEY =
  process.env.SUPABASE_SECRET_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY ?? '';
export const SUPABASE_PROJECT_REF = process.env.SUPABASE_PROJECT_REF ?? '';

/** Private bucket used for CQI evidence files (FR-PCQI-05). */
export const EVIDENCE_BUCKET = 'evidence';

let browserClient: SupabaseClient | null = null;

/** Client for browser code (publishable key, RLS applies). Returns null when not configured. */
export function getSupabaseBrowserClient(): SupabaseClient | null {
  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) return null;
  if (!browserClient) {
    browserClient = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
      auth: { persistSession: true, autoRefreshToken: true },
    });
  }
  return browserClient;
}

/** Client for server code using the publishable key (RLS applies). */
export function getSupabaseServerClient(): SupabaseClient | null {
  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) return null;
  return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: { persistSession: false },
  });
}

/**
 * Server-only admin client using the secret key (bypasses RLS — same trust
 * level as the app's own role guard in lib/api-auth). Returns null until the
 * owner adds SUPABASE_SECRET_KEY to the environment.
 */
export function getSupabaseAdminClient(): SupabaseClient | null {
  if (!SUPABASE_URL || !SUPABASE_SECRET_KEY) return null;
  return createClient(SUPABASE_URL, SUPABASE_SECRET_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

/** True when the secret key is present and Storage operations can run server-side. */
export function supabaseStorageConfigured(): boolean {
  return Boolean(SUPABASE_URL && SUPABASE_SECRET_KEY);
}

/** Object path convention inside the evidence bucket: <yyyy>/<mm>/<id><ext>. */
export function evidenceObjectPath(id: string, ext: string, at: Date = new Date()): string {
  const yyyy = at.getUTCFullYear();
  const mm = String(at.getUTCMonth() + 1).padStart(2, '0');
  return `${yyyy}/${mm}/${id}${ext}`;
}

/** Upload evidence bytes to the private bucket. Throws when Storage is not configured. */
export async function uploadEvidence(
  objectPath: string,
  data: Uint8Array | ArrayBuffer,
  contentType: string,
): Promise<{ path: string }> {
  const admin = getSupabaseAdminClient();
  if (!admin) throw new Error('SUPABASE_SECRET_KEY not configured');
  const body = data instanceof Uint8Array ? data : new Uint8Array(data);
  const { error } = await admin.storage.from(EVIDENCE_BUCKET).upload(objectPath, body, {
    contentType,
    upsert: true,
  });
  if (error) throw new Error(`Supabase Storage upload failed: ${error.message}`);
  return { path: `${EVIDENCE_BUCKET}/${objectPath}` };
}

/** Download evidence bytes server-side (admin client; authorisation stays in the API layer). */
export async function downloadEvidence(
  objectPath: string,
): Promise<{ data: Uint8Array; contentType: string } | null> {
  const admin = getSupabaseAdminClient();
  if (!admin) return null;
  const { data, error } = await admin.storage.from(EVIDENCE_BUCKET).download(objectPath);
  if (error || !data) return null;
  return { data: new Uint8Array(await data.arrayBuffer()), contentType: data.type || 'application/octet-stream' };
}

export interface SupabaseStatus {
  configured: boolean;
  reachable: boolean;
  latencyMs: number | null;
  projectRef: string;
  storageConfigured: boolean;
  dbConfigured: boolean;
  detail: string;
}

/**
 * Health probe used by /api/system/supabase-status: checks that the project URL
 * answers and reports which capabilities are wired (Storage, DB connection).
 */
export async function supabaseStatus(timeoutMs = 6000): Promise<SupabaseStatus> {
  const dbConfigured = Boolean(
    process.env.SUPABASE_DB_URL && !process.env.SUPABASE_DB_URL.includes('[YOUR-DATABASE-PASSWORD]'),
  );
  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
    return {
      configured: false,
      reachable: false,
      latencyMs: null,
      projectRef: SUPABASE_PROJECT_REF,
      storageConfigured: false,
      dbConfigured,
      detail: 'NEXT_PUBLIC_SUPABASE_URL / publishable key tidak ditetapkan',
    };
  }
  const started = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/health`, {
      headers: { apikey: SUPABASE_PUBLISHABLE_KEY },
      signal: controller.signal,
      cache: 'no-store',
    });
    clearTimeout(timer);
    return {
      configured: true,
      reachable: res.ok || res.status === 401, // 401 means the project answered with an auth challenge
      latencyMs: Date.now() - started,
      projectRef: SUPABASE_PROJECT_REF,
      storageConfigured: supabaseStorageConfigured(),
      dbConfigured,
      detail: res.ok ? 'Kesihatan Auth OK' : `Auth /health memulangkan HTTP ${res.status}`,
    };
  } catch (err) {
    clearTimeout(timer);
    return {
      configured: true,
      reachable: false,
      latencyMs: null,
      projectRef: SUPABASE_PROJECT_REF,
      storageConfigured: supabaseStorageConfigured(),
      dbConfigured,
      detail: err instanceof Error ? err.message : 'Sambungan Supabase gagal',
    };
  }
}
