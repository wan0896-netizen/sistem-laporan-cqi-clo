/** Shared API guards (server-side, deny by default - PRD 13.2/13.4). */

import 'server-only';
import { NextResponse } from 'next/server';
import { requireUser, AuthError, getSession, type SessionUser } from '@/lib/auth';
import { can, type Capability } from '@/lib/permissions';
import { db } from '@/lib/db';

export async function guard(capability?: Capability): Promise<{ user: SessionUser } | { error: NextResponse }> {
  try {
    const user = await requireUser();
    if (capability && !can(user.roles, capability)) {
      return { error: NextResponse.json({ error: 'Akses ditolak / Access denied' }, { status: 403 }) };
    }
    return { user };
  } catch (err) {
    if (err instanceof AuthError) {
      return { error: NextResponse.json({ error: err.message }, { status: err.status }) };
    }
    return { error: NextResponse.json({ error: 'Kesalahan pelayan / Server error' }, { status: 500 }) };
  }
}

/**
 * Visibility check mirroring the RLS policy matrix (PRD 13.4): lecturers and
 * coordinators see rows where they are assigned; KK/KPro see their programme;
 * KJ/Quality/Admin read department-wide.
 */
export async function canViewOffering(user: SessionUser, offering: { id?: string; programmeId: string; coordinatorId: string | null }): Promise<boolean> {
  if (user.roles.includes('kj') || user.roles.includes('quality') || user.roles.includes('admin')) return true;
  const programmeIds = user.programmes.filter(Boolean) as string[];
  if (user.roles.some((r) => ['kpro', 'kk'].includes(r)) && programmeIds.includes(offering.programmeId)) return true;
  if (offering.coordinatorId === user.id) return true;
  if (offering.id) {
    const section = await db.section.findFirst({ where: { offeringId: offering.id, lecturerId: user.id } });
    if (section) return true;
  }
  return false;
}

export async function requireOfferingAccess(user: SessionUser, offeringId: string, capability?: Capability) {
  const offering = await db.offering.findUnique({
    where: { id: offeringId },
    include: { sections: true, session: true },
  });
  if (!offering) return { error: NextResponse.json({ error: 'Penawaran tidak dijumpai / Offering not found' }, { status: 404 }) };
  const isAssigned = offering.coordinatorId === user.id || offering.sections.some((s) => s.lecturerId === user.id);
  const programmeIds = user.programmes.filter(Boolean) as string[];
  const programmeScoped = user.roles.includes('kpro') && programmeIds.includes(offering.programmeId);
  const kkScoped = user.roles.includes('kk') && programmeIds.includes(offering.programmeId);
  const deptWide = user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r));
  const canView = isAssigned || programmeScoped || kkScoped || deptWide;
  if (!canView) return { error: NextResponse.json({ error: 'Akses ditolak / Access denied' }, { status: 403 }) };
  if (capability === 'enter_marks' && !isAssigned && !user.roles.includes('admin')) {
    return { error: NextResponse.json({ error: 'Hanya pensyarah/penyelaras kursus boleh kemas kini markah / Only assigned staff can update marks' }, { status: 403 }) };
  }
  if (capability === 'edit_report' && !isAssigned) {
    return { error: NextResponse.json({ error: 'Hanya penyelaras/pensyarah kursus boleh sunting laporan / Only assigned staff can edit the report' }, { status: 403 }) };
  }
  return { offering };
}
