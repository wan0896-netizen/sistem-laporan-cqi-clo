/**
 * Lightweight bilingual dictionary (BM default, EN toggle - FR-CQI-09).
 * Client-side context provider; language persisted in localStorage.
 */

'use client';

import React, { createContext, useContext, useSyncExternalStore, useCallback } from 'react';

export type Lang = 'bm' | 'en';

const dict = {
  // shell
  appName: { bm: 'Sistem Laporan CQI Pencapaian CLO', en: 'CQI CLO Attainment Report System' },
  deptName: { bm: 'Jabatan Kejuruteraan Mekanikal', en: 'Mechanical Engineering Department' },
  institution: { bm: 'Politeknik Sultan Haji Ahmad Shah (POLISAS)', en: 'Sultan Haji Ahmad Shah Polytechnic (POLISAS)' },
  dashboard: { bm: 'Papan Pemuka', en: 'Dashboard' },
  penawaran: { bm: 'Penawaran Kursus', en: 'Course Offerings' },
  verification: { bm: 'Pengesahan', en: 'Verification' },
  registerActions: { bm: 'Daftar Tindakan CQI', en: 'CQI Action Register' },
  registerFeedback: { bm: 'Daftar Maklumbalas Kurikulum', en: 'Curriculum Feedback Register' },
  admin: { bm: 'Pentadbiran', en: 'Administration' },
  logout: { bm: 'Log Keluar', en: 'Sign out' },
  myTasks: { bm: 'Tugasan Saya', en: 'My Tasks' },
  notifications: { bm: 'Pemberitahuan', en: 'Notifications' },
  markAllRead: { bm: 'Tanda semua dibaca', en: 'Mark all read' },
  noNotifications: { bm: 'Tiada pemberitahuan', en: 'No notifications' },
  language: { bm: 'Bahasa', en: 'Language' },

  // login
  signIn: { bm: 'Log Masuk', en: 'Sign in' },
  email: { bm: 'Emel institusi', en: 'Institutional email' },
  password: { bm: 'Kata laluan', en: 'Password' },
  signInTitle: { bm: 'Log masuk ke sistem', en: 'Sign in to the system' },
  demoAccounts: { bm: 'Akaun demo (klik untuk isi)', en: 'Demo accounts (click to fill)' },

  // common
  save: { bm: 'Simpan', en: 'Save' },
  saved: { bm: 'Berjaya disimpan', en: 'Saved successfully' },
  cancel: { bm: 'Batal', en: 'Cancel' },
  submit: { bm: 'Hantar', en: 'Submit' },
  verify: { bm: 'Sahkan (Disahkan)', en: 'Verify (Disahkan)' },
  return: { bm: 'Pulangkan', en: 'Return' },
  status: { bm: 'Status', en: 'Status' },
  course: { bm: 'Kursus', en: 'Course' },
  session: { bm: 'Sesi', en: 'Session' },
  programme: { bm: 'Program', en: 'Programme' },
  sectionClass: { bm: 'Seksyen/Kelas', en: 'Section/Class' },
  coordinator: { bm: 'Penyelaras Kursus', en: 'Course Coordinator' },
  lecturer: { bm: 'Pensyarah', en: 'Lecturer' },
  students: { bm: 'Bil. pelajar', en: 'No. of students' },
  actions: { bm: 'Tindakan', en: 'Actions' },
  open: { bm: 'Buka', en: 'Open' },
  deadline: { bm: 'Tarikh akhir', en: 'Deadline' },
  overdue: { bm: 'Melebihi tarikh akhir', en: 'Overdue' },
  dueIn: { bm: 'hari lagi', en: 'days left' },
  noData: { bm: 'Tiada data', en: 'No data' },
  loading: { bm: 'Sedang memuat...', en: 'Loading...' },
  confirm: { bm: 'Adakah anda pasti?', en: 'Are you sure?' },
  yes: { bm: 'Ya', en: 'Yes' },
  no: { bm: 'Tiada', en: 'None' },
  download: { bm: 'Muat turun', en: 'Download' },
  exportPdf: { bm: 'Eksport PDF (Borang Ver. 3.2)', en: 'Export PDF (Form Ver. 3.2)' },
  exportExcel: { bm: 'Eksport Excel', en: 'Export Excel' },
  printPreview: { bm: 'Pratonton Cetak', en: 'Print Preview' },
  version: { bm: 'Versi', en: 'Version' },
  history: { bm: 'Sejarah', en: 'History' },
  overview: { bm: 'Ringkasan', en: 'Overview' },
  assessments: { bm: 'Penilaian', en: 'Assessment' },
  marks: { bm: 'Markah', en: 'Marks' },
  attainment: { bm: 'Pencapaian', en: 'Attainment' },
  report: { bm: 'Laporan', en: 'Report' },

  // statuses
  stDraft: { bm: 'Draf', en: 'Draft' },
  stUnderVerification: { bm: 'Sedang Pengesahan', en: 'Under Verification' },
  stReturned: { bm: 'Dipulangkan', en: 'Returned' },
  stVerified: { bm: 'Disahkan', en: 'Verified' },
  stClosed: { bm: 'Tutup', en: 'Closed' },
  metTarget: { bm: 'Mencapai Sasaran', en: 'Target Met' },
  notMetTarget: { bm: 'Tidak Mencapai Sasaran', en: 'Not Achieved' },
  declinedFlag: { bm: 'Menurun ≥ 5%', en: 'Declined ≥ 5%' },
  lowSample: { bm: 'Sampel kecil', en: 'Low sample' },

  // report editor
  stepHeader: { bm: 'Maklumat Kursus', en: 'Course Information' },
  stepA: { bm: 'Seksyen A: Analisis Pencapaian CLO', en: 'Section A: CLO Attainment Analysis' },
  stepB: { bm: 'Seksyen B: Status Pelaksanaan CQI Terdahulu', en: 'Section B: Previous CQI Implementation Status' },
  stepC: { bm: 'Seksyen C: Cadangan Pelaksanaan CQI', en: 'Section C: Proposed CQI Implementation' },
  stepD: { bm: 'Seksyen D: Maklumbalas Kurikulum', en: 'Section D: Curriculum Feedback' },
  stepE: { bm: 'Seksyen E: Pengesahan', en: 'Section E: Verification' },
  next: { bm: 'Seterusnya', en: 'Next' },
  back: { bm: 'Kembali', en: 'Back' },
  issueCategory: { bm: 'Isu Pencapaian CLO', en: 'CLO Attainment Issue' },
  cloInvolved: { bm: 'CLO Terlibat', en: 'CLO Involved' },
  cqiFocus: { bm: 'Tumpuan CQI', en: 'CQI Focus' },
  selectPlaceholder: { bm: 'Sila Pilih', en: 'Please Select' },
  recordBelow55: { bm: 'Rekod Pencapaian CLO Kurang 55% Mengikut Sesi', en: 'Record of CLO Attainment Below 55% by Session' },
  previousActions: { bm: 'Tindakan CQI sesi lepas (dibawa ke hadapan)', en: "Previous session's CQI actions (carried forward)" },
  actionActivity: { bm: 'Tindakan/Aktiviti', en: 'Action/Activity' },
  impact: { bm: 'Impak Terhadap Pencapaian CLO', en: 'Impact on CLO Attainment' },
  implementedDate: { bm: 'Tarikh Pelaksanaan', en: 'Implementation Date' },
  evidenceDoc: { bm: 'Dokumen/Bukti Pelaksanaan', en: 'Implementation Document/Evidence' },
  addUnplanned: { bm: 'Tambah tindakan tidak dirancang', en: 'Add unplanned action' },
  uploadEvidence: { bm: 'Muat naik bukti (PDF/JPG/PNG/DOCX, max 5MB)', en: 'Upload evidence (PDF/JPG/PNG/DOCX, max 5MB)' },
  punca: { bm: 'Punca', en: 'Root Cause' },
  cadangan: { bm: 'Cadangan CQI (sesi akan datang)', en: 'Proposed CQI (next session)' },
  jenisCqi: { bm: 'Jenis CQI', en: 'CQI Type' },
  owner: { bm: 'Pelaksana (nama)', en: 'Owner (name)' },
  targetDate: { bm: 'Tarikh sasaran', en: 'Target date' },
  measurableOutcome: { bm: 'Hasil terukur', en: 'Measurable outcome' },
  corrective: { bm: 'Pembetulan (Corrective)', en: 'Corrective' },
  preventive: { bm: 'Pencegahan (Preventive)', en: 'Preventive' },
  enhancement: { bm: 'Penambahbaikan/Pemantapan (Enhancement)', en: 'Enhancement/Sustaining' },
  overrideType: { bm: 'Ubah jenis dengan alasan', en: 'Override type with reason' },
  aiSuggest: { bm: 'Draf AI (GLM)', en: 'AI Draft (GLM)' },
  aiSuggestionLabel: { bm: 'Cadangan AI - wajib disemak dan disunting oleh pensyarah', en: 'AI suggestion - lecturer must review and edit' },
  aiGenerating: { bm: 'Menjana draf AI...', en: 'Generating AI draft...' },
  aiDisabled: { bm: 'Fungsi AI dinyahaktifkan oleh institusi.', en: 'AI features are disabled institution-wide.' },
  rootCauseFactors: { bm: 'Faktor punca (pilih semua yang berkaitan)', en: 'Root-cause factors (select all that apply)' },
  perkara: { bm: 'Perkara', en: 'Topic' },
  maklumbalas: { bm: 'Maklumbalas/Cadangan', en: 'Feedback/Proposal' },
  addFeedbackRow: { bm: 'Tambah baris maklumbalas', en: 'Add feedback row' },
  preparedBy: { bm: 'Disediakan oleh', en: 'Prepared by' },
  verifiedBy: { bm: 'Disahkan oleh', en: 'Verified by' },
  ulasan: { bm: 'Ulasan', en: 'Comments' },
  ulasanRequired: { bm: 'Ulasan wajib apabila memulangkan laporan', en: 'Comments are mandatory when returning a report' },
  submitReport: { bm: 'Hantar Laporan', en: 'Submit Report' },
  submitConfirm: { bm: 'Hantar laporan untuk pengesahan? Angka pencapaian akan direkod sebagai snapshot tetap.', en: 'Submit report for verification? Attainment figures will be locked as an immutable snapshot.' },
  resubmit: { bm: 'Hantar Semula', en: 'Resubmit' },
  amendVersion: { bm: 'Pinda (versi baharu)', en: 'Amend (new version)' },
  likeForLikeWarn: { bm: 'Amaran: Definisi CLO berbeza antara sesi dalam tetingkap perbandingan. Nota diperlukan.', en: 'Warning: CLO definitions differ between sessions in the comparison window. A note is required.' },
  comparisonNote: { bm: 'Nota perbandingan (wajib)', en: 'Comparison note (required)' },
  validationErrors: { bm: 'Ralat pengesahan', en: 'Validation errors' },
  marksIncomplete: { bm: 'Markah belum lengkap', en: 'Marks incomplete' },

  // dashboards
  programmeDashboard: { bm: 'Papan Pemuka Program', en: 'Programme Dashboard' },
  deptDashboard: { bm: 'Papan Pemuka Jabatan', en: 'Department Dashboard' },
  cloHeatmap: { bm: 'Peta haba pencapaian CLO', en: 'CLO attainment heatmap' },
  belowTargetCourses: { bm: 'Kursus di bawah sasaran', en: 'Courses below target' },
  declinedCourses: { bm: 'Kursus menurun ≥ 5 mata', en: 'Courses declining ≥ 5 points' },
  cqiDistribution: { bm: 'Agihan Jenis CQI', en: 'CQI Type Distribution' },
  completionRate: { bm: 'Kadar penyempurnaan', en: 'Completion rate' },
  compliance: { bm: 'Patuhan', en: 'Compliance' },
  filterSession: { bm: 'Sesi', en: 'Session' },
  filterProgramme: { bm: 'Program', en: 'Programme' },
  filterCourse: { bm: 'Kursus', en: 'Course' },
  filterTopic: { bm: 'Perkara', en: 'Topic' },
  filterStatus: { bm: 'Status', en: 'Status' },

  // marks
  importMarks: { bm: 'Import Markah (CSV/Excel)', en: 'Import Marks (CSV/Excel)' },
  downloadTemplate: { bm: 'Muat turun templat', en: 'Download template' },
  addStudent: { bm: 'Tambah pelajar', en: 'Add student' },
  matric: { bm: 'No. Matrik', en: 'Matric No.' },
  validateFirst: { bm: 'Sahkan dahulu untuk lihat laporan pengesahan', en: 'Validate first to see the row-level validation report' },
  commit: { bm: 'Komiti Import', en: 'Commit Import' },
  rowsValid: { bm: 'baris sah', en: 'valid rows' },
  rowsError: { bm: 'baris ralat', en: 'error rows' },
  absent: { bm: 'TG', en: 'Absent' },
  barred: { bm: 'LARANG', en: 'Barred' },
  exempted: { bm: 'BEBAS', en: 'Exempted' },
  normal: { bm: 'Biasa', en: 'Normal' },

  // admin
  users: { bm: 'Pengguna', en: 'Users' },
  programmes: { bm: 'Program', en: 'Programmes' },
  courses: { bm: 'Kursus', en: 'Courses' },
  clos: { bm: 'CLO', en: 'CLOs' },
  sessions: { bm: 'Sesi', en: 'Sessions' },
  templates: { bm: 'Templat Borang', en: 'Form Templates' },
  lookups: { bm: 'Senarai Dropdown', en: 'Dropdown Lists' },
  settingsTitle: { bm: 'Tetapan', en: 'Settings' },
  auditLog: { bm: 'Log Audit', en: 'Audit Log' },
  add: { bm: 'Tambah', en: 'Add' },
  edit: { bm: 'Sunting', en: 'Edit' },
  delete: { bm: 'Padam', en: 'Delete' },
  roles: { bm: 'Peranan', en: 'Roles' },
  active: { bm: 'Aktif', en: 'Active' },
  newPassword: { bm: 'Kata laluan baharu', en: 'New password' },
  verificationChain: { bm: 'Rantai pengesahan', en: 'Verification chain' },
  effectiveDate: { bm: 'Tarikh berkuatkuasa', en: 'Effective date' },
  updatedDate: { bm: 'Tarikh dikemas kini', en: 'Last updated' },
  publish: { bm: 'Terbitkan', en: 'Publish' },
  runReminders: { bm: 'Jalankan peringatan sekarang', en: 'Run reminders now' },
  lockSession: { bm: 'Kunci Sesi (Arkib)', en: 'Lock Session (Archive)' },

  // offer
  noOfferings: { bm: 'Tiada penawaran kursus di assigned kepada anda.', en: 'No course offerings assigned to you.' },
  verifiedSnapshot: { bm: 'Snapshot pengesahan (tetap)', en: 'Verification snapshot (immutable)' },
  previousSessions: { bm: 'Sesi-sesi sebelum', en: 'Previous sessions' },
} as const;

export type DictKey = keyof typeof dict;

export function t(lang: Lang, key: DictKey): string {
  const entry = dict[key];
  return entry ? entry[lang] : String(key);
}

const LangContext = createContext<{ lang: Lang; setLang: (l: Lang) => void }>({ lang: 'bm', setLang: () => {} });

/** External store so language reads avoid setState-in-effect (React 19 rules). */
const langStore = {
  listeners: new Set<() => void>(),
  get(): Lang {
    if (typeof window === 'undefined') return 'bm';
    return window.localStorage.getItem('cqi_lang') === 'en' ? 'en' : 'bm';
  },
  set(l: Lang) {
    window.localStorage.setItem('cqi_lang', l);
    langStore.listeners.forEach((fn) => fn());
  },
  subscribe(fn: () => void) {
    langStore.listeners.add(fn);
    return () => {
      langStore.listeners.delete(fn);
    };
  },
};

export function LangProvider({ children }: { children: React.ReactNode }) {
  const lang = useSyncExternalStore(langStore.subscribe, langStore.get, () => 'bm' as Lang);
  const setLang = useCallback((l: Lang) => langStore.set(l), []);
  return <LangContext.Provider value={{ lang, setLang }}>{children}</LangContext.Provider>;
}

export function useLang() {
  return useContext(LangContext);
}

export function useT(): (key: DictKey) => string {
  const { lang } = useContext(LangContext);
  return (key: DictKey) => t(lang, key);
}
