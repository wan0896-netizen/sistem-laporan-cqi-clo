/**
 * Server-side data service: loads offering data and the three-session
 * comparison window, computes attainment via the shared pure module, creates
 * snapshots, and assembles full report payloads (PRD 8.2, 9.4, 13.2).
 * "Database enforces, server orchestrates": every mutation path checks role
 * and state inside this layer before writing.
 */

import 'server-only';
import { db } from '@/lib/db';
import { getCalcSettings } from '@/lib/settings';
import {
  buildComparison,
  suggestCqiTypes,
  overallCqiType,
  suggestImpact,
  type WindowOffering,
  type ComparisonResult,
  type CqiSuggestion,
  type CalcSettings,
} from '@/lib/calculation';

export async function loadOfferingFull(offeringId: string) {
  const offering = await db.offering.findUnique({
    where: { id: offeringId },
    include: {
      course: { include: { clos: { orderBy: { code: 'asc' } } } },
      session: true,
      programme: true,
      coordinator: true,
      sections: { include: { lecturer: true }, orderBy: { code: 'asc' } },
      assessments: { include: { items: { orderBy: { label: 'asc' } } } },
      marks: true,
      cloResults: true,
    },
  });
  return offering;
}

export interface WindowData {
  current: NonNullable<Awaited<ReturnType<typeof loadOfferingFull>>>;
  window: {
    offeringId: string;
    sessionLabel: string;
    seqNo: number;
    clos: typeof current.course.clos;
    distinctStudents: number;
  }[];
  settings: CalcSettings;
}

/** Current offering + the N previous sessions of the same course+programme. */
export async function loadWindow(offeringId: string): Promise<{ current: NonNullable<Awaited<ReturnType<typeof loadOfferingFull>>>; prevs: (NonNullable<Awaited<ReturnType<typeof loadOfferingFull>>> | null)[]; settings: CalcSettings }> {
  const current = await loadOfferingFull(offeringId);
  if (!current) throw new Error('OFFERING_NOT_FOUND');
  const settings = await getCalcSettings();
  const siblings = await db.offering.findMany({
    where: { courseId: current.courseId, programmeId: current.programmeId },
    include: {
      session: true,
      course: { include: { clos: { orderBy: { code: 'asc' } } } },
      sections: true,
      assessments: { include: { items: true } },
      marks: true,
      cloResults: true,
    },
  });
  const prevs = siblings
    .filter((o) => o.session.seqNo < current.session.seqNo)
    .sort((a, b) => b.session.seqNo - a.session.seqNo)
    .slice(0, settings.comparisonWindow);
  return { current, prevs, settings };
}

function distinctStudents(marks: { matric: string }[]) {
  return new Set(marks.map((m) => m.matric)).size;
}

function toWindowOffering(off: NonNullable<Awaited<ReturnType<typeof loadOfferingFull>>>): WindowOffering {
  return {
    sessionId: off.sessionId,
    seqNo: off.session.seqNo,
    label: off.session.label,
    term: off.session.term,
    year: off.session.year,
    clos: off.course.clos.map((c) => ({ id: c.id, code: c.code, statement: c.statement, domain: c.domain, version: c.version })),
    items: off.assessments.flatMap((a) => a.items.map((i) => ({ id: i.id, label: `${a.name} · ${i.label}`, maxMarks: i.maxMarks, cloId: i.cloId }))),
    marks: off.marks.map((m) => ({ matric: m.matric, itemId: m.itemId, score: m.score, status: m.status, sectionId: m.sectionId })),
    sections: off.sections.map((s) => ({ id: s.id, code: s.code })),
    cloResults: off.cloResults.length > 0 ? off.cloResults.map((r) => ({ matric: r.matric, cloId: r.cloId, percent: r.percent })) : undefined,
    distinctStudents: distinctStudents(off.marks),
  };
}

/** Full three-session comparison + CQI suggestions for the offering. */
export function computeComparison(
  current: NonNullable<Awaited<ReturnType<typeof loadOfferingFull>>>,
  prevs: (NonNullable<Awaited<ReturnType<typeof loadOfferingFull>>> | null)[],
  settings: CalcSettings,
): { comparison: ComparisonResult; suggestions: CqiSuggestion[] } {
  const windowOfferings: WindowOffering[] = [toWindowOffering(current)];
  for (const prev of prevs) {
    if (prev) windowOfferings.push(toWindowOffering(prev));
    else {
      // placeholder keeps the window length stable; sessions with no data
      // render "-" and are excluded without error (PRD 8.2)
      windowOfferings.push({
        sessionId: `empty-${windowOfferings.length}`,
        seqNo: (windowOfferings[windowOfferings.length - 1]?.seqNo ?? 0) - 1,
        label: '-',
        term: 0,
        year: '-',
        clos: current.course.clos.map((c) => ({ id: c.id, code: c.code, statement: c.statement, domain: c.domain, version: c.version })),
        items: [],
        marks: [],
        sections: [],
        distinctStudents: 0,
      });
    }
  }
  const comparison = buildComparison(windowOfferings, settings);
  const suggestions = suggestCqiTypes(comparison, settings);
  return { comparison, suggestions };
}

/** Immutability guard: submitted/verified reports cannot be edited (FR-CLO-08, FR-WF-05). */
export function assertEditable(status: string, archived: boolean) {
  if (archived) throw new Error('SESSION_LOCKED');
  if (status !== 'DRAFT' && status !== 'RETURNED') {
    throw new Error('REPORT_IMMUTABLE');
  }
}

export interface ReportPayload {
  report: Awaited<ReturnType<typeof db.cqiReport.create>> extends never ? never : {
    id: string;
    status: string;
    version: number;
    templateVersion: string;
    overallType: string | null;
    comparisonNote: string | null;
    sectionAIssues: unknown;
  };
  header: {
    courseCode: string;
    courseName: string;
    coordinator: string;
    programme: string;
    sectionCodes: string;
    sessionLabel: string;
    dept: string;
  };
  comparison: ComparisonResult;
  suggestions: CqiSuggestion[];
  overallSuggested: string | null;
}

export async function ensureDraftReport(offeringId: string): Promise<string> {
  let report = await db.cqiReport.findFirst({
    where: { offeringId, status: { in: ['DRAFT', 'RETURNED'] } },
    orderBy: { version: 'desc' },
    include: { _count: { select: { rows: true } } },
  });
  if (report) {
    // self-healing: drafts created before a rule change may lack auto rows
    if (report._count.rows === 0) {
      const { current, prevs, settings } = await loadWindow(offeringId);
      const { comparison, suggestions } = computeComparison(current, prevs, settings);
      await seedCqiRows(report.id, suggestions, comparison, settings);
    }
    return report.id;
  }
  // create draft + auto-create CQI rows per rule (FR-CQI-01); version must
  // not clash with an existing submitted/verified report of this offering
  const { current, prevs, settings } = await loadWindow(offeringId);
  const { comparison, suggestions } = computeComparison(current, prevs, settings);
  const existingVersions = await db.cqiReport.findMany({ where: { offeringId }, select: { version: true } });
  const nextVersion = existingVersions.length > 0 ? Math.max(...existingVersions.map((v) => v.version)) + 1 : 1;
  report = await db.cqiReport.create({
    data: {
      offeringId,
      templateVersion: '3.2',
      status: 'DRAFT',
      version: nextVersion,
      sectionAIssues: JSON.stringify(sectionAIssuesDraft(comparison, suggestions, settings)),
    },
  });
  await seedCqiRows(report.id, suggestions, comparison, settings);
  return report.id;
}

/** Auto-build the Section A "Rekod Pencapaian CLO Kurang 55% Mengikut Sesi" rows. */
function sectionAIssuesDraft(comparison: ComparisonResult, suggestions: CqiSuggestion[], settings: CalcSettings) {
  const codeOf = (cloId: string) => comparison.comparisons.find((c) => c.cloId === cloId)?.code ?? cloId;
  return comparison.series.map((s) => ({
    sessionLabel: s.label,
    sessionId: s.sessionId,
    isCurrent: s.isCurrent,
    hasData: s.hasData,
    belowClos: Object.entries(s.attainmentByClo)
      .filter(([, v]) => v !== null && (v as number) < settings.cloTarget)
      .map(([cloId, v]) => ({ cloId, code: codeOf(cloId), attainment: v })),
    issueCode: null,
    cloInvolved: null,
    focus: null,
  }));
}

/** One CQI entry per affected CLO with its own type; enhancement fallback row (PRD 8.3). */
export async function seedCqiRows(
  reportId: string,
  suggestions: CqiSuggestion[],
  comparison: ComparisonResult,
  settings: CalcSettings,
) {
  const affected = suggestions.filter((s) => s.affected && s.suggestedType);
  let sortOrder = 0;
  if (affected.length > 0) {
    for (const s of affected) {
      await db.cqiRow.create({
        data: {
          reportId,
          cloId: s.cloId,
          cqiType: s.suggestedType!,
          suggestedType: s.suggestedType,
          proposal: '', // lecturer fills Cadangan CQI (FR-CQI-04)
          sortOrder: sortOrder++,
        },
      });
    }
  } else {
    // FR-CQI-04: Cadangan CQI mandatory in every report even when all CLOs
    // meet target - create the enhancement row for the next session
    await db.cqiRow.create({
      data: {
        reportId,
        cloId: null,
        cqiType: 'ENHANCEMENT',
        suggestedType: 'ENHANCEMENT',
        proposal: '',
        sortOrder: 0,
      },
    });
  }
  const overall = overallCqiType(affected.map((s) => s.suggestedType));
  await db.cqiReport.update({ where: { id: reportId }, data: { overallType: overall ?? 'ENHANCEMENT' } });
}

/** Section B: auto-load CQI actions proposed in the previous session's report (FR-PCQI-01). */
export async function loadPreviousActions(offeringId: string) {
  const { current, prevs, settings } = await loadWindow(offeringId);
  const prev = prevs.find(Boolean);
  if (!prev) return { actions: [] as unknown[], comparison: null as ComparisonResult | null, suggestions: [] as CqiSuggestion[], settings };
  const prevReport = await db.cqiReport.findFirst({
    where: { offeringId: prev.id, status: { in: ['VERIFIED', 'CLOSED', 'UNDER_VERIFICATION'] } },
    orderBy: { version: 'desc' },
    include: { actions: { include: { clo: true, owner: true, evidenceFiles: true } } },
  });
  return {
    actions: prevReport?.actions ?? [],
    comparison: computeComparison(current, prevs, settings).comparison,
    suggestions: computeComparison(current, prevs, settings).suggestions,
    settings,
  };
}

/** Suggest impact per action from the CLO change (FR-PCQI-03). */
export function impactForAction(deltaByClo: Record<string, number | null>, cloId: string | null): string | null {
  if (!cloId) return null;
  return suggestImpact(deltaByClo[cloId] ?? null);
}

// ---------------------------------------------------------------------------
// Full report assembly (report editor + PDF + verification viewer)
// ---------------------------------------------------------------------------

export async function assembleReport(reportId: string) {
  const report = await db.cqiReport.findUnique({
    where: { id: reportId },
    include: {
      offering: {
        include: {
          course: { include: { clos: { orderBy: { code: 'asc' } } } },
          session: true,
          programme: true,
          coordinator: true,
          sections: { orderBy: { code: 'asc' } },
        },
      },
      rows: { orderBy: { sortOrder: 'asc' }, include: { clo: true, owner: true } },
      feedback: { include: { evidence: true } },
      verifications: { include: { user: true }, orderBy: { signedAt: 'asc' } },
      snapshots: { where: { reportId: reportId as string } },
      actions: { include: { clo: true, owner: true, evidenceFiles: true } },
    },
  });
  if (!report) return null;

  const { current, prevs, settings } = await loadWindow(report.offeringId);
  const { comparison, suggestions } = computeComparison(current, prevs, settings);

  // Section B: actions proposed by the previous session's verified report (FR-PCQI-01)
  const prevOffering = prevs.find(Boolean);
  const prevReport = prevOffering
    ? await db.cqiReport.findFirst({
        where: { offeringId: prevOffering.id, status: { in: ['VERIFIED', 'CLOSED'] } },
        orderBy: { version: 'desc' },
        include: { actions: { include: { clo: true, owner: true, evidenceFiles: true } } },
      })
    : null;
  const deltaByClo: Record<string, number | null> = {};
  for (const c of comparison.comparisons) deltaByClo[c.cloId] = c.delta;
  const carriedActions = (prevReport?.actions ?? []).map((a) => ({
    ...a,
    suggestedImpact: impactForAction(deltaByClo, a.cloId),
  }));
  // Section B = carried-forward actions (from previous session's report) +
  // actions created by THIS report (unplanned additions, FR-PCQI-04)
  const sectionBActions = [...carriedActions, ...report.actions];

  const template = await db.formTemplate.findFirst({ where: { versionLabel: report.templateVersion } });
  const chain = JSON.parse(report.offering.programme.verificationChain || '["KK","KPRO","KJ"]') as string[];
  const verifiedRoles = report.verifications.filter((v) => v.decision === 'VERIFIED').map((v) => v.role);
  const requiredRole = chain.find((r) => !verifiedRoles.includes(r)) ?? null;

  // admin-managed dropdown labels (FR-MD-05) for PDF/display
  const lookups = await db.lookup.findMany({ where: { type: { in: ['ISSUE_CATEGORY', 'FEEDBACK_TOPIC'] }, active: true } });
  const lookupLabels = {
    issue: Object.fromEntries(lookups.filter((l) => l.type === 'ISSUE_CATEGORY').map((l) => [l.code, l.labelBm])),
    topic: Object.fromEntries(lookups.filter((l) => l.type === 'FEEDBACK_TOPIC').map((l) => [l.code, l.labelBm])),
  };

  // report figures: submitted reports use their locked snapshot (FR-CLO-08)
  const lockedSnapshot = report.snapshots[0] ?? null;

  return {
    report,
    header: {
      courseCode: report.offering.course.code,
      courseName: report.offering.course.name,
      coordinator: report.offering.coordinator?.fullName ?? '-',
      programme: `${report.offering.programme.code} - ${report.offering.programme.name}`,
      sectionCodes: report.offering.sections.map((s) => s.code).join(', '),
      sessionLabel: report.offering.session.label,
      dept: 'Jabatan Kejuruteraan Mekanikal',
      institution: 'Politeknik Sultan Haji Ahmad Shah (POLISAS)',
    },
    comparison,
    suggestions,
    carriedActions,
    sectionBActions,
    prevReportId: prevReport?.id ?? null,
    chain,
    requiredRole,
    lookupLabels,
    template: template ? { versionLabel: template.versionLabel, effectiveDate: template.effectiveDate, updatedDate: template.updatedDate, layout: JSON.parse(template.layout) } : null,
    lockedSnapshot,
    settings,
  };
}

export type AssembledReport = NonNullable<Awaited<ReturnType<typeof assembleReport>>>;

/** Submission validation (FR-CQI-04/05, FR-CLO-09, PRD 8.3). */
export function validateForSubmission(assembled: AssembledReport): string[] {
  const errors: string[] = [];
  const rows = assembled.report.rows;
  if (rows.length === 0) errors.push('Seksyen C: sekurang-kurangnya satu cadangan CQI diperlukan / Section C requires at least one CQI proposal');
  for (const [i, row] of rows.entries()) {
    if (!row.proposal?.trim()) errors.push(`Seksyen C baris ${i + 1}: Cadangan CQI (sesi akan datang) wajib / Proposal for the next session is mandatory`);
    if ((row.cqiType === 'CORRECTIVE' || row.cqiType === 'PREVENTIVE') && !(row.causeText?.trim() || JSON.parse(row.causeTags || '[]').length > 0)) {
      errors.push(`Seksyen C baris ${i + 1}: Punca wajib untuk CQI ${row.cqiType === 'CORRECTIVE' ? 'Pembetulan' : 'Pencegahan'} / Root cause is mandatory for ${row.cqiType.toLowerCase()} rows`);
    }
    if (row.cqiType !== row.suggestedType && !row.overrideReason?.trim()) {
      errors.push(`Seksyen C baris ${i + 1}: Alasan diperlukan bila mengubah Jenis CQI / A reason is required when overriding the suggested CQI type`);
    }
  }
  if (!assembled.comparison.likeForLike && !assembled.report.comparisonNote?.trim()) {
    errors.push('Nota perbandingan wajib kerana definisi CLO berbeza antara sesi / Comparison note required because CLO definitions differ between sessions');
  }
  if (assembled.comparison.series[0]?.studentCount === null || assembled.comparison.series[0]?.studentCount === 0) {
    errors.push('Tiada data markah atau hasil CLO / No marks or CLO result data');
  }
  return errors;
}

