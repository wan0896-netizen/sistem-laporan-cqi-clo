/**
 * Authentication layer (FR-AUTH-01/02/03)
 * ========================================
 * PRD target: Supabase Auth with roles in `user_roles` injected into the JWT
 * via an auth hook, allow-listed email domains, forced re-login on role change.
 *
 * This build runs without external infrastructure, so the same contract is
 * implemented here:
 *  - Passwords hashed with scrypt (salted), stored on profiles.
 *  - Roles read from the `user_roles` table on every request.
 *  - A signed session token (HMAC-SHA256) carries userId + a roles signature;
 *    when roles change, the signature no longer matches and the session is
 *    rejected -> forced re-login (FR-AUTH-03). Expiry enforces timeout.
 *  - Email domain allow-list enforced at login (ALLOWED_EMAIL_DOMAINS).
 *
 * Swapping to Supabase Auth in production only replaces `verifyCredentials`
 * and `getSession` internals; callers and role checks stay identical.
 */

import 'server-only';
import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import { db } from '@/lib/db';
import type { Role } from '@/lib/permissions';
import { isRole } from '@/lib/permissions';

const COOKIE = 'cqi_session';
const SESSION_HOURS = 8; // FR-AUTH-03 session timeout

function secret(): string {
  return process.env.AUTH_SECRET || process.env.SUPABASE_SERVICE_ROLE_KEY || 'polisas-cqi-dev-secret-do-not-use-in-prod';
}

function b64url(buf: Buffer): string {
  return buf.toString('base64url');
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const candidate = crypto.scryptSync(password, salt, 64).toString('hex');
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(candidate, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function rolesSignature(userId: string): string {
  // signature changes whenever the user's role rows change -> forced re-login
  // (mirrors the Supabase auth hook refreshing the JWT role claim)
  const rows = db.userRole.findMany({ where: { userId } });
  // note: called synchronously by callers via await - see rolesSignatureAsync
  void rows;
  return '';
}

export async function rolesSignatureAsync(userId: string): Promise<string> {
  const rows = await db.userRole.findMany({ where: { userId }, orderBy: { id: 'asc' } });
  return crypto.createHmac('sha256', secret()).update(rows.map((r) => `${r.role}:${r.programmeId ?? ''}`).join('|')).digest('hex').slice(0, 24);
}

export interface SessionUser {
  id: string;
  email: string;
  fullName: string;
  staffId: string | null;
  department: string;
  roles: Role[];
  programmes: (string | null)[]; // programme ids per role row (null = department-wide)
  issuedAt: number;
}

async function createToken(user: SessionUser, rolesSig: string): Promise<string> {
  const payload = {
    uid: user.id,
    email: user.email,
    rsig: rolesSig,
    iat: Date.now(),
    exp: Date.now() + SESSION_HOURS * 3600_000,
  };
  const body = b64url(Buffer.from(JSON.stringify(payload)));
  const sig = crypto.createHmac('sha256', secret()).update(body).digest('base64url');
  return `${body}.${sig}`;
}

async function readToken(token: string): Promise<{ uid: string; rsig: string; iat: number; exp: number } | null> {
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expected = crypto.createHmac('sha256', secret()).update(body).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp < Date.now()) return null; // session timeout
    return payload;
  } catch {
    return null;
  }
}

export async function setSessionCookie(userId: string): Promise<void> {
  const profile = await db.profile.findUniqueOrThrow({ where: { id: userId } });
  const roleRows = await db.userRole.findMany({ where: { userId } });
  const user: SessionUser = {
    id: profile.id,
    email: profile.email,
    fullName: profile.fullName,
    staffId: profile.staffId,
    department: profile.department,
    roles: roleRows.map((r) => r.role as Role).filter(isRole),
    programmes: roleRows.map((r) => r.programmeId),
    issuedAt: Date.now(),
  };
  const token = await createToken(user, await rolesSignatureAsync(userId));
  const store = await cookies();
  store.set(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: SESSION_HOURS * 3600,
  });
}

export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.delete(COOKIE);
}

/** Returns the signed-in user (roles fresh from DB) or null. */
export async function getSession(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (!token) return null;
  const payload = await readToken(token);
  if (!payload) return null;
  const profile = await db.profile.findUnique({ where: { id: payload.uid }, include: { userRoles: true } });
  if (!profile || !profile.active) return null;
  // FR-AUTH-03: forced re-login when roles changed since sign-in
  const sig = await rolesSignatureAsync(profile.id);
  if (sig !== payload.rsig) return null;
  return {
    id: profile.id,
    email: profile.email,
    fullName: profile.fullName,
    staffId: profile.staffId,
    department: profile.department,
    roles: profile.userRoles.map((r) => r.role as Role).filter(isRole),
    programmes: profile.userRoles.map((r) => r.programmeId),
    issuedAt: payload.iat,
  };
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status = 401) {
    super(message);
    this.status = status;
  }
}

/** Server-side guard for route handlers and server actions. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getSession();
  if (!user) throw new AuthError('Sesi tidak sah. Sila log masuk semula. / Invalid session, please sign in again.');
  return user;
}

export async function signIn(email: string, password: string): Promise<{ ok: true; userId: string } | { ok: false; error: string }> {
  const normalized = email.trim().toLowerCase();
  const profile = await db.profile.findUnique({ where: { email: normalized }, include: { userRoles: true } });
  if (!profile || !profile.active) return { ok: false, error: 'Email atau kata laluan tidak sah. / Invalid email or password.' };

  // FR-AUTH-01: restricted to approved domains/allow-list
  const allowRaw = (await db.setting.findUnique({ where: { key: 'allowedEmailDomains' } }))?.value ?? 'polisas.edu.my';
  const allowed = allowRaw.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  const domain = normalized.split('@')[1] ?? '';
  if (allowed.length > 0 && allowed[0] !== '*' && !allowed.includes(domain)) {
    return { ok: false, error: `Domain email tidak dibenarkan (${allowed.join(', ')}). / Email domain not allowed.` };
  }
  if (!verifyPassword(password, profile.passwordHash)) {
    return { ok: false, error: 'Email atau kata laluan tidak sah. / Invalid email or password.' };
  }
  return { ok: true, userId: profile.id };
}

// keep tree-shakers happy: rolesSignature (sync stub) is intentionally unused
void rolesSignature;
