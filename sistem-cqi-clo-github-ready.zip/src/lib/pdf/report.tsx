/**
 * PDF export replicating Borang Laporan CQI Kursus Ver. 3.2 (FR-RPT-01).
 * Built with @react-pdf/renderer (server-side, no headless Chromium - PRD 13.7).
 * Layout config comes from the stored form template (FR-RPT-02), so a new
 * template version drives the output without code change where structure allows.
 * The comparison chart is drawn as SVG rects (FR-CLO-05).
 */

import React from 'react';
import { Document, Page, Text, View, StyleSheet, Svg, Rect, Line, G, renderToBuffer } from '@react-pdf/renderer';
import type { AssembledReport } from '@/lib/service';
import { CAUSE_FACTORS } from '@/lib/calculation';

const FORM_META = {
  effectiveBm: 'Berkuatkuasa: Januari 2026',
  updatedBm: 'Dikemas kini: Jun 2026',
};

const colors = {
  border: '#555555',
  headerBg: '#e8eef7',
  zebra: '#f5f7fa',
  text: '#111111',
  muted: '#444444',
  met: '#2e7d32',
  notMet: '#c62828',
  declined: '#ef6c00',
};

const styles = StyleSheet.create({
  page: { paddingTop: 28, paddingBottom: 42, paddingHorizontal: 32, fontSize: 8.5, fontFamily: 'Helvetica', color: colors.text },
  headerBox: { textAlign: 'center', marginBottom: 8 },
  institution: { fontSize: 10, fontFamily: 'Helvetica-Bold' },
  department: { fontSize: 9, fontFamily: 'Helvetica-Bold', marginTop: 1 },
  title: { fontSize: 10.5, fontFamily: 'Helvetica-Bold', marginTop: 6 },
  sessionLine: { fontSize: 9, marginTop: 2 },
  sectionHeader: { backgroundColor: colors.headerBg, borderStyle: 'solid', borderWidth: 1, borderColor: colors.border, padding: 4, fontSize: 9.5, fontFamily: 'Helvetica-Bold', marginTop: 10 },
  tableRow: { flexDirection: 'row', borderLeftWidth: 1, borderRightWidth: 1, borderBottomWidth: 1, borderColor: colors.border },
  tableHeadRow: { flexDirection: 'row', borderTopWidth: 1, borderLeftWidth: 1, borderRightWidth: 1, borderColor: colors.border, backgroundColor: colors.headerBg, fontFamily: 'Helvetica-Bold' },
  cell: { padding: 3.5, borderRightWidth: 0.75, borderColor: colors.border, flexWrap: 'wrap' },
  bold: { fontFamily: 'Helvetica-Bold' },
  kvRow: { flexDirection: 'row', borderLeftWidth: 1, borderRightWidth: 1, borderColor: colors.border },
  kvLabel: { width: '32%', padding: 3.5, fontFamily: 'Helvetica-Bold', borderWidth: 0.75, borderColor: colors.border },
  kvValue: { flex: 1, padding: 3.5, borderWidth: 0.75, borderColor: colors.border },
  chartBox: { borderLeftWidth: 1, borderRightWidth: 1, borderBottomWidth: 1, borderColor: colors.border, padding: 8 },
  chartTitle: { fontSize: 8.5, fontFamily: 'Helvetica-Bold', marginBottom: 4 },
  legendRow: { flexDirection: 'row', marginTop: 5, gap: 8 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 3, fontSize: 7.5 },
  legendSwatch: { width: 7, height: 7 },
  signatureRow: { flexDirection: 'row', gap: 12, marginTop: 10 },
  signatureBox: { flex: 1, borderStyle: 'solid', borderWidth: 1, borderColor: colors.border, padding: 8, minHeight: 92 },
  sigLabel: { fontSize: 8.5, fontFamily: 'Helvetica-Bold' },
  sigLine: { marginTop: 22, borderTopWidth: 0.75, borderColor: colors.border, paddingTop: 3, fontSize: 7.5, color: colors.muted },
  footer: { position: 'absolute', bottom: 22, left: 32, right: 32, textAlign: 'center', fontSize: 7.5, color: colors.muted, borderTopWidth: 0.75, borderColor: colors.border, paddingTop: 4 },
  smallNote: { fontSize: 7.5, color: colors.muted, marginTop: 3 },
});

function fmtPct(v: number | null | undefined): string {
  if (v === null || v === undefined) return '-';
  return `${Math.round(v * 10) / 10}%`;
}

function fmtDateStr(d: Date | string | null | undefined): string {
  if (!d) return '-';
  const date = typeof d === 'string' ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return '-';
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  return `${dd}/${mm}/${date.getFullYear()}`;
}

const Cell = ({ w, children, align }: { w?: string; children: React.ReactNode; align?: 'left' | 'center' }) => (
  <View style={[styles.cell, w ? { width: w } : { flex: 1 }]}>
    <Text style={align === 'center' ? { textAlign: 'center' } : undefined}>{children}</Text>
  </View>
);

const HeadCell = ({ w, children }: { w?: string; children: React.ReactNode }) => (
  <View style={[styles.cell, w ? { width: w } : { flex: 1 }]}>
    <Text style={styles.bold}>{children}</Text>
  </View>
);

const SESSION_BAR_COLORS = ['#1565c0', '#6a1b9a', '#ef6c00', '#00695c'];

/** Simple grouped bar chart with 55% target line (FR-CLO-05). */
function ComparisonChart({ series, comparisons, target }: { series: AssembledReport['comparison']['series']; comparisons: AssembledReport['comparison']['comparisons']; target: number }) {
  const W = 500;
  const H = 150;
  const padL = 28;
  const padB = 26;
  const padT = 10;
  const plotW = W - padL - 10;
  const plotH = H - padB - padT;
  const groupCount = Math.max(comparisons.length, 1);
  const groupW = plotW / groupCount;
  const barCount = series.length;
  const barW = Math.min(34, (groupW - 10) / Math.max(barCount, 1));
  const yFor = (v: number) => padT + plotH - (v / 100) * plotH;

  return (
    <View style={styles.chartBox}>
      <Text style={styles.chartTitle}>Graf Perbandingan Pencapaian CLO Mengikut Sesi (Sasaran {target}%)</Text>
      <Svg width={W} height={H}>
        {[0, 25, 50, 75, 100].map((v) => (
          <G key={v}>
            <Line x1={padL} y1={yFor(v)} x2={W - 10} y2={yFor(v)} stroke="#cccccc" strokeWidth={0.6} />
            <Text x={padL - 3} y={yFor(v) + 2} fontSize={6.5} fill="#555555" textAnchor="end">{v}</Text>
          </G>
        ))}
        <Line x1={padL} y1={yFor(target)} x2={W - 10} y2={yFor(target)} stroke={colors.notMet} strokeWidth={1.2} />
        <Text x={W - 12} y={yFor(target) - 2} fontSize={6.5} fill={colors.notMet} textAnchor="end">Sasaran {target}%</Text>
        {comparisons.map((c, gi) => (
          <G key={c.cloId}>
            {series.map((s, si) => {
              const v = c.series[si];
              if (v === null || v === undefined || !s.hasData) return null;
              const x = padL + gi * groupW + (groupW - barCount * barW) / 2 + si * barW + 1;
              return <Rect key={si} x={x} y={yFor(v)} width={barW - 3} height={plotH + padT - yFor(v)} fill={si === 0 ? (v >= target ? colors.met : colors.notMet) : SESSION_BAR_COLORS[si % 4]} />;
            })}
            <Text x={padL + gi * groupW + groupW / 2} y={H - padB + 10} fontSize={7} fill="#333333" textAnchor="middle">{c.code}</Text>
          </G>
        ))}
      </Svg>
      <View style={styles.legendRow}>
        {series.map((s, si) => (
          <View key={s.sessionId} style={styles.legendItem}>
            {si === 0 ? (
              <View style={{ flexDirection: 'row' }}>
                <View style={[styles.legendSwatch, { backgroundColor: colors.met }]} />
                <View style={[styles.legendSwatch, { backgroundColor: colors.notMet }]} />
              </View>
            ) : (
              <View style={[styles.legendSwatch, { backgroundColor: SESSION_BAR_COLORS[si % 4] }]} />
            )}
            <Text>{si === 0 ? `${s.label} (n=${s.studentCount ?? '-'}) · semasa` : `${s.label} (n=${s.studentCount ?? '-'})`}</Text>
          </View>
        ))}
        <View style={styles.legendItem}>
          <View style={[styles.legendSwatch, { backgroundColor: colors.notMet }]} />
          <Text>Bar merah = di bawah sasaran</Text>
        </View>
      </View>
    </View>
  );
}

export function ReportPdfDocument({ data }: { data: AssembledReport }) {
  const { report, header, comparison, suggestions, sectionBActions, template, settings } = data;
  const layout = (template?.layout ?? {}) as {
    titleBm?: string;
    footerBm?: string;
    sections?: Record<string, string>;
  };
  const sections = layout.sections ?? {};
  const target = settings.cloTarget;
  const issues = JSON.parse(report.sectionAIssues || '[]') as {
    sessionLabel: string;
    isCurrent: boolean;
    hasData: boolean;
    belowClos: { code?: string; cloId: string; attainment: number | null }[];
    issueCode: string | null;
    cloInvolved: string | null;
    focus: string | null;
  }[];

  const causeLabel = (tagsJson: string) => {
    try {
      const tags = JSON.parse(tagsJson || '[]') as string[];
      const labels = tags.map((t) => CAUSE_FACTORS.find((f) => f.code === t)?.bm ?? t);
      return labels.join('; ');
    } catch {
      return '';
    }
  };

  const impactCell = (impact: string | null, impactText: string | null, cloCode: string | null, delta: number | null) => {
    const map: Record<string, string> = { IMPROVED: 'Meningkat / Improved', NO_CHANGE: 'Tiada perubahan / No change', DECLINED: 'Menurun / Declined' };
    const parts: string[] = [];
    if (impact) parts.push(`${cloCode ? `${cloCode}: ` : ''}${map[impact] ?? impact}${delta !== null && delta !== undefined ? ` (Δ ${delta > 0 ? '+' : ''}${delta} m.p.)` : ''}`);
    if (impactText) parts.push(impactText);
    return parts.join(' - ') || '-';
  };

  return (
    <Document title={`Laporan CQI ${header.courseCode} ${header.sessionLabel}`}>
      <Page size="A4" style={styles.page} wrap>
        {/* Header (Form 3.1) */}
        <View style={styles.headerBox}>
          <Text style={styles.institution}>POLITEKNIK SULTAN HAJI AHMAD SHAH (POLISAS), KUANTAN, MALAYSIA</Text>
          <Text style={styles.department}>JABATAN KEJURUTERAAN MEKANIKAL (JKM)</Text>
          <Text style={styles.title}>{layout.titleBm ?? 'Laporan Penambahbaikan Kualiti Berterusan (CQI) Pencapaian CLO'}</Text>
          <Text style={styles.sessionLine}>Sesi: {header.sessionLabel}</Text>
        </View>

        {/* Maklumat Kursus (Form 3.1) */}
        <View style={styles.sectionHeader}>
          <Text>{sections.header ?? 'MAKLUMAT KURSUS'}</Text>
        </View>
        <View>
          <View style={styles.kvRow}>
            <View style={styles.kvLabel}><Text>Kod &amp; Nama Kursus</Text></View>
            <View style={styles.kvValue}><Text>{header.courseCode} - {header.courseName}</Text></View>
          </View>
          <View style={styles.kvRow}>
            <View style={styles.kvLabel}><Text>Nama Penyelaras Kursus</Text></View>
            <View style={styles.kvValue}><Text>{header.coordinator}</Text></View>
          </View>
          <View style={styles.kvRow}>
            <View style={styles.kvLabel}><Text>Program</Text></View>
            <View style={styles.kvValue}><Text>{header.programme}</Text></View>
          </View>
          <View style={styles.kvRow}>
            <View style={styles.kvLabel}><Text>Seksyen/Kelas</Text></View>
            <View style={styles.kvValue}><Text>{header.sectionCodes}</Text></View>
          </View>
        </View>

        {/* Section A (Form 3.2) */}
        <View style={styles.sectionHeader}>
          <Text>{sections.a ?? 'SEKSYEN A: LAPORAN ANALISIS PENCAPAIAN CLO'}</Text>
        </View>
        <View style={styles.tableHeadRow}>
          <HeadCell w="17%">CLO</HeadCell>
          {comparison.series.map((s) => (
            <HeadCell key={s.sessionId} w={`${83 / comparison.series.length}%`}>
              {s.label}
              {'\n'}
              (Bil. Pelajar: {s.studentCount ?? '-'})
            </HeadCell>
          ))}
        </View>
        {comparison.comparisons.map((c, i) => (
          <View key={c.cloId} style={[styles.tableRow, { backgroundColor: i % 2 === 1 ? colors.zebra : '#ffffff' }]}>
            <View style={[styles.cell, { width: '17%' }]}>
              <Text style={styles.bold}>{c.code}</Text>
              <Text style={{ fontSize: 6.5, color: colors.muted }}>{c.statement}</Text>
            </View>
            {c.series.map((v, si) => (
              <View key={si} style={[styles.cell, { width: `${83 / c.series.length}%` }]}>
                <Text style={{ textAlign: 'center' }}>{fmtPct(v)}</Text>
                {si === 0 && v !== null && (
                  <Text style={{ fontSize: 6.5, color: v < target ? colors.notMet : c.declined ? colors.declined : colors.met, textAlign: 'center' }}>
                    {v < target ? 'TIDAK MENCAPAI SASARAN' : c.declined ? 'MENURUN ≥ 5%' : 'MENCAPAI SASARAN'}
                    {c.currentStudentCount > 0 && c.currentStudentCount < settings.lowSampleThreshold ? ' · SAMPEL KECIL' : ''}
                  </Text>
                )}
              </View>
            ))}
          </View>
        ))}
        <Text style={styles.smallNote}>Perubahan berbanding sesi terdahulu: {comparison.comparisons.map((c) => `${c.code} ${c.delta === null ? '-' : `${c.delta > 0 ? '+' : ''}${c.delta} m.p.`}`).join(' | ')} · Kaedah: {settings.attainmentMethod === 'THRESHOLD' ? `Peratusan pelajar mencapai paras skor ${settings.cloScoreThresholdPercent}%` : 'Purata kelas'}</Text>
        {!comparison.likeForLike && (
          <Text style={styles.smallNote}>Amaran: Definisi CLO tidak setara antara sesi (perbandingan bukan like-for-like). {report.comparisonNote ? `Nota: ${report.comparisonNote}` : ''}</Text>
        )}
        <View style={{ marginTop: 6 }}>
          <ComparisonChart series={comparison.series} comparisons={comparison.comparisons} target={target} />
        </View>

        {/* Rekod Pencapaian CLO Kurang 55% Mengikut Sesi (FR-CLO-06/07) */}
        <View style={styles.sectionHeader}>
          <Text>{sections.aRecord ?? 'REKOD PENCAPAIAN CLO KURANG 55% MENGIKUT SESI'}</Text>
        </View>
        <View style={styles.tableHeadRow}>
          <HeadCell w="17%">Sesi</HeadCell>
          <HeadCell w="30%">Isu Pencapaian CLO</HeadCell>
          <HeadCell w="18%">CLO Terlibat</HeadCell>
          <HeadCell w="35%">Tumpuan CQI (sesi semasa)</HeadCell>
        </View>
        {issues.map((row, i) => (
          <View key={i} style={[styles.tableRow, { backgroundColor: i % 2 === 1 ? colors.zebra : '#ffffff' }]}>
            <View style={[styles.cell, { width: '17%' }]}><Text>{row.sessionLabel}</Text></View>
            <View style={[styles.cell, { width: '30%' }]}>
              <Text>{!row.hasData || row.belowClos.length === 0 ? 'Tiada' : data.lookupLabels?.issue?.[row.issueCode ?? ''] ?? row.issueCode ?? '-'}</Text>
            </View>
            <View style={[styles.cell, { width: '18%' }]}><Text>{row.belowClos.length === 0 ? 'Tiada' : row.cloInvolved ?? row.belowClos.map((b) => b.code ?? b.cloId).join(', ')}</Text></View>
            <View style={[styles.cell, { width: '35%' }]}><Text>{row.isCurrent && row.belowClos.length > 0 ? row.focus ?? '-' : '-'}</Text></View>
          </View>
        ))}

        {/* Section B (Form 3.3) */}
        <View style={styles.sectionHeader}>
          <Text>{sections.b ?? 'SEKSYEN B: LAPORAN/STATUS PELAKSANAAN CQI TERDAHULU'}</Text>
        </View>
        <View style={styles.tableHeadRow}>
          <HeadCell w="5%">Bil.</HeadCell>
          <HeadCell w="37%">Tindakan/Aktiviti</HeadCell>
          <HeadCell w="25%">Impak Terhadap Pencapaian CLO</HeadCell>
          <HeadCell w="15%">Tarikh Pelaksanaan</HeadCell>
          <HeadCell w="18%">Dokumen/Bukti Pelaksanaan</HeadCell>
        </View>
        {sectionBActions.length === 0 ? (
          <View style={styles.tableRow}>
            <Cell w="100%">Tiada tindakan CQI terdahulu / No previous CQI actions</Cell>
          </View>
        ) : (
          sectionBActions.map((a, i) => {
            const action = a as unknown as { id: string; description: string; status: string; implementedDate: Date | null; impact: string | null; impactText: string | null; clo?: { code: string } | null; cloId: string | null; evidenceFiles: { fileName: string }[]; unplanned: boolean };
            const cloCode = action.clo?.code ?? comparison.comparisons.find((c) => c.cloId === action.cloId)?.code ?? null;
            const delta = cloCode ? comparison.comparisons.find((c) => c.code === cloCode)?.delta ?? null : null;
            return (
              <View key={action.id} style={[styles.tableRow, { backgroundColor: i % 2 === 1 ? colors.zebra : '#ffffff' }]}>
                <Cell w="5%" align="center">{i + 1}</Cell>
                <Cell w="37%">{action.description}{action.unplanned ? ' (tambahan / unplanned)' : ''}</Cell>
                <Cell w="25%">{impactCell(action.impact, action.impactText, cloCode, delta)}</Cell>
                <Cell w="15%">{fmtDateStr(action.implementedDate)}</Cell>
                <Cell w="18%">{action.evidenceFiles.length > 0 ? action.evidenceFiles.map((e) => e.fileName).join(', ') : '-'}</Cell>
              </View>
            );
          })
        )}

        {/* Section C (Form 3.4) */}
        <View style={styles.sectionHeader}>
          <Text>{sections.c ?? 'SEKSYEN C: CADANGAN PELAKSANAAN CQI (SESI AKAN DATANG)'}</Text>
        </View>
        <View style={styles.tableHeadRow}>
          <HeadCell w="5%">Bil.</HeadCell>
          <HeadCell w="33%">Punca (faktor + huraian)</HeadCell>
          <HeadCell w="37%">Cadangan CQI</HeadCell>
          <HeadCell w="12%">Jenis CQI</HeadCell>
          <HeadCell w="13%">Pelaksana / Tarikh Sasaran</HeadCell>
        </View>
        {report.rows.map((row, i) => {
          const sug = suggestions.find((s) => s.cloId === row.cloId);
          const cloCode = row.clo?.code ?? comparison.comparisons.find((c) => c.cloId === row.cloId)?.code ?? null;
          return (
            <View key={row.id} style={[styles.tableRow, { backgroundColor: i % 2 === 1 ? colors.zebra : '#ffffff' }]}>
              <Cell w="5%" align="center">{i + 1}</Cell>
              <Cell w="33%">
                {cloCode ? `${cloCode}: ` : ''}{causeLabel(row.causeTags) || '-'}{row.causeText ? ` · ${row.causeText}` : ''}
                {sug && sug.attainment !== null && sug.attainment !== undefined ? ` (Pencapaian: ${fmtPct(sug.attainment)}${row.delta !== null && row.delta !== undefined ? `, Δ ${row.delta > 0 ? '+' : ''}${row.delta} m.p.` : ''})` : ''}
              </Cell>
              <Cell w="37%">{row.proposal}{row.outcome ? ` Hasil terukur: ${row.outcome}` : ''}</Cell>
              <Cell w="12%">{row.cqiType === 'CORRECTIVE' ? 'Pembetulan' : row.cqiType === 'PREVENTIVE' ? 'Pencegahan' : 'Penambahbaikan'}</Cell>
              <Cell w="13%">{row.owner?.fullName ?? '-'} · {fmtDateStr(row.targetDate)}</Cell>
            </View>
          );
        })}

        {/* Section D (Form 3.5) */}
        <View style={styles.sectionHeader}>
          <Text>{sections.d ?? 'SEKSYEN D: MAKLUMBALAS KURIKULUM'}</Text>
        </View>
        <View style={styles.tableHeadRow}>
          <HeadCell w="5%">Bil.</HeadCell>
          <HeadCell w="25%">Perkara</HeadCell>
          <HeadCell w="70%">Maklumbalas/Cadangan</HeadCell>
        </View>
        {report.feedback.length === 0 ? (
          <View style={styles.tableRow}>
            <Cell w="100%">Tiada maklumbalas kurikulum / No curriculum feedback</Cell>
          </View>
        ) : (
          report.feedback.map((f, i) => (
            <View key={f.id} style={[styles.tableRow, { backgroundColor: i % 2 === 1 ? colors.zebra : '#ffffff' }]}>
              <Cell w="5%" align="center">{i + 1}</Cell>
              <Cell w="25%">{data.lookupLabels?.topic?.[f.topic] ?? f.topic}</Cell>
              <Cell w="70%">{f.text}</Cell>
            </View>
          ))
        )}

        {/* Section E (Form 3.6) */}
        <View style={styles.sectionHeader}>
          <Text>{sections.e ?? 'SEKSYEN E: PENGESAHAN'}</Text>
        </View>
        <View style={styles.signatureRow}>
          <View style={styles.signatureBox}>
            <Text style={styles.sigLabel}>Disediakan oleh:</Text>
            <Text style={{ marginTop: 4 }}>{report.submittedBy?.fullName ?? header.coordinator}</Text>
            <Text>Penyelaras Kursus</Text>
            <Text>Tarikh: {fmtDateStr(report.submittedAt)}</Text>
            <View style={styles.sigLine}><Text>Tandatangan / Signature</Text></View>
          </View>
          <View style={styles.signatureBox}>
            <Text style={styles.sigLabel}>Disahkan oleh:</Text>
            {report.verifications.length === 0 ? (
              <Text style={{ marginTop: 4, color: colors.muted }}>(menunggu pengesahan)</Text>
            ) : (
              report.verifications.map((v) => (
                <Text key={v.id} style={{ marginTop: 4 }}>
                  {v.user.fullName} ({v.role}) - {v.decision === 'VERIFIED' ? 'Disahkan' : 'Dipulangkan'} - {fmtDateStr(v.signedAt)}
                </Text>
              ))
            )}
            <View style={styles.sigLine}><Text>Tandatangan / Signature (KK/KPro/KJ)</Text></View>
          </View>
        </View>
        {report.verifications.filter((v) => v.comment).length > 0 && (
          <View style={{ marginTop: 6 }}>
            <Text style={styles.bold}>Ulasan (KK/KPro/KJ):</Text>
            {report.verifications.filter((v) => v.comment).map((v) => (
              <Text key={v.id} style={{ marginLeft: 6 }}>
                - {v.role} ({v.user.fullName}): {v.comment}
              </Text>
            ))}
          </View>
        )}

        {/* Footer versioning (Form 3.7, FR-RPT-01) */}
        <View style={styles.footer} fixed>
          <Text>{layout.footerBm ?? 'Borang Laporan CQI Kursus'} Ver. {report.templateVersion} | {FORM_META.effectiveBm} | {FORM_META.updatedBm} | Dijana oleh Sistem Laporan CQI Pencapaian CLO, JKM POLISAS</Text>
        </View>
      </Page>
    </Document>
  );
}

export async function renderReportPdf(data: AssembledReport): Promise<Buffer> {
  const doc = <ReportPdfDocument data={data} />;
  return renderToBuffer(doc);
}
