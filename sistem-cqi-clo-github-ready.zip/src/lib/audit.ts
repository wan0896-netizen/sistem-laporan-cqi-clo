/**
 * Immutable audit log (FR-AD-01) + in-app notifications (FR-NT-01).
 * In production audit_logs is append-only with RLS denying client writes and
 * DB triggers populating rows; here the same records are written server-side
 * only - no route exposes a client write path.
 */

import 'server-only';
import { db } from '@/lib/db';

export async function audit(
  actorId: string | null,
  action: string,
  tableName: string,
  rowId: string | null,
  before?: unknown,
  after?: unknown,
): Promise<void> {
  await db.auditLog.create({
    data: {
      actorId,
      action,
      tableName,
      rowId,
      before: before === undefined ? null : safeJson(before),
      after: after === undefined ? null : safeJson(after),
    },
  });
}

function safeJson(v: unknown): string {
  try {
    return JSON.stringify(
      v,
      (k, val) => (typeof val === 'bigint' ? String(val) : val),
    );
  } catch {
    return String(v);
  }
}

export async function notify(
  userIds: string[],
  type: 'SUBMITTED' | 'RETURNED' | 'VERIFIED' | 'REMINDER' | 'OVERDUE' | 'ESCALATION' | 'SYSTEM',
  messageBm: string,
  messageEn: string,
  refId?: string,
  link?: string,
): Promise<void> {
  const unique = [...new Set(userIds.filter(Boolean))];
  if (unique.length === 0) return;
  await db.notification.createMany({
    data: unique.map((userId) => ({
      userId,
      type,
      refId: refId ?? null,
      messageBm,
      messageEn,
      link: link ?? null,
    })),
  });
}
