/**
 * CLO Attainment & CQI Decision Engine
 * =====================================
 * Pure TypeScript module implementing PRD v3.0 Section 8 (Domain Model and
 * Calculation Rules). This module is the SINGLE SOURCE OF TRUTH for:
 *  - CLO attainment per section and per offering   (FR-CLO-01)
 *  - Three-session comparison with "-" for no data (FR-CLO-02)
 *  - 55% target met / not met status               (FR-CLO-03)
 *  - Change vs previous session, decline >= 5 pts  (FR-CLO-04)
 *  - CQI type decision rule (Corrective/Preventive/Enhancement) (8.3, FR-CQI-02)
 *  - Impact suggestion for Section B               (FR-PCQI-03)
 *
 * Business parameters (55, 5, 2, method...) come from CalcSettings, which the
 * app reads from the `settings` table - never hard-coded (PRD Section 1).
 * Client preview and server snapshot both call these functions, so they cannot
 * diverge (PRD Section 13.2).
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type AttainmentMethod = 'THRESHOLD' | 'AVERAGE';
export type CqiType = 'CORRECTIVE' | 'PREVENTIVE' | 'ENHANCEMENT';

export interface CalcSettings {
  /** CLO achievement target in % (default 55) */
  cloTarget: number;
  /** Significant decline threshold in percentage points (default 5) */
  dropThreshold: number;
  /** Comparison window: number of previous sessions (default 2) */
  comparisonWindow: number;
  /** Department-approved attainment method (default THRESHOLD) */
  attainmentMethod: AttainmentMethod;
  /** Student meets a CLO when their CLO score % >= this (THRESHOLD method) */
  cloScoreThresholdPercent: number;
  /** Exclude ABSENT/BARRED students from attainment denominators */
  excludeAbsentBarred: boolean;
  /** Cohorts smaller than this are flagged as low-sample (open question 8) */
  lowSampleThreshold: number;
}

export const DEFAULT_CALC_SETTINGS: CalcSettings = {
  cloTarget: 55,
  dropThreshold: 5,
  comparisonWindow: 2,
  attainmentMethod: 'THRESHOLD',
  cloScoreThresholdPercent: 50,
  excludeAbsentBarred: true,
  lowSampleThreshold: 20,
};

/** Minimal shapes accepted from Prisma rows (keeps the module storage-agnostic) */
export interface ItemLike {
  id: string;
  label: string;
  maxMarks: number;
  cloId: string | null;
}

export interface MarkLike {
  matric: string;
  itemId: string;
  score: number | null;
  /** null = normal attempt; else ABSENT / BARRED / EXEMPTED (FR-MK-04) */
  status: string | null;
  sectionId: string;
}

export interface CloLike {
  id: string;
  code: string;
  statement: string;
  domain?: string | null;
  version?: number;
}

export interface CloResultLike {
  matric: string;
  cloId: string;
  percent: number;
}

export interface CloAttainment {
  cloId: string;
  code: string;
  statement: string;
  domain?: string | null;
  /** 0-100 or null when no data ("-" on the form) */
  attainment: number | null;
  /** eligible students included in the denominator */
  studentCount: number;
  met: boolean | null;
  lowSample: boolean;
}

export interface SessionSeriesEntry {
  sessionId: string;
  seqNo: number;
  label: string;
  term: number;
  year: string;
  /** distinct students with data; null -> "-" */
  studentCount: number | null;
  /** per CLO attainment 0-100; null -> "-" */
  attainmentByClo: Record<string, number | null>;
  hasData: boolean;
  isCurrent: boolean;
}

export interface CloComparison {
  cloId: string;
  code: string;
  statement: string;
  /** attainment for each window entry (aligned with series[]) */
  series: (number | null)[];
  /** current minus nearest previous session WITH data; null -> "-" */
  delta: number | null;
  met: boolean | null;
  declined: boolean;
  /** label of the session the delta was measured against */
  prevLabel: string | null;
  currentAttainment: number | null;
  currentStudentCount: number;
}

export interface ComparisonResult {
  current: CloAttainment[];
  perSection: { sectionId: string; sectionCode: string; attainments: CloAttainment[] }[];
  series: SessionSeriesEntry[];
  comparisons: CloComparison[];
  belowTarget: CloComparison[];
  declined: CloComparison[];
  anyData: boolean;
  /** FR-CLO-09: CLO definitions differ between sessions */
  likeForLike: boolean;
  cloDifferences: string[];
}

export interface CqiSuggestion {
  cloId: string | null;
  code: string | null;
  attainment: number | null;
  delta: number | null;
  affected: boolean;
  suggestedType: CqiType | null;
  priority: 1 | 2 | 3 | null;
  reasonBm: string;
  reasonEn: string;
}

export type ImpactSuggestion = 'IMPROVED' | 'NO_CHANGE' | 'DECLINED';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

export const round1 = (n: number) => Math.round(n * 10) / 10;

export function sumOf(arr: number[]) {
  return arr.reduce((a, b) => a + b, 0);
}

// ---------------------------------------------------------------------------
// Attainment (8.2)
// ---------------------------------------------------------------------------

/**
 * Per-student CLO score percentage from marks. Items are grouped by their
 * mapped CLO; each item maps to exactly one CLO (FR-AS-01). EXEMPTED items
 * drop out of the denominator; absent/barred handled per configuration
 * (PRD 8.4 edge cases).
 */
export function computeStudentCloPercents(
  marks: MarkLike[],
  items: ItemLike[],
  settings: CalcSettings,
): { cloId: string; matric: string; percent: number | null; excluded: boolean }[] {
  const itemById = new Map(items.map((i) => [i.id, i]));
  const byStudentClo = new Map<
    string,
    { cloId: string; matric: string; got: number; max: number; hasStatusItem: boolean }
  >();

  for (const m of marks) {
    const item = itemById.get(m.itemId);
    if (!item?.cloId) continue;
    const key = `${m.matric}||${item.cloId}`;
    if (!byStudentClo.has(key))
      byStudentClo.set(key, { cloId: item.cloId, matric: m.matric, got: 0, max: 0, hasStatusItem: false });
    const cell = byStudentClo.get(key)!;
    if (m.status === 'EXEMPTED') continue; // excluded from denominator, student stays in cohort
    cell.max += item.maxMarks;
    if (m.status === 'ABSENT' || m.status === 'BARRED') {
      cell.hasStatusItem = true;
      continue;
    }
    if (m.score !== null && m.score !== undefined && !Number.isNaN(m.score)) cell.got += m.score;
  }

  const out: { cloId: string; matric: string; percent: number | null; excluded: boolean }[] = [];
  for (const cell of byStudentClo.values()) {
    const excluded = settings.excludeAbsentBarred && cell.hasStatusItem;
    const percent = cell.max > 0 ? (cell.got / cell.max) * 100 : null;
    out.push({ cloId: cell.cloId, matric: cell.matric, percent, excluded });
  }
  return out;
}

/** Attainment for one cohort (a section, or a whole offering pooled). */
export function attainForCohort(
  percents: { cloId: string; matric: string; percent: number | null; excluded: boolean }[],
  clos: CloLike[],
  settings: CalcSettings,
): CloAttainment[] {
  return clos.map((clo) => {
    const rows = percents.filter((p) => p.cloId === clo.id);
    // students with at least one non-exempt mark for this CLO
    const withData = rows.filter((r) => r.percent !== null);
    const eligible = settings.excludeAbsentBarred ? withData.filter((r) => !r.excluded) : withData;
    const n = eligible.length;
    let attainment: number | null = null;
    if (n > 0) {
      if (settings.attainmentMethod === 'THRESHOLD') {
        const metCount = eligible.filter((r) => (r.percent as number) >= settings.cloScoreThresholdPercent).length;
        attainment = (metCount / n) * 100;
      } else {
        attainment = sumOf(eligible.map((r) => r.percent as number)) / n;
      }
      attainment = round1(attainment);
    }
    return {
      cloId: clo.id,
      code: clo.code,
      statement: clo.statement,
      domain: clo.domain ?? null,
      attainment,
      studentCount: n,
      met: attainment === null ? null : attainment >= settings.cloTarget,
      lowSample: n > 0 && n < settings.lowSampleThreshold,
    };
  });
}

/**
 * Attainment for an offering: consolidated (all sections pooled) and per
 * section (PRD 8.4: multiple sections -> per-section and consolidated).
 * When the offering carries imported per-student CLO results (FR-MK-05),
 * those are used directly; otherwise marks are used.
 */
export function computeOfferingAttainment(
  clos: CloLike[],
  items: ItemLike[],
  marks: MarkLike[],
  sections: { id: string; code: string }[],
  settings: CalcSettings,
  cloResults?: CloResultLike[],
): { current: CloAttainment[]; perSection: { sectionId: string; sectionCode: string; attainments: CloAttainment[] }[] } {
  const useResults = !!(cloResults && cloResults.length > 0);
  const percents = useResults
    ? cloResults!.map((r) => ({ cloId: r.cloId, matric: r.matric, percent: r.percent, excluded: false }))
    : computeStudentCloPercents(marks, items, settings);
  const current = attainForCohort(percents, clos, settings);

  const perSection = sections.map((s) => {
    let cohort = percents;
    if (!useResults) {
      const sectionMarks = marks.filter((m) => m.sectionId === s.id);
      cohort = computeStudentCloPercents(sectionMarks, items, settings);
    } else if (cloResults) {
      const res = cloResults.filter((r) => r.sectionId === s.id);
      if (res.length > 0) cohort = res.map((r) => ({ cloId: r.cloId, matric: r.matric, percent: r.percent, excluded: false }));
    }
    return { sectionId: s.id, sectionCode: s.code, attainments: attainForCohort(cohort, clos, settings) };
  });

  return { current, perSection };
}

// ---------------------------------------------------------------------------
// Three-session comparison (FR-CLO-02, 8.2)
// ---------------------------------------------------------------------------

export interface WindowOffering {
  sessionId: string;
  seqNo: number;
  label: string;
  term: number;
  year: string;
  clos: CloLike[];
  items: ItemLike[];
  marks: MarkLike[];
  sections: { id: string; code: string }[];
  cloResults?: CloResultLike[];
  /** distinct students with any data in this offering */
  distinctStudents: number;
}

/**
 * Build the comparison window: current session + the N previous sessions of
 * the same course. Sessions with no data show "-" and are excluded without
 * error. windowOfferings[0] is the current session; the rest are previous
 * sessions ordered by seqNo descending.
 */
export function buildComparison(windowOfferings: WindowOffering[], settings: CalcSettings): ComparisonResult {
  const currentOff = windowOfferings[0];
  const clos = currentOff.clos;
  const { current, perSection } = computeOfferingAttainment(
    clos,
    currentOff.items,
    currentOff.marks,
    currentOff.sections,
    settings,
    currentOff.cloResults,
  );

  const series: SessionSeriesEntry[] = windowOfferings.map((off, idx) => {
    const att = attainForCohort(
      off.cloResults && off.cloResults.length > 0
        ? off.cloResults.map((r) => ({ cloId: r.cloId, matric: r.matric, percent: r.percent, excluded: false }))
        : computeStudentCloPercents(off.marks, off.items, settings),
      off.clos,
      settings,
    );
    const attainmentByClo: Record<string, number | null> = {};
    for (const a of att) attainmentByClo[a.cloId] = a.attainment;
    const hasData = off.distinctStudents > 0;
    return {
      sessionId: off.sessionId,
      seqNo: off.seqNo,
      label: off.label,
      term: off.term,
      year: off.year,
      studentCount: hasData ? off.distinctStudents : null,
      attainmentByClo: hasData ? attainmentByClo : Object.fromEntries(Object.keys(attainmentByClo).map((k) => [k, null])),
      hasData,
      isCurrent: idx === 0,
    };
  });

  const comparisons: CloComparison[] = clos.map((clo) => {
    const cur = current.find((c) => c.cloId === clo.id);
    const seriesVals = series.map((s) => (s.hasData ? s.attainmentByClo[clo.id] ?? null : null));
    // delta vs the nearest previous session WITH data (a session with no data
    // shows "-" and is excluded without error - PRD 8.2)
    let delta: number | null = null;
    let prevLabel: string | null = null;
    for (let i = 1; i < series.length; i++) {
      if (series[i].hasData && seriesVals[i] !== null && seriesVals[0] !== null) {
        delta = round1((seriesVals[0] as number) - (seriesVals[i] as number));
        prevLabel = series[i].label;
        break;
      }
    }
    return {
      cloId: clo.id,
      code: clo.code,
      statement: clo.statement,
      series: seriesVals,
      delta,
      met: cur?.met ?? null,
      declined: delta !== null && delta <= -settings.dropThreshold,
      prevLabel,
      currentAttainment: cur?.attainment ?? null,
      currentStudentCount: cur?.studentCount ?? 0,
    };
  });

  const belowTarget = comparisons.filter((c) => c.currentAttainment !== null && c.currentAttainment < settings.cloTarget);
  const declined = comparisons.filter((c) => c.declined);

  // FR-CLO-09 / 8.4: like-for-like check across the window
  const cloDifferences: string[] = [];
  const keyOf = (c: CloLike) => `${c.code}|${c.statement}|${c.version ?? 1}`;
  const currentKeys = new Map(clos.map((c) => [c.code, keyOf(c)]));
  for (let i = 1; i < windowOfferings.length; i++) {
    const prev = windowOfferings[i];
    if (!prev.distinctStudents) continue; // no data -> nothing to compare
    for (const pc of prev.clos) {
      const cur = currentKeys.get(pc.code);
      if (!cur) {
        cloDifferences.push(`${pc.code}: wujud dalam ${prev.label} tetapi tiada dalam sesi semasa / exists in ${prev.label} but not in the current session`);
      } else if (cur !== keyOf(pc)) {
        cloDifferences.push(`${pc.code}: definisi CLO berbeza antara ${prev.label} dan sesi semasa / CLO definition differs between ${prev.label} and the current session`);
      }
    }
    for (const cc of clos) {
      if (!prev.clos.some((pc) => pc.code === cc.code)) {
        cloDifferences.push(`${cc.code}: tiada dalam ${prev.label} / missing in ${prev.label}`);
      }
    }
  }

  return {
    current,
    perSection,
    series,
    comparisons,
    belowTarget,
    declined,
    anyData: series[0].hasData,
    likeForLike: cloDifferences.length === 0,
    cloDifferences,
  };
}

// ---------------------------------------------------------------------------
// CQI decision rule (8.3, FR-CQI-01/02)
// ---------------------------------------------------------------------------

export function suggestCqiTypes(cmp: ComparisonResult, settings: CalcSettings): CqiSuggestion[] {
  const out: CqiSuggestion[] = [];
  for (const c of cmp.comparisons) {
    const below = c.currentAttainment !== null && c.currentAttainment < settings.cloTarget;
    const drop = c.declined;
    let suggestedType: CqiType | null = null;
    let priority: 1 | 2 | 3 | null = null;
    let reasonBm = '';
    let reasonEn = '';
    if (below) {
      suggestedType = 'CORRECTIVE';
      priority = 1;
      reasonBm = `Pencapaian ${round1(c.currentAttainment as number)}% < sasaran ${settings.cloTarget}%. Tindakan pembetulan (punca dan cadangan) wajib.`;
      reasonEn = `Attainment ${round1(c.currentAttainment as number)}% < target ${settings.cloTarget}%. Corrective action (root cause and proposal) is mandatory.`;
    } else if (drop) {
      suggestedType = 'PREVENTIVE';
      priority = 2;
      reasonBm = `Penurunan ${Math.abs(c.delta as number)} mata peratusan berbanding ${c.prevLabel}. Tindakan pencegahan diperlukan untuk menghentikan penurunan.`;
      reasonEn = `Drop of ${Math.abs(c.delta as number)} percentage points versus ${c.prevLabel}. Preventive action is required to stop the decline.`;
    } else if (c.currentAttainment !== null) {
      suggestedType = 'ENHANCEMENT';
      priority = 3;
      reasonBm = 'Mencapai sasaran tanpa penurunan ketara. Penambahbaikan / pemantapan strategi sedia ada digalakkan.';
      reasonEn = 'Target met with no significant decline. Enhancement / sustaining of existing strategies is encouraged.';
    } else {
      reasonBm = 'Tiada data pencapaian untuk CLO ini.';
      reasonEn = 'No attainment data for this CLO.';
    }
    out.push({
      cloId: c.cloId,
      code: c.code,
      attainment: c.currentAttainment,
      delta: c.delta,
      affected: below || drop,
      suggestedType,
      priority,
      reasonBm,
      reasonEn,
    });
  }
  return out;
}

/** Report overall type = highest priority present (PRD 8.3). */
export function overallCqiType(types: (CqiType | null | undefined)[]): CqiType | null {
  const t = types.filter(Boolean) as CqiType[];
  if (t.includes('CORRECTIVE')) return 'CORRECTIVE';
  if (t.includes('PREVENTIVE')) return 'PREVENTIVE';
  if (t.includes('ENHANCEMENT')) return 'ENHANCEMENT';
  return null;
}

// ---------------------------------------------------------------------------
// Section B impact suggestion (FR-PCQI-03)
// ---------------------------------------------------------------------------

export function suggestImpact(delta: number | null): ImpactSuggestion | null {
  if (delta === null) return null;
  if (delta >= 1) return 'IMPROVED';
  if (delta <= -1) return 'DECLINED';
  return 'NO_CHANGE';
}

// ---------------------------------------------------------------------------
// Form constants (Ver 3.2) shared by UI and PDF for fidelity
// ---------------------------------------------------------------------------

/** Six root-cause factors from the form (Section 3.4 / FR-CQI-03). */
export const CAUSE_FACTORS = [
  { code: 'KURIKULUM', bm: 'Kandungan kurikulum', en: 'Curriculum content' },
  { code: 'PDP', bm: 'Kaedah Pengajaran dan Pembelajaran (PdP)', en: 'Teaching and learning (PdP) method' },
  { code: 'BAHAN', bm: 'Bahan bantu mengajar / fasiliti', en: 'Teaching aids / facilities' },
  { code: 'PENSYARAH', bm: 'Kompetensi pensyarah', en: 'Lecturer competency' },
  { code: 'DEMOGRAFI', bm: 'Latar belakang demografi pelajar', en: 'Student demographic background' },
  { code: 'SILIBUS', bm: 'Kandungan silibus', en: 'Syllabus content' },
] as const;

export const REPORT_STATUSES = ['DRAFT', 'UNDER_VERIFICATION', 'RETURNED', 'VERIFIED', 'CLOSED'] as const;
export type ReportStatus = (typeof REPORT_STATUSES)[number];
