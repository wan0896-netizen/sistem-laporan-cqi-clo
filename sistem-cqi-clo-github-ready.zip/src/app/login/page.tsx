'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { GraduationCap, Loader2, Wrench } from 'lucide-react';
import { useT } from '@/lib/i18n';

const DEMO_ACCOUNTS = [
  { email: 'penyelaras.dja@polisas.edu.my', role: 'Penyelaras Kursus / Coordinator', desc: 'DJA30132 - kemas markah, lengkap & hantar laporan' },
  { email: 'kk.dja@polisas.edu.my', role: 'Ketua Kursus (KK)', desc: 'Sahkan / pulangkan laporan' },
  { email: 'kpro.dad@polisas.edu.my', role: 'Ketua Program (KPro) - DAD', desc: 'Papan pemuka program + pengesahan' },
  { email: 'kj.jkm@polisas.edu.my', role: 'Ketua Jabatan (KJ)', desc: 'Papan pemuka jabatan + pengesahan akhir' },
  { email: 'quality@polisas.edu.my', role: 'Unit Kualiti', desc: 'Baca sahaja - pematuhan & audit' },
  { email: 'admin@polisas.edu.my', role: 'Pentadbir Sistem', desc: 'Master data, templat, tetapan, log audit' },
];

const DEMO_PASSWORD = 'Polisas#2026';

export default function LoginPage() {
  const router = useRouter();
  const t = useT();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e?: React.FormEvent) {
    e?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? 'Log masuk gagal');
        return;
      }
      router.push('/dashboard');
      router.refresh();
    } catch {
      setError('Kesalahan rangkaian / Network error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Brand panel */}
      <div className="lg:w-1/2 bg-primary text-primary-foreground p-8 lg:p-14 flex flex-col justify-between">
        <div className="flex items-center gap-3">
          <Wrench className="h-8 w-8" aria-hidden />
          <div className="text-sm leading-tight">
            <p className="font-semibold">Jabatan Kejuruteraan Mekanikal</p>
            <p className="opacity-90">Politeknik Sultan Haji Ahmad Shah (POLISAS), Kuantan</p>
          </div>
        </div>
        <div className="my-10 lg:my-0">
          <h1 className="text-3xl lg:text-4xl font-bold leading-tight">Sistem Laporan CQI Pencapaian CLO</h1>
          <p className="mt-4 opacity-90 max-w-md">
            Penambahbaikan Kualiti Berterusan (CQI) Pencapaian CLO - data-driven, sejajar dengan Borang Laporan CQI Kursus Ver. 3.2 (berkuatkuasa Januari 2026, dikemas kini Jun 2026).
          </p>
          <ul className="mt-6 space-y-2 text-sm opacity-90">
            <li>- Pencapaian CLO automatik + perbandingan 3 sesi</li>
            <li>- Pengesanan CLO &lt; 55% dan penurunan ≥ 5 mata peratusan</li>
            <li>- Jenis CQI (Pembetulan/Pencegahan/Penambahbaikan) disarankan sistem</li>
            <li>- Tindakan CQI dibawa ke hadapan + bukti pelaksanaan</li>
            <li>- Pengesahan digital KK/KPro/KJ + eksport PDF Ver. 3.2</li>
          </ul>
        </div>
        <p className="text-xs opacity-75">PDPA 2010: rekod nombor matrik dan markah sahaja. Akses berasaskan peranan.</p>
      </div>

      {/* Login panel */}
      <div className="lg:w-1/2 flex items-center justify-center p-6 lg:p-14">
        <div className="w-full max-w-md space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">{t('signInTitle')}</CardTitle>
              <CardDescription>Emel institusi dalam senarai dibenarkan (allow-list)</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={submit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">{t('email')}</Label>
                  <Input id="email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="nama@polisas.edu.my" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">{t('password')}</Label>
                  <Input id="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <GraduationCap className="h-4 w-4" />}
                  {t('signIn')}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">{t('demoAccounts')}</CardTitle>
              <CardDescription className="text-xs">Kata laluan semua akaun demo: {DEMO_PASSWORD}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {DEMO_ACCOUNTS.map((a) => (
                <button
                  key={a.email}
                  type="button"
                  onClick={() => {
                    setEmail(a.email);
                    setPassword(DEMO_PASSWORD);
                  }}
                  className="w-full text-left rounded-md border p-2.5 hover:bg-accent transition-colors"
                >
                  <p className="text-sm font-medium">{a.role}</p>
                  <p className="text-xs text-muted-foreground">{a.email} - {a.desc}</p>
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
