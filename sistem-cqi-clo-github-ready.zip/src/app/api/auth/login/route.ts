import { NextRequest, NextResponse } from 'next/server';
import { signIn, setSessionCookie, clearSessionCookie, getSession } from '@/lib/auth';
import { audit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const email = (body?.email ?? '').toString();
  const password = (body?.password ?? '').toString();
  if (!email || !password) {
    return NextResponse.json({ error: 'Emel dan kata laluan diperlukan / Email and password required' }, { status: 400 });
  }
  const result = await signIn(email, password);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 401 });
  }
  await setSessionCookie(result.userId);
  await audit(result.userId, 'SIGN_IN', 'profile', result.userId);
  return NextResponse.json({ ok: true });
}

export async function DELETE() {
  const user = await getSession();
  if (user) await audit(user.id, 'SIGN_OUT', 'profile', user.id);
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
