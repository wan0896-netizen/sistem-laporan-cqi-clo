import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { assembleReport } from '@/lib/service';
import { buildOfferingWorkbook, buildConsolidatedWorkbook, type ConsolidatedRow } from '@/lib/excel';
import { loadWindow, computeComparison } from '@/lib/service';
import { audit } from '@/lib/audit';

export const runtime = 'nodejs';

/**
 * GET /api/reports/excel:
 *  - ?reportId=       -> attainment workbook for one report (FR-RPT-03)
 *  - ?sessionId=&programmeId= -> consolidated semester workbook (FR-RPT-07)
 */
export async function GET(req: NextRequest) {
  const g = await guard('view_attainment');
  if ('error' in g) return g.error;
  const reportId = req.nextUrl.searchParams.get('reportId');
  const sessionId = req.nextUrl.searchParams.get('sessionId');
  const programmeId = req.nextUrl.searchParams.get('programmeId');

  if (reportId) {
    const data = await assembleReport(reportId);
    if (!data) return NextResponse.json({ error: 'Laporan tidak dijumpai' }, { status: 404 });
    const access = await requireOfferingAccess(g.user, data.report.offeringId);
    if ('error' in access) return access.error;
    const buffer = await buildOfferingWorkbook(data);
    await audit(g.user.id, 'REPORT_EXCEL_EXPORT', 'cqi_reports', reportId);
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="Pencapaian-CLO-${data.header.courseCode}-${data.header.sessionLabel.replace(/\s+/g, '')}.xlsx"`,
      },
    });
  }

  if (sessionId) {
    // consolidated (FR-RPT-07); KJ/Quality/Admin get department-wide, KPro gets own programme
    const settings = { cloTarget: Number((await db.setting.findUnique({ where: { key: 'cloTarget' } }))?.value ?? 55) };
    const where = { sessionId, ...(programmeId && !g.user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r)) ? { programmeId: programmeId || g.user.programmes.filter(Boolean)[0] } : {}) };
    const offerings = await db.offering.findMany({
      where,
      include: { course: { include: { clos: true } }, session: true, programme: true, coordinator: true, sections: true, reports: { orderBy: { version: 'desc' }, take: 1 } },
    });
    const rows: ConsolidatedRow[] = [];
    for (const off of offerings) {
      const latestReport = off.reports[0];
      let cloResults: ConsolidatedRow['cloResults'] = [];
      try {
        const { current, prevs, settings: calcSettings } = await loadWindow(off.id);
        const { comparison } = computeComparison(current, prevs, calcSettings);
        cloResults = comparison.comparisons.map((c) => ({ code: c.code, attainment: c.currentAttainment, met: c.met, delta: c.delta, declined: c.declined }));
      } catch {
        cloResults = off.course.clos.map((c) => ({ code: c.code, attainment: null, met: null, delta: null, declined: false }));
      }
      rows.push({
        programme: off.programme.code,
        courseCode: off.course.code,
        courseName: off.course.name,
        sessionLabel: off.session.label,
        coordinator: off.coordinator?.fullName ?? '-',
        studentCount: off.sections.reduce((a, s) => a + s.studentCount, 0),
        cloResults,
        reportStatus: latestReport?.status ?? 'NOT_STARTED',
        overallType: latestReport?.overallType ?? null,
        deadline: off.session.deadline,
        daysLeft: off.session.deadline ? Math.ceil((off.session.deadline.getTime() - Date.now()) / 86400_000) : null,
      });
    }
    const session = await db.session.findUnique({ where: { id: sessionId } });
    const buffer = await buildConsolidatedWorkbook(rows, session?.label ?? sessionId, settings.cloTarget);
    await audit(g.user.id, 'CONSOLIDATED_EXCEL_EXPORT', 'sessions', sessionId);
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="Laporan-Konsolidated-${(session?.label ?? sessionId).replace(/\s+/g, '')}.xlsx"`,
      },
    });
  }

  return NextResponse.json({ error: 'reportId atau sessionId diperlukan' }, { status: 400 });
}
