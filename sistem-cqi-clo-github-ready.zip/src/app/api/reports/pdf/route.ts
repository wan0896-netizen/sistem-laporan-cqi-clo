import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { assembleReport } from '@/lib/service';
import { renderReportPdf } from '@/lib/pdf/report';
import { audit } from '@/lib/audit';

/** GET /api/reports/pdf?reportId= - Ver. 3.2 PDF export (FR-RPT-01). */
export const runtime = 'nodejs';
export const maxDuration = 60;

export async function GET(req: NextRequest) {
  const g = await guard('view_attainment');
  if ('error' in g) return g.error;
  const reportId = req.nextUrl.searchParams.get('reportId');
  if (!reportId) return NextResponse.json({ error: 'reportId diperlukan' }, { status: 400 });
  const data = await assembleReport(reportId);
  if (!data) return NextResponse.json({ error: 'Laporan tidak dijumpai' }, { status: 404 });
  const access = await requireOfferingAccess(g.user, data.report.offeringId);
  if ('error' in access) return access.error;

  const buffer = await renderReportPdf(data);
  await audit(g.user.id, 'REPORT_PDF_EXPORT', 'cqi_reports', reportId);
  const fileName = `Laporan-CQI-${data.header.courseCode}-${data.header.sessionLabel.replace(/\s+/g, '')}-v${data.report.version}.pdf`;
  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${fileName}"`,
    },
  });
}
