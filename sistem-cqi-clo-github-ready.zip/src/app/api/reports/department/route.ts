import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { loadWindow, computeComparison } from '@/lib/service';

/**
 * GET /api/reports/department?sessionId=&programmeId=
 * Consolidated department/programme view (FR-RPT-06): attainment by
 * programme, below-target list, decline list, CQI type distribution,
 * completion and compliance. KJ/Quality/Admin: department-wide; KPro/KK:
 * own programme.
 */
export async function GET(req: NextRequest) {
  // Programme dashboard access (PRD 6.1: KPro/KJ/Quality/Admin yes, KK/coordinator
  // limited) - the data below is scoped by role: non-dept-wide users only see
  // their own programme's offerings.
  const g = await guard('dashboard_programme');
  if ('error' in g) return g.error;
  const user = g.user;
  const sessionId = req.nextUrl.searchParams.get('sessionId');
  const programmeParam = req.nextUrl.searchParams.get('programmeId');
  const deptWide = user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r));
  const programmeIds = user.programmes.filter(Boolean) as string[];

  const programmes = await db.programme.findMany({
    where: deptWide ? {} : { id: { in: programmeIds } },
    orderBy: { code: 'asc' },
  });
  const sessions = await db.session.findMany({ orderBy: { seqNo: 'desc' }, take: 6 });
  // default to the most recent session that actually has offerings in scope
  const counts = await db.offering.groupBy({ by: ['sessionId'], _count: { _all: true }, where: deptWide ? {} : { programmeId: { in: programmeIds } } });
  const withOfferings = new Set(counts.filter((c) => c._count._all > 0).map((c) => c.sessionId));
  const defaultSession = sessions.find((s) => withOfferings.has(s.id))?.id ?? sessions[0]?.id ?? null;
  const activeSessionId = sessionId ?? defaultSession;
  if (!activeSessionId) return NextResponse.json({ programmes, sessions, data: null });

  const offeringWhere = {
    sessionId: activeSessionId,
    ...(deptWide ? {} : { programmeId: { in: programmeIds } }),
    ...(programmeParam && deptWide ? { programmeId: programmeParam } : {}),
  };
  const offerings = await db.offering.findMany({
    where: offeringWhere,
    include: {
      course: { include: { clos: true } },
      session: true,
      programme: true,
      coordinator: true,
      sections: true,
      reports: { orderBy: { version: 'desc' }, take: 1 },
    },
  });

  const rows: {
    offeringId: string;
    programme: string;
    courseCode: string;
    courseName: string;
    coordinator: string;
    studentCount: number;
    clos: { cloId: string; code: string; attainment: number | null; met: boolean | null; delta: number | null; declined: boolean; lowSample: boolean }[];
    reportStatus: string;
    reportId: string | null;
    overallType: string | null;
    deadline: Date | null;
    daysLeft: number | null;
    onTime: boolean | null;
  }[] = [];

  const cqiTypeCounts: Record<string, number> = { CORRECTIVE: 0, PREVENTIVE: 0, ENHANCEMENT: 0 };
  let submitted = 0;
  let verified = 0;
  let total = offerings.length;
  let onTimeCount = 0;
  let withDeadline = 0;

  for (const off of offerings) {
    const latest = off.reports[0];
    let clos: (typeof rows)[number]['clos'] = [];
    try {
      const { current, prevs, settings } = await loadWindow(off.id);
      const { comparison } = computeComparison(current, prevs, settings);
      clos = comparison.comparisons.map((c) => ({
        cloId: c.cloId,
        code: c.code,
        attainment: c.currentAttainment,
        met: c.met,
        delta: c.delta,
        declined: c.declined,
        lowSample: c.currentStudentCount > 0 && c.currentStudentCount < settings.lowSampleThreshold,
      }));
    } catch {
      clos = off.course.clos.map((c) => ({ cloId: c.id, code: c.code, attainment: null, met: null, delta: null, declined: false, lowSample: false }));
    }
    const daysLeft = off.session.deadline ? Math.ceil((off.session.deadline.getTime() - Date.now()) / 86400_000) : null;
    const submittedFlag = latest && ['UNDER_VERIFICATION', 'VERIFIED', 'CLOSED', 'RETURNED'].includes(latest.status);
    if (latest && ['CORRECTIVE', 'PREVENTIVE', 'ENHANCEMENT'].includes(latest.overallType ?? '')) {
      cqiTypeCounts[latest.overallType as string] += 1;
    }
    if (submittedFlag) submitted += 1;
    if (latest && ['VERIFIED', 'CLOSED'].includes(latest.status)) verified += 1;
    if (daysLeft !== null) {
      withDeadline += 1;
      if (daysLeft < 0) {
        if (submittedFlag) onTimeCount += 1;
      } else {
        onTimeCount += 1; // still within deadline
      }
    }
    rows.push({
      offeringId: off.id,
      programme: off.programme.code,
      courseCode: off.course.code,
      courseName: off.course.name,
      coordinator: off.coordinator?.fullName ?? '-',
      studentCount: off.sections.reduce((a, s) => a + s.studentCount, 0),
      clos,
      reportStatus: latest?.status ?? 'NOT_STARTED',
      reportId: latest?.id ?? null,
      overallType: latest?.overallType ?? null,
      deadline: off.session.deadline,
      daysLeft,
      onTime: daysLeft === null ? null : daysLeft < 0 ? submittedFlag : true,
    });
  }
  void total;

  const belowTarget = rows.filter((r) => r.clos.some((c) => c.met === false));
  const declined = rows.filter((r) => r.clos.some((c) => c.declined));

  return NextResponse.json({
    programmes,
    sessions,
    activeSessionId,
    rows,
    summary: {
      totalOfferings: offerings.length,
      submitted,
      verified,
      completionRate: offerings.length > 0 ? Math.round((submitted / offerings.length) * 100) : 0,
      complianceRate: withDeadline > 0 ? Math.round((onTimeCount / withDeadline) * 100) : null,
      cqiTypeCounts,
      belowTarget,
      declined,
    },
  });
}
