import { NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { SUPABASE_URL, SUPABASE_PROJECT_REF, supabaseStatus } from '@/lib/supabase';

/**
 * GET Supabase integration status (admin-only): reports whether the project
 * URL answers, whether Storage (secret key) is wired, and whether the direct
 * DB connection string has been completed by the owner (password placeholder
 * replaced). Used by the Admin page "Infrastruktur" card.
 */
export async function GET() {
  const g = await guard('manage_master_data');
  if ('error' in g) return g.error;
  const status = await supabaseStatus();
  return NextResponse.json({
    url: SUPABASE_URL || null,
    projectRef: SUPABASE_PROJECT_REF || null,
    ...status,
  });
}
