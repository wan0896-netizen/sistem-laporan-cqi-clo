import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { audit } from '@/lib/audit';

/**
 * POST /api/assessments (FR-AS-01/02/03):
 *  - body {offeringId, assessments}: replace the assessment structure
 *    (validated: weights 100%, every CLO covered, each item maps one CLO)
 *  - body {offeringId, cloneFrom}: clone structure from the previous session
 *    offering (FR-AS-03)
 */
export async function POST(req: NextRequest) {
  const g = await guard('enter_marks');
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const offeringId = body?.offeringId as string;
  if (!offeringId) return NextResponse.json({ error: 'offeringId diperlukan' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId, 'enter_marks');
  if ('error' in access) return access.error;

  const offering = await db.offering.findUnique({ where: { id: offeringId }, include: { course: { include: { clos: true } }, assessments: true } });
  if (!offering) return NextResponse.json({ error: 'Penawaran tidak dijumpai' }, { status: 404 });

  // ---- clone mode (FR-AS-03) ----
  if (body?.cloneFrom) {
    const source = await db.offering.findUnique({
      where: { id: String(body.cloneFrom) },
      include: { course: { include: { clos: true } }, assessments: { include: { items: true } } },
    });
    if (!source) return NextResponse.json({ error: 'Penawaran sumber tidak dijumpai' }, { status: 404 });
    // map CLO codes -> current offering's CLO ids
    const codeToClo = new Map(offering.course.clos.map((c) => [c.code, c.id]));
    await db.assessment.deleteMany({ where: { offeringId } });
    for (const a of source.assessments) {
      const created = await db.assessment.create({ data: { offeringId, name: a.name, type: a.type, weight: a.weight } });
      for (const item of a.items) {
        const cloId = item.cloId ? codeToClo.get(source.course.clos.find((c) => c.id === item.cloId)?.code ?? '') ?? null : null;
        await db.assessmentItem.create({ data: { assessmentId: created.id, label: item.label, maxMarks: item.maxMarks, cloId } });
      }
    }
    await audit(g.user.id, 'ASSESSMENT_CLONE', 'assessments', offeringId, null, { from: body.cloneFrom });
    return NextResponse.json({ ok: true, cloned: true });
  }

  // ---- replace mode (FR-AS-01/02) ----
  const assessments = (body?.assessments ?? []) as { name: string; type: string; weight: number; items: { label: string; maxMarks: number; cloId: string | null }[] }[];
  const validCloIds = new Set(offering.course.clos.map((c) => c.id));
  const errors: string[] = [];
  const totalWeight = assessments.reduce((acc, a) => acc + (a.weight || 0), 0);
  if (totalWeight !== 100) errors.push(`Jumlah pemberat mesti 100% (sekarang ${totalWeight}%) / Weights must total 100%`);
  const covered = new Set(assessments.flatMap((a) => a.items.map((i) => i.cloId).filter(Boolean)));
  for (const clo of offering.course.clos) {
    if (!covered.has(clo.id)) errors.push(`CLO ${clo.code} tidak diliputi oleh mana-mana item / CLO not covered`);
  }
  for (const a of assessments) {
    if (a.items.length === 0) errors.push(`Penilaian "${a.name}" perlu sekurang-kurangnya satu item`);
    for (const item of a.items) {
      if (!item.cloId || !validCloIds.has(item.cloId)) errors.push(`Item "${item.label}" dalam "${a.name}" tidak dipetakan kepada CLO sah`);
      if (!item.maxMarks || item.maxMarks <= 0) errors.push(`Item "${item.label}" perlu markah penuh > 0`);
    }
  }
  if (errors.length > 0) return NextResponse.json({ error: errors[0], errors }, { status: 422 });

  await db.assessment.deleteMany({ where: { offeringId } });
  for (const a of assessments) {
    const created = await db.assessment.create({ data: { offeringId, name: a.name, type: a.type, weight: a.weight } });
    for (const item of a.items) {
      await db.assessmentItem.create({ data: { assessmentId: created.id, label: item.label, maxMarks: item.maxMarks, cloId: item.cloId } });
    }
  }
  await audit(g.user.id, 'ASSESSMENT_REPLACE', 'assessments', offeringId, null, { count: assessments.length });
  return NextResponse.json({ ok: true });
}
