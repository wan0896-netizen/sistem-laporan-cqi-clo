import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { audit } from '@/lib/audit';
import { hashPassword } from '@/lib/auth';
import { Prisma } from '@prisma/client';

/**
 * Admin master-data API (FR-MD-01..05, FR-RPT-02): GET returns all reference
 * data; POST performs admin CRUD with audit. Admin-only (permission matrix).
 */
export async function GET() {
  const g = await guard('manage_master_data');
  if ('error' in g) return g.error;
  const [programmes, courses, clos, plos, sessions, offerings, users, lookups, templates, settings] = await Promise.all([
    db.programme.findMany({ orderBy: { code: 'asc' } }),
    db.course.findMany({ include: { programmes: true }, orderBy: { code: 'asc' } }),
    db.clo.findMany({ include: { course: true, ploMap: { include: { plo: true } } }, orderBy: { code: 'asc' } }),
    db.plo.findMany({ include: { programme: true }, orderBy: { code: 'asc' } }),
    db.session.findMany({ orderBy: { seqNo: 'asc' } }),
    db.offering.findMany({ include: { course: true, session: true, programme: true, coordinator: true, sections: true }, orderBy: { id: 'asc' } }),
    db.profile.findMany({ include: { userRoles: true }, orderBy: { email: 'asc' } }),
    db.lookup.findMany({ orderBy: [{ type: 'asc' }, { sortOrder: 'asc' }] }),
    db.formTemplate.findMany({ orderBy: { versionLabel: 'desc' } }),
    db.setting.findMany({ orderBy: { key: 'asc' } }),
  ]);
  return NextResponse.json({ programmes, courses, clos, plos, sessions, offerings, users, lookups, templates, settings });
}

export async function POST(req: NextRequest) {
  const g = await guard('manage_master_data');
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const entity = body?.entity as string;
  const action = body?.action as 'create' | 'update' | 'delete';
  const data = body?.data as Record<string, unknown>;
  if (!entity || !action) return NextResponse.json({ error: 'entity dan action diperlukan' }, { status: 400 });

  const d = data as Record<string, string | number | boolean | null | undefined>;
  try {
    switch (entity) {
      case 'programme': {
        if (action === 'create') await db.programme.create({ data: { code: String(d.code), name: String(d.name), level: String(d.level ?? 'Diploma'), verificationChain: d.verificationChain ? JSON.stringify(d.verificationChain) : '["KK","KPRO","KJ"]' } });
        else if (action === 'update') await db.programme.update({ where: { id: String(d.id) }, data: { name: d.name as string | undefined, level: d.level as string | undefined, verificationChain: d.verificationChain ? JSON.stringify(d.verificationChain) : undefined } });
        else await db.programme.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'course': {
        if (action === 'create') await db.course.create({ data: { code: String(d.code), name: String(d.name), credit: Number(d.credit ?? 3) } });
        else if (action === 'update') await db.course.update({ where: { id: String(d.id) }, data: { name: d.name as string | undefined, credit: d.credit as number | undefined } });
        else await db.course.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'clo': {
        if (action === 'create') await db.clo.create({ data: { courseId: String(d.courseId), code: String(d.code), statement: String(d.statement), domain: String(d.domain ?? 'Cognitive'), version: Number(d.version ?? 1) } });
        else if (action === 'update') {
          // version bump when statement changes -> not like-for-like warning (FR-CLO-09)
          const existing = await db.clo.findUnique({ where: { id: String(d.id) } });
          const versionBump = existing && d.statement && existing.statement !== String(d.statement);
          await db.clo.update({ where: { id: String(d.id) }, data: { statement: d.statement as string | undefined, domain: d.domain as string | undefined, version: versionBump ? { increment: 1 } : undefined } });
        } else await db.clo.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'plo': {
        if (action === 'create') await db.plo.create({ data: { programmeId: String(d.programmeId), code: String(d.code), statement: String(d.statement) } });
        else if (action === 'update') await db.plo.update({ where: { id: String(d.id) }, data: { statement: d.statement as string | undefined } });
        else await db.plo.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'session': {
        if (action === 'create') await db.session.create({ data: { label: String(d.label), year: String(d.year), term: Number(d.term), seqNo: Number(d.seqNo), startDate: d.startDate ? new Date(String(d.startDate)) : null, endDate: d.endDate ? new Date(String(d.endDate)) : null, deadline: d.deadline ? new Date(String(d.deadline)) : null, status: String(d.status ?? 'OPEN') } });
        else if (action === 'update') await db.session.update({ where: { id: String(d.id) }, data: { label: d.label as string | undefined, deadline: d.deadline ? new Date(String(d.deadline)) : undefined, status: d.status as string | undefined, seqNo: d.seqNo as number | undefined } });
        else await db.session.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'offering': {
        if (action === 'create') await db.offering.create({ data: { courseId: String(d.courseId), sessionId: String(d.sessionId), programmeId: String(d.programmeId), coordinatorId: (d.coordinatorId as string) || null, status: String(d.status ?? 'ACTIVE') } });
        else if (action === 'update') await db.offering.update({ where: { id: String(d.id) }, data: { coordinatorId: (d.coordinatorId as string) || null, status: d.status as string | undefined } });
        else await db.offering.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'section': {
        if (action === 'create') await db.section.create({ data: { offeringId: String(d.offeringId), code: String(d.code), lecturerId: (d.lecturerId as string) || null } });
        else if (action === 'update') await db.section.update({ where: { id: String(d.id) }, data: { code: d.code as string | undefined, lecturerId: (d.lecturerId as string) || null } });
        else await db.section.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'user': {
        if (action === 'create') {
          const email = String(d.email).toLowerCase();
          await db.profile.create({
            data: {
              email,
              fullName: String(d.fullName),
              staffId: (d.staffId as string) || null,
              passwordHash: hashPassword(String(d.password ?? 'Polisas#2026')),
              active: true,
              userRoles: { create: ((d.roles as string[]) ?? ['lecturer']).map((role) => ({ role, programmeId: (d.programmeId as string) || null })) },
            },
          });
        } else if (action === 'update') {
          const roles = d.roles as string[] | undefined;
          if (roles) {
            await db.userRole.deleteMany({ where: { userId: String(d.id) } });
            for (const role of roles) {
              await db.userRole.create({ data: { userId: String(d.id), role, programmeId: (d.programmeId as string) || null } });
            }
          }
          if (d.password) await db.profile.update({ where: { id: String(d.id) }, data: { passwordHash: hashPassword(String(d.password)), active: d.active as boolean | undefined } });
          else await db.profile.update({ where: { id: String(d.id) }, data: { fullName: d.fullName as string | undefined, staffId: (d.staffId as string) || null, active: d.active as boolean | undefined } });
        } else await db.profile.update({ where: { id: String(d.id) }, data: { active: false } }); // soft deactivate
        break;
      }
      case 'lookup': {
        if (action === 'create') await db.lookup.create({ data: { type: String(d.type), code: String(d.code), labelBm: String(d.labelBm), labelEn: String(d.labelEn), sortOrder: Number(d.sortOrder ?? 99), active: true } });
        else if (action === 'update') await db.lookup.update({ where: { id: String(d.id) }, data: { labelBm: d.labelBm as string | undefined, labelEn: d.labelEn as string | undefined, active: d.active as boolean | undefined, sortOrder: d.sortOrder as number | undefined } });
        else await db.lookup.delete({ where: { id: String(d.id) } });
        break;
      }
      case 'template': {
        // FR-RPT-02: publish a new form template version without code change
        if (action === 'create') {
          const created = await db.formTemplate.create({
            data: {
              versionLabel: String(d.versionLabel),
              effectiveDate: new Date(String(d.effectiveDate ?? new Date().toISOString())),
              updatedDate: new Date(),
              active: d.active !== false,
              layout: d.layout ? JSON.stringify(d.layout) : JSON.stringify({ sections: {} }),
              fieldRules: d.fieldRules ? JSON.stringify(d.fieldRules) : '{}',
            },
          });
          await audit(g.user.id, 'TEMPLATE_PUBLISH', 'form_templates', created.id, null, { versionLabel: created.versionLabel });
        } else if (action === 'update') {
          await db.formTemplate.update({ where: { id: String(d.id) }, data: { active: d.active as boolean | undefined, layout: d.layout ? JSON.stringify(d.layout) : undefined, updatedDate: new Date() } });
        }
        break;
      }
      case 'setting': {
        await db.setting.upsert({ where: { key: String(d.key) }, update: { value: String(d.value) }, create: { key: String(d.key), value: String(d.value) } });
        await audit(g.user.id, 'SETTING_UPDATE', 'settings', String(d.key), null, { value: String(d.value) });
        break;
      }
      case 'courseProgramme': {
        if (action === 'create') await db.courseProgramme.create({ data: { courseId: String(d.courseId), programmeId: String(d.programmeId) } });
        else await db.courseProgramme.delete({ where: { courseId_programmeId: { courseId: String(d.courseId), programmeId: String(d.programmeId) } } });
        break;
      }
      default:
        return NextResponse.json({ error: `Entiti tidak dikenali: ${entity}` }, { status: 400 });
    }
    await audit(g.user.id, `ADMIN_${action.toUpperCase()}`, entity, (d?.id as string) ?? null, null, d);
    return NextResponse.json({ ok: true });
  } catch (err) {
    const msg = err instanceof Prisma.PrismaClientKnownRequestError ? `Kesalahan pangkalan data: ${err.code}` : err instanceof Error ? err.message : 'Kesalahan';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
