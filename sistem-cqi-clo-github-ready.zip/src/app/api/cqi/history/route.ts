import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';

/** GET /api/cqi/history?offeringId= - report versions (read-only, no draft creation). */
export async function GET(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const offeringId = req.nextUrl.searchParams.get('offeringId');
  if (!offeringId) return NextResponse.json({ error: 'offeringId diperlukan' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId);
  if ('error' in access) return access.error;
  const reports = await db.cqiReport.findMany({
    where: { offeringId },
    orderBy: { version: 'asc' },
    select: {
      id: true,
      version: true,
      status: true,
      templateVersion: true,
      overallType: true,
      submittedById: true,
      submittedAt: true,
      amendedFromId: true,
      submittedBy: { select: { fullName: true } },
      verifications: { select: { role: true, decision: true, comment: true, signedAt: true, user: { select: { fullName: true } } } },
      snapshots: { select: { id: true, computedAt: true, reportId: true } },
    },
  });
  return NextResponse.json({ reports });
}
