import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { assembleReport } from '@/lib/service';
import { audit, notify } from '@/lib/audit';

/**
 * POST verify / return with Ulasan (FR-WF-03/04):
 *  - decision VERIFIED: record verification; advance the configurable chain;
 *    when the chain completes -> status VERIFIED (read-only, FR-WF-05)
 *  - decision RETURNED: mandatory Ulasan; status RETURNED; notify coordinator
 */
export async function POST(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const reportId = body?.reportId as string;
  const decision = body?.decision as 'VERIFIED' | 'RETURNED';
  const comment = (body?.comment ?? '').toString().trim();
  if (!reportId || !['VERIFIED', 'RETURNED'].includes(decision)) {
    return NextResponse.json({ error: 'reportId dan decision (VERIFIED/RETURNED) diperlukan' }, { status: 400 });
  }
  if (decision === 'RETURNED' && !comment) {
    return NextResponse.json({ error: 'Ulasan wajib apabila memulangkan laporan / Comments are mandatory when returning' }, { status: 422 });
  }
  const assembled = await assembleReport(reportId);
  if (!assembled) return NextResponse.json({ error: 'Laporan tidak dijumpai' }, { status: 404 });

  if (assembled.report.status !== 'UNDER_VERIFICATION') {
    return NextResponse.json({ error: 'Laporan tidak sedang dalam pengesahan / Report is not under verification' }, { status: 409 });
  }
  const requiredRole = assembled.requiredRole;
  if (!requiredRole || !g.user.roles.includes(requiredRole.toLowerCase())) {
    return NextResponse.json({ error: `Peranan ${requiredRole ?? '-'} diperlukan pada langkah ini / Role ${requiredRole ?? '-'} required at this step` }, { status: 403 });
  }

  await db.verification.create({
    data: { reportId, role: requiredRole, userId: g.user.id, decision, comment: comment || null },
  });

  if (decision === 'RETURNED') {
    await db.cqiReport.update({ where: { id: reportId }, data: { status: 'RETURNED' } });
    const recipients = assembled.report.submittedById ? [assembled.report.submittedById] : [];
    await notify(
      recipients,
      'RETURNED',
      `Laporan CQI ${assembled.header.courseCode} dipulangkan oleh ${requiredRole}. Ulasan: ${comment}`,
      `CQI report ${assembled.header.courseCode} returned by ${requiredRole}. Comments: ${comment}`,
      reportId,
      `/offerings/${assembled.report.offeringId}`,
    );
    await audit(g.user.id, 'REPORT_RETURN', 'cqi_reports', reportId, { status: 'UNDER_VERIFICATION' }, { status: 'RETURNED', comment });
    return NextResponse.json({ ok: true, status: 'RETURNED' });
  }

  // VERIFIED: advance chain (FR-WF-03)
  const chain = assembled.chain;
  const idx = chain.indexOf(requiredRole);
  const nextRole = chain[idx + 1] ?? null;
  if (nextRole) {
    const verifiers = await db.userRole.findMany({
      where: { role: nextRole.toLowerCase(), OR: [{ programmeId: assembled.report.offering.programmeId }, { programmeId: null }] },
      select: { userId: true },
    });
    await notify(
      verifiers.map((v) => v.userId),
      'SUBMITTED',
      `Laporan CQI ${assembled.header.courseCode} telah disahkan oleh ${requiredRole}; menunggu pengesahan ${nextRole}.`,
      `CQI report ${assembled.header.courseCode} verified by ${requiredRole}; awaiting ${nextRole}.`,
      reportId,
      '/verification',
    );
  } else {
    await db.cqiReport.update({ where: { id: reportId }, data: { status: 'VERIFIED' } });
    const recipients = assembled.report.submittedById ? [assembled.report.submittedById] : [];
    await notify(
      recipients,
      'VERIFIED',
      `Laporan CQI ${assembled.header.courseCode} (${assembled.header.sessionLabel}) telah DISAHKAN.`,
      `CQI report ${assembled.header.courseCode} (${assembled.header.sessionLabel}) has been VERIFIED.`,
      reportId,
      `/offerings/${assembled.report.offeringId}`,
    );
  }
  await audit(g.user.id, 'REPORT_VERIFY', 'cqi_reports', reportId, null, { role: requiredRole, comment });
  return NextResponse.json({ ok: true, status: nextRole ? 'UNDER_VERIFICATION' : 'VERIFIED' });
}
