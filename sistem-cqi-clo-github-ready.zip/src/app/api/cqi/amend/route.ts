import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { assembleReport, seedCqiRows, computeComparison, loadWindow } from '@/lib/service';
import { audit, notify } from '@/lib/audit';

/**
 * POST amend (FR-WF-05): verified reports are read-only; corrections create a
 * new version cloned from the verified report. Only the coordinator may amend.
 */
export async function POST(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const reportId = body?.reportId as string;
  if (!reportId) return NextResponse.json({ error: 'reportId diperlukan' }, { status: 400 });
  const assembled = await assembleReport(reportId);
  if (!assembled) return NextResponse.json({ error: 'Laporan tidak dijumpai' }, { status: 404 });
  const access = await requireOfferingAccess(g.user, assembled.report.offeringId, 'edit_report');
  if ('error' in access) return access.error;
  if (!['VERIFIED', 'CLOSED'].includes(assembled.report.status)) {
    return NextResponse.json({ error: 'Hanya laporan disahkan boleh dipinda / Only verified reports can be amended' }, { status: 409 });
  }
  const existingVersions = await db.cqiReport.findMany({ where: { offeringId: assembled.report.offeringId }, select: { version: true } });
  const nextVersion = Math.max(...existingVersions.map((v) => v.version)) + 1;

  const clone = await db.cqiReport.create({
    data: {
      offeringId: assembled.report.offeringId,
      templateVersion: assembled.report.templateVersion,
      status: 'DRAFT',
      version: nextVersion,
      amendedFromId: reportId,
      sectionAIssues: assembled.report.sectionAIssues,
      comparisonNote: assembled.report.comparisonNote,
    },
  });
  // copy rows and feedback
  for (const row of assembled.report.rows) {
    await db.cqiRow.create({
      data: {
        reportId: clone.id,
        cloId: row.cloId,
        cqiType: row.cqiType,
        suggestedType: row.suggestedType,
        overrideReason: row.overrideReason,
        causeTags: row.causeTags,
        causeText: row.causeText,
        proposal: row.proposal,
        outcome: row.outcome,
        ownerId: row.ownerId,
        targetDate: row.targetDate,
        sortOrder: row.sortOrder,
      },
    });
  }
  // fresh suggestion seed if no rows
  if (assembled.report.rows.length === 0) {
    const { current, prevs, settings } = await loadWindow(assembled.report.offeringId);
    const { comparison, suggestions } = computeComparison(current, prevs, settings);
    await seedCqiRows(clone.id, suggestions, comparison, settings);
  }
  for (const f of assembled.report.feedback) {
    await db.curriculumFeedback.create({ data: { reportId: clone.id, courseId: f.courseId, sessionId: f.sessionId, topic: f.topic, text: f.text } });
  }
  await audit(g.user.id, 'REPORT_AMEND', 'cqi_reports', reportId, { version: assembled.report.version }, { newReportId: clone.id, version: nextVersion });
  return NextResponse.json({ ok: true, newReportId: clone.id, version: nextVersion });
}
