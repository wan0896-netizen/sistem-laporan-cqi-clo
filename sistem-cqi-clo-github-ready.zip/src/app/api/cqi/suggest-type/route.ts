import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { loadWindow, computeComparison } from '@/lib/service';

/** GET /api/cqi/suggest-type?offeringId= - CQI decision rule (FR-CQI-02, 8.3). */
export async function GET(req: NextRequest) {
  const g = await guard('view_attainment');
  if ('error' in g) return g.error;
  const offeringId = req.nextUrl.searchParams.get('offeringId');
  if (!offeringId) return NextResponse.json({ error: 'offeringId diperlukan' }, { status: 400 });
  const { current, prevs, settings } = await loadWindow(offeringId);
  const { comparison, suggestions } = computeComparison(current, prevs, settings);
  const affected = suggestions.filter((s) => s.affected);
  const overall = affected.some((s) => s.suggestedType === 'CORRECTIVE')
    ? 'CORRECTIVE'
    : affected.some((s) => s.suggestedType === 'PREVENTIVE')
      ? 'PREVENTIVE'
      : suggestions.some((s) => s.suggestedType === 'ENHANCEMENT')
        ? 'ENHANCEMENT'
        : null;
  return NextResponse.json({ suggestions, overall, likeForLike: comparison.likeForLike });
}
