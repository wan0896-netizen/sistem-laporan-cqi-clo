import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { assembleReport, validateForSubmission, computeComparison, loadWindow } from '@/lib/service';
import { overallCqiType } from '@/lib/calculation';
import { audit, notify } from '@/lib/audit';

/**
 * POST submit (FR-WF-01/02, FR-CLO-08):
 *  - coordinator only (permission matrix 6.1)
 *  - validates mandatory fields (FR-CQI-04/05, FR-CLO-09)
 *  - locks the attainment snapshot into the report (immutable)
 *  - captures Disediakan oleh (name, role, date)
 *  - notifies the first verifier in the programme's configurable chain (FR-WF-03)
 */
export async function POST(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const reportId = body?.reportId as string;
  if (!reportId) return NextResponse.json({ error: 'reportId diperlukan' }, { status: 400 });
  const assembled = await assembleReport(reportId);
  if (!assembled) return NextResponse.json({ error: 'Laporan tidak dijumpai' }, { status: 404 });

  // submit is coordinator-only
  const isCoordinator = assembled.report.offering.coordinatorId === g.user.id || g.user.roles.includes('coordinator');
  if (!isCoordinator) return NextResponse.json({ error: 'Hanya Penyelaras Kursus boleh menghantar laporan / Only the Course Coordinator can submit' }, { status: 403 });
  const offeringAccess = await requireOfferingAccess(g.user, assembled.report.offeringId);
  if ('error' in offeringAccess) return offeringAccess.error;

  if (assembled.report.status !== 'DRAFT' && assembled.report.status !== 'RETURNED') {
    return NextResponse.json({ error: 'Laporan tidak dalam status Draf/Dipulangkan / Report is not editable' }, { status: 409 });
  }

  const errors = validateForSubmission(assembled);
  if (errors.length > 0) return NextResponse.json({ error: errors[0], errors }, { status: 422 });

  // recompute comparison at submission and store the immutable snapshot
  const { current, prevs, settings } = await loadWindow(assembled.report.offeringId);
  const { comparison, suggestions } = computeComparison(current, prevs, settings);
  const overall = overallCqiType(assembled.report.rows.map((r) => r.cqiType as never));

  const snapshot = await db.attainmentSnapshot.create({
    data: {
      offeringId: assembled.report.offeringId,
      reportId,
      computedBy: g.user.id,
      settingsUsed: JSON.stringify(settings),
      results: JSON.stringify({ comparison, suggestions, overallType: overall }),
    },
  });

  await db.cqiReport.update({
    where: { id: reportId },
    data: {
      status: 'UNDER_VERIFICATION',
      submittedById: g.user.id,
      submittedAt: new Date(),
      overallType: overall,
      templateVersion: assembled.report.templateVersion,
    },
  });

  // FR-CQI-07: proposals seed Section B of the next session - create a
  // planned action per CQI row (deduped across resubmissions)
  const existingActions = await db.cqiAction.findMany({ where: { originReportId: reportId, unplanned: false }, select: { cloId: true, description: true } });
  for (const row of assembled.report.rows) {
    if (!row.proposal?.trim()) continue;
    const dup = existingActions.some((a) => a.cloId === row.cloId && a.description === row.proposal);
    if (dup) continue;
    await db.cqiAction.create({
      data: {
        originReportId: reportId,
        cloId: row.cloId,
        description: row.proposal,
        ownerId: row.ownerId ?? g.user.id,
        targetDate: row.targetDate,
        status: 'PLANNED',
      },
    });
  }

  // notify first verifier in chain (FR-WF-03, chain configurable per programme)
  const chain = assembled.chain;
  const firstRole = chain[0] ?? 'KPRO';
  const verifiers = await db.userRole.findMany({
    where: { role: firstRole.toLowerCase(), OR: [{ programmeId: assembled.report.offering.programmeId }, { programmeId: null }] },
    select: { userId: true },
  });
  await notify(
    verifiers.map((v) => v.userId),
    'SUBMITTED',
    `Laporan CQI ${assembled.header.courseCode} (${assembled.header.sessionLabel}) menunggu pengesahan ${firstRole}.`,
    `CQI report ${assembled.header.courseCode} (${assembled.header.sessionLabel}) awaits ${firstRole} verification.`,
    reportId,
    '/verification',
  );
  await audit(g.user.id, 'REPORT_SUBMIT', 'cqi_reports', reportId, { status: assembled.report.status }, { status: 'UNDER_VERIFICATION', snapshotId: snapshot.id });
  return NextResponse.json({ ok: true, snapshotId: snapshot.id });
}
