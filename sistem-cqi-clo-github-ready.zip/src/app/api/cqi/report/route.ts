import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { ensureDraftReport, assembleReport } from '@/lib/service';

/** GET full report payload for the editor: /api/cqi/report?offeringId= or ?reportId= */
export async function GET(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const offeringId = req.nextUrl.searchParams.get('offeringId');
  const reportId = req.nextUrl.searchParams.get('reportId');
  try {
    let rid = reportId;
    if (!rid && offeringId) {
      const access = await requireOfferingAccess(g.user, offeringId);
      if ('error' in access) return access.error;
      rid = await ensureDraftReport(offeringId);
    }
    if (!rid) return NextResponse.json({ error: 'offeringId atau reportId diperlukan' }, { status: 400 });
    const assembled = await assembleReport(rid);
    if (!assembled) return NextResponse.json({ error: 'Laporan tidak dijumpai' }, { status: 404 });
    const access = await requireOfferingAccess(g.user, assembled.report.offeringId);
    if ('error' in access) return access.error;
    return NextResponse.json(assembled);
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Kesalahan' }, { status: 500 });
  }
}
