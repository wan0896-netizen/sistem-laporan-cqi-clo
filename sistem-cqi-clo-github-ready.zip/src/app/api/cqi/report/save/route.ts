import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { assembleReport, assertEditable } from '@/lib/service';
import { audit } from '@/lib/audit';

/**
 * POST saves report sections while DRAFT/RETURNED (PRD 13.2: server
 * orchestrates; submission locks the snapshot, FR-CLO-08):
 * body: {
 *   reportId,
 *   sectionAIssues?: rows[],        // Section A lecturer inputs (FR-CLO-07)
 *   comparisonNote?: string,        // FR-CLO-09 note when not like-for-like
 *   actionUpdates?: [{id, status, implementedDate, impact, impactText}], // Section B
 *   newActions?: [{cloId, description, ownerId, targetDate, status, implementedDate, impact, impactText}], // FR-PCQI-04
 *   rows?: [{id?, cloId, cqiType, overrideReason, causeTags, causeText, proposal, outcome, ownerId, targetDate}], // Section C (FR-CQI-*)
 *   feedback?: [{id?, topic, text}], // Section D (FR-CF-01)
 * }
 */
export async function POST(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const reportId = body?.reportId as string;
  if (!reportId) return NextResponse.json({ error: 'reportId diperlukan' }, { status: 400 });
  const assembled = await assembleReport(reportId);
  if (!assembled) return NextResponse.json({ error: 'Laporan tidak dijumpai' }, { status: 404 });
  const access = await requireOfferingAccess(g.user, assembled.report.offeringId, 'edit_report');
  if ('error' in access) return access.error;

  try {
    const sessionLocked = (await db.session.findUnique({ where: { id: assembled.report.offering.sessionId } }))?.status === 'LOCKED';
    assertEditable(assembled.report.status, sessionLocked);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'LOCKED';
    if (msg === 'SESSION_LOCKED') return NextResponse.json({ error: 'Sesi telah dikunci (arkib) / Session is locked (archived)' }, { status: 409 });
    return NextResponse.json({ error: 'Laporan telah dihantar/disahkan dan tidak boleh disunting / Report is locked after submission' }, { status: 409 });
  }

  // ---- Section A (FR-CLO-07) ----
  if (Array.isArray(body.sectionAIssues)) {
    await db.cqiReport.update({ where: { id: reportId }, data: { sectionAIssues: JSON.stringify(body.sectionAIssues) } });
  }
  if (typeof body.comparisonNote === 'string') {
    await db.cqiReport.update({ where: { id: reportId }, data: { comparisonNote: body.comparisonNote } });
  }

  // ---- Section B (FR-PCQI-02/04) ----
  for (const u of body.actionUpdates ?? []) {
    await db.cqiAction.update({
      where: { id: u.id },
      data: {
        status: u.status ?? undefined,
        implementedDate: u.implementedDate ? new Date(u.implementedDate) : null,
        impact: u.impact ?? null,
        impactText: u.impactText ?? null,
      },
    });
  }
  for (const a of body.newActions ?? []) {
    await db.cqiAction.create({
      data: {
        originReportId: reportId,
        cloId: a.cloId || null,
        description: a.description,
        ownerId: a.ownerId || g.user.id,
        targetDate: a.targetDate ? new Date(a.targetDate) : null,
        status: a.status ?? 'IMPLEMENTED',
        implementedDate: a.implementedDate ? new Date(a.implementedDate) : null,
        impact: a.impact ?? null,
        impactText: a.impactText ?? null,
        unplanned: true,
        verifiedInReportId: reportId,
      },
    });
  }

  // ---- Section C (FR-CQI-01..05, FR-CQI-07) ----
  if (Array.isArray(body.rows)) {
    const existing = await db.cqiRow.findMany({ where: { reportId } });
    const keepIds = new Set<string>();
    let sort = 0;
    for (const r of body.rows) {
      const data = {
        reportId,
        cloId: r.cloId || null,
        cqiType: r.cqiType,
        suggestedType: r.suggestedType ?? r.suggestedType ?? null,
        overrideReason: r.overrideReason ?? null,
        causeTags: JSON.stringify(r.causeTags ?? []),
        causeText: r.causeText ?? null,
        proposal: r.proposal ?? '',
        outcome: r.outcome ?? null,
        ownerId: r.ownerId || null,
        targetDate: r.targetDate ? new Date(r.targetDate) : null,
        sortOrder: sort++,
      };
      if (r.id) {
        keepIds.add(r.id);
        await db.cqiRow.update({ where: { id: r.id }, data });
      } else {
        const created = await db.cqiRow.create({ data });
        keepIds.add(created.id);
      }
    }
    for (const old of existing) {
      if (!keepIds.has(old.id)) await db.cqiRow.delete({ where: { id: old.id } });
    }
    // recompute overall type (PRD 8.3 highest priority present)
    const types = body.rows.map((r: { cqiType: string }) => r.cqiType);
    const overallType = types.includes('CORRECTIVE') ? 'CORRECTIVE' : types.includes('PREVENTIVE') ? 'PREVENTIVE' : types.length > 0 ? 'ENHANCEMENT' : null;
    await db.cqiReport.update({ where: { id: reportId }, data: { overallType } });
  }

  // ---- Section D (FR-CF-01) ----
  if (Array.isArray(body.feedback)) {
    const existing = await db.curriculumFeedback.findMany({ where: { reportId } });
    const keepIds = new Set<string>();
    for (const f of body.feedback) {
      if (!f.text?.trim()) continue;
      const data = { reportId, courseId: assembled.report.offering.courseId, sessionId: assembled.report.offering.sessionId, topic: f.topic, text: f.text };
      if (f.id) {
        keepIds.add(f.id);
        await db.curriculumFeedback.update({ where: { id: f.id }, data });
      } else {
        const created = await db.curriculumFeedback.create({ data });
        keepIds.add(created.id);
      }
    }
    for (const old of existing) {
      if (!keepIds.has(old.id)) await db.curriculumFeedback.delete({ where: { id: old.id } });
    }
  }

  await audit(g.user.id, 'REPORT_SAVE', 'cqi_reports', reportId, null, { sections: Object.keys(body).filter((k) => k !== 'reportId') });
  const refreshed = await assembleReport(reportId);
  return NextResponse.json({ ok: true, assembled: refreshed });
}
