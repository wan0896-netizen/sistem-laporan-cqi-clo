import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { audit, notify } from '@/lib/audit';

/**
 * GET /api/cron/reminders (FR-WF-06): deadline reminders T-7 / T-3 / T-1 and
 * overdue escalation to KPro. Authorised by CRON_SECRET header (Vercel Cron)
 * or an admin session ("run now" from Admin console for demo).
 */
export async function GET(req: NextRequest) {
  const secret = req.headers.get('x-cron-secret');
  const envSecret = process.env.CRON_SECRET;
  let isAdmin = false;
  if (!(envSecret && secret && secret === envSecret)) {
    const g = await guard();
    if ('error' in g) return g.error;
    isAdmin = g.user.roles.includes('admin');
    if (!isAdmin) return NextResponse.json({ error: 'Akses ditolak' }, { status: 403 });
  }

  const now = new Date();
  const daysUntil = (d: Date) => Math.ceil((d.getTime() - now.getTime()) / 86400_000);
  const created: { type: string; offering: string; recipients: number }[] = [];

  const offerings = await db.offering.findMany({
    where: { session: { status: 'OPEN', deadline: { not: null } } },
    include: { session: true, course: true, programme: true, coordinator: true, reports: { orderBy: { version: 'desc' } } },
  });

  const isSameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

  for (const off of offerings) {
    const deadline = off.session.deadline;
    if (!deadline) continue;
    const latest = off.reports[0];
    const done = latest && ['VERIFIED', 'CLOSED'].includes(latest.status);
    if (done) continue;
    const days = daysUntil(deadline);
    const coordinatorId = off.coordinatorId;
    if (!coordinatorId) continue;

    // dedupe: same type + ref + day
    const alreadySent = async (type: string) => {
      const existing = await db.notification.findFirst({ where: { type, refId: off.id, createdAt: { gte: new Date(now.getFullYear(), now.getMonth(), now.getDate()) } } });
      return !!existing;
    };

    if ([7, 3, 1].includes(days)) {
      if (!(await alreadySent('REMINDER'))) {
        await notify(
          [coordinatorId],
          'REMINDER',
          `Peringatan: Laporan CQI ${off.course.code} (${off.session.label}) perlu dihantar dalam ${days} hari.`,
          `Reminder: CQI report for ${off.course.code} (${off.session.label}) is due in ${days} day(s).`,
          off.id,
          `/offerings/${off.id}`,
        );
        created.push({ type: `REMINDER_T-${days}`, offering: off.course.code, recipients: 1 });
      }
    } else if (days < 0) {
      if (!(await alreadySent('OVERDUE'))) {
        await notify(
          [coordinatorId],
          'OVERDUE',
          `LEWAT: Laporan CQI ${off.course.code} (${off.session.label}) telah melepasi tarikh akhir.`,
          `OVERDUE: CQI report for ${off.course.code} (${off.session.label}) is past its deadline.`,
          off.id,
          `/offerings/${off.id}`,
        );
        created.push({ type: 'OVERDUE', offering: off.course.code, recipients: 1 });
        // escalation to KPro (FR-WF-06)
        const kpros = await db.userRole.findMany({ where: { role: 'kpro', OR: [{ programmeId: off.programmeId }, { programmeId: null }] }, select: { userId: true } });
        if (!isSameDay(now, deadline)) {
          await notify(
            kpros.map((k) => k.userId),
            'ESCALATION',
            `Eskalasi: ${off.course.code} (${off.session.label}) masih belum disahkan selepas tarikh akhir.`,
            `Escalation: ${off.course.code} (${off.session.label}) remains unverified past the deadline.`,
            off.id,
            '/dashboard',
          );
        }
        created.push({ type: 'ESCALATION_KPRO', offering: off.course.code, recipients: kpros.length });
      }
    }
  }

  await audit(null, 'CRON_REMINDERS', 'notifications', null, null, { created: created.length });
  return NextResponse.json({ ok: true, evaluated: offerings.length, created });
}
