import { NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';
import type { SessionUser } from '@/lib/auth';

/**
 * GET /api/offerings - role-scoped offering list with report status,
 * deadlines and task flags (feeds dashboards + offering list screens).
 */
export async function GET() {
  const g = await guard();
  if ('error' in g) return g.error;
  const user: SessionUser = g.user;
  const programmeIds = user.programmes.filter(Boolean) as string[];
  const deptWide = user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r));
  const programmeScoped = user.roles.some((r) => ['kpro', 'kk'].includes(r));

  const offerings = await db.offering.findMany({
    where: deptWide
      ? {}
      : programmeScoped
        ? { programmeId: { in: programmeIds } }
        : { OR: [{ coordinatorId: user.id }, { sections: { some: { lecturerId: user.id } } }] },
    include: {
      course: true,
      session: true,
      programme: true,
      coordinator: true,
      sections: true,
      reports: { orderBy: { version: 'desc' } },
      marks: { select: { matric: true } },
      assessments: { include: { items: true } },
    },
    orderBy: [{ sessionId: 'asc' }],
  });

  const rows = offerings
    .map((off) => {
      const latestReport = off.reports[0];
      const marksStudents = new Set(off.marks.map((m) => m.matric)).size;
      const totalItems = off.assessments.reduce((acc, a) => acc + a.items.length, 0);
      const marksCells = off.marks.length;
      const deadline = off.session.deadline;
      const daysLeft = deadline ? Math.ceil((deadline.getTime() - Date.now()) / 86400_000) : null;
      return {
        id: off.id,
        courseCode: off.course.code,
        courseName: off.course.name,
        programme: off.programme.code,
        sessionLabel: off.session.label,
        sessionSeq: off.session.seqNo,
        deadline: deadline,
        daysLeft,
        coordinator: off.coordinator?.fullName ?? '-',
        sections: off.sections.map((s) => ({ code: s.code, studentCount: s.studentCount })),
        rosterStudents: Math.max(marksStudents, off.sections.reduce((a, s) => a + s.studentCount, 0)),
        marksProgress: totalItems > 0 && marksStudents > 0 ? Math.min(100, Math.round((marksCells / (totalItems * marksStudents)) * 100)) : 0,
        reportStatus: latestReport?.status ?? 'NOT_STARTED',
        reportId: latestReport?.id ?? null,
        reportVersion: latestReport?.version ?? null,
        overallType: latestReport?.overallType ?? null,
      };
    })
    .sort((a, b) => b.sessionSeq - a.sessionSeq);

  return NextResponse.json({ offerings: rows });
}
