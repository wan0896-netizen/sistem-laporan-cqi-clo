import { NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';

/** GET notifications for the signed-in user (FR-NT-01). */
export async function GET() {
  const g = await guard();
  if ('error' in g) return g.error;
  const [items, unread] = await Promise.all([
    db.notification.findMany({ where: { userId: g.user.id }, orderBy: { createdAt: 'desc' }, take: 30 }),
    db.notification.count({ where: { userId: g.user.id, read: false } }),
  ]);
  return NextResponse.json({ items, unread });
}

/** POST mark read: { ids?: string[] } or { all: true } */
export async function POST(req: Request) {
  const g = await guard();
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => ({}));
  if (body?.all === true) {
    await db.notification.updateMany({ where: { userId: g.user.id, read: false }, data: { read: true } });
  } else if (Array.isArray(body?.ids)) {
    await db.notification.updateMany({ where: { userId: g.user.id, id: { in: body.ids } }, data: { read: true } });
  }
  return NextResponse.json({ ok: true });
}
