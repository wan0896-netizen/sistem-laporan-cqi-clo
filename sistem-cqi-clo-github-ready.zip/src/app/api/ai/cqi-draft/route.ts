import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { loadWindow, computeComparison } from '@/lib/service';
import { buildAnonymousPayload } from '@/lib/ai/sanitise';
import { runAi, type PuncaDraft, type CadanganDraft } from '@/lib/ai/provider';

/**
 * POST /api/ai/cqi-draft (AI-01/02, PRD Section 11):
 *  - feature=punca: Punca hypotheses organised by the six form factors
 *  - feature=cadangan: Cadangan CQI matched to the CQI type
 * Guardrails: anonymised aggregated payload only, Zod-validated structured
 * output, retry, usage metering (rate limit + budget), graceful fallback.
 * The response is labelled an AI suggestion; the lecturer must edit and accept.
 */
export async function POST(req: NextRequest) {
  const g = await guard('edit_report');
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const offeringId = body?.offeringId as string;
  const feature = body?.feature === 'cadangan' ? 'cadangan_draft' : 'punca_draft';
  const cqiType = ['CORRECTIVE', 'PREVENTIVE', 'ENHANCEMENT'].includes(body?.cqiType) ? body.cqiType : 'CORRECTIVE';
  const factors = Array.isArray(body?.factors) ? body.factors.map(String) : [];
  if (!offeringId) return NextResponse.json({ error: 'offeringId diperlukan' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId, 'edit_report');
  if ('error' in access) return access.error;

  const { current, prevs, settings } = await loadWindow(offeringId);
  const { comparison } = computeComparison(current, prevs, settings);

  // aggregated, anonymised payload - no names, no matric numbers (PRD 11.3)
  const payload = buildAnonymousPayload({
    courseCode: current.course.code,
    cqiType,
    factors,
    cloStats: comparison.comparisons.map((c) => ({
      code: c.code,
      attainment: c.currentAttainment,
      delta: c.delta,
      met: c.met,
      studentCount: c.currentStudentCount,
    })),
    previousActions: [],
    studentCounts: Object.fromEntries(comparison.series.map((s) => [s.label, s.studentCount])),
  });

  try {
    const result = await runAi<PuncaDraft | CadanganDraft>(
      { userId: g.user.id, feature },
      async (provider) => {
        const res = feature === 'punca_draft' ? await provider.draftPunca(payload, cqiType) : await provider.draftCadangan(payload, cqiType);
        // second draft for language assist (AI-04): each item already carries bm+en
        return res;
      },
      feature === 'punca_draft'
        ? await import('@/lib/ai/provider').then((m) => new m.FallbackProvider()).then((p) => p.draftPunca(payload, cqiType))
        : await import('@/lib/ai/provider').then((m) => new m.FallbackProvider()).then((p) => p.draftCadangan(payload, cqiType)),
    );
    return NextResponse.json({ ...result, label: 'AI suggestion', requiresHumanEdit: true });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'AI_ERROR';
    if (msg === 'AI_DISABLED') return NextResponse.json({ error: 'AI_DISABLED', message: 'Fungsi AI dinyahaktifkan oleh institusi / AI disabled institution-wide' }, { status: 423 });
    if (msg.startsWith('AI_LIMITED')) return NextResponse.json({ error: msg, message: 'Had penggunaan AI dicapai / AI usage limit reached' }, { status: 429 });
    return NextResponse.json({ error: 'AI_ERROR' }, { status: 500 });
  }
}

// keep unused import referenced for type checking
void db;
