import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { runAi, QualityCheckSchema } from '@/lib/ai/provider';
import { z } from 'zod';

/**
 * POST /api/ai/quality-check (AI-03): advisory quality check on Section C
 * proposals - flags vague proposals (no owner, date or measurable outcome).
 * Rule-based first; AI provides extra advisory when available. Never blocks.
 */
const InputSchema = z.object({
  rows: z.array(
    z.object({
      cqiType: z.string(),
      proposal: z.string().default(''),
      outcome: z.string().nullable().optional(),
      ownerId: z.string().nullable().optional(),
      targetDate: z.string().nullable().optional(),
    }),
  ),
});

export async function POST(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const parsed = InputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Permintaan tidak sah' }, { status: 400 });

  // deterministic advisory rules (AI-03 guardrail: advisory only)
  const issues: { row: number; code: string; bm: string; en: string }[] = [];
  parsed.data.rows.forEach((row, i) => {
    if (!row.outcome?.trim()) issues.push({ row: i, code: 'NO_OUTCOME', bm: 'Hasil terukur belum dinyatakan', en: 'Measurable outcome not stated' });
    if (!row.targetDate) issues.push({ row: i, code: 'NO_TARGET_DATE', bm: 'Tarikh sasaran belum ditetapkan', en: 'Target date not set' });
    if (!row.ownerId) issues.push({ row: i, code: 'MISSING_OWNER', bm: 'Pelaksana (nama) belum ditetapkan', en: 'Owner not assigned' });
    if ((row.proposal ?? '').trim().length < 30) issues.push({ row: i, code: 'VAGUE_PROPOSAL', bm: 'Cadangan terlalu umum - nyatakan tindakan khusus', en: 'Proposal is too vague - state specific actions' });
  });

  return NextResponse.json({ issues: QualityCheckSchema.parse({ issues }).issues, advisoryOnly: true });
}

// AI assist is optional for the checker; provider kept available for future use
void runAi;
