import { NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';

/**
 * GET /api/verification/queue - reports awaiting verification (FR-WF), with
 * the next required role in each programme's configurable chain. Visible to
 * KK/KPro/KJ (their role steps), KJ/Quality/Admin (department-wide).
 */
export async function GET() {
  const g = await guard();
  if ('error' in g) return g.error;
  const user = g.user;
  const programmeIds = user.programmes.filter(Boolean) as string[];
  const verifierRoles = user.roles.filter((r) => ['kk', 'kpro', 'kj'].includes(r));
  const deptWide = user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r));

  const offerings = await db.offering.findMany({
    where: deptWide ? {} : verifierRoles.length > 0 ? { programmeId: { in: programmeIds } } : { coordinatorId: user.id },
    include: {
      course: true,
      session: true,
      programme: true,
      coordinator: true,
      reports: { where: { status: { in: ['UNDER_VERIFICATION', 'RETURNED'] } }, orderBy: { version: 'desc' }, include: { verifications: true, submittedBy: true } },
    },
  });

  const queue = offerings.flatMap((off) =>
    off.reports.map((report) => {
      const chain = JSON.parse(off.programme.verificationChain || '["KK","KPRO","KJ"]') as string[];
      const verifiedRoles = report.verifications.filter((v) => v.decision === 'VERIFIED').map((v) => v.role);
      const requiredRole = chain.find((r) => !verifiedRoles.includes(r)) ?? null;
      const returnedBy = report.verifications.find((v) => v.decision === 'RETURNED');
      return {
        reportId: report.id,
        status: report.status,
        version: report.version,
        submittedAt: report.submittedAt,
        submittedBy: report.submittedBy?.fullName ?? '-',
        courseCode: off.course.code,
        courseName: off.course.name,
        programme: off.programme.code,
        sessionLabel: off.session.label,
        overallType: report.overallType,
        chain,
        verifiedRoles,
        requiredRole,
        myTurn: verifierRoles.includes((requiredRole ?? '').toLowerCase()),
        returnedComment: returnedBy?.comment ?? null,
        returnedRole: returnedBy?.role ?? null,
      };
    }),
  );

  return NextResponse.json({ queue });
}
