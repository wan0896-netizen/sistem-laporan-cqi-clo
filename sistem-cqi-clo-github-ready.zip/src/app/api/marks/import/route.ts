import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { audit } from '@/lib/audit';
import { parseCsv } from '@/lib/csv';

/**
 * FR-MK-02 / FR-MK-03 / FR-MK-05: marks CSV import with row-level validation
 * report, then commit. Two modes:
 *  - mode=MARKS: header row = [No. Matrik, <item labels>...]
 *  - mode=CLO_RESULTS: header row = [No. Matrik, <CLO codes>...] (already
 *    computed per-student CLO percentages)
 * Two-phase: POST with commit=false returns the validation report; commit=true
 * persists only when there are zero errors.
 */

interface RowError {
  row: number;
  matric: string;
  error: string;
}

export async function POST(req: NextRequest) {
  const g = await guard('enter_marks');
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const offeringId = body?.offeringId as string;
  const csv = (body?.csv ?? '').toString();
  const mode = body?.mode === 'CLO_RESULTS' ? 'CLO_RESULTS' : 'MARKS';
  const commit = body?.commit === true;
  if (!offeringId || !csv) return NextResponse.json({ error: 'offeringId dan csv diperlukan' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId, 'enter_marks');
  if ('error' in access) return access.error;

  const offering = await db.offering.findUnique({
    where: { id: offeringId },
    include: { sections: { orderBy: { code: 'asc' } }, assessments: { include: { items: { orderBy: { label: 'asc' } } } }, course: { include: { clos: { orderBy: { code: 'asc' } } } } },
  });
  if (!offering) return NextResponse.json({ error: 'Penawaran tidak dijumpai' }, { status: 404 });

  const rows = parseCsv(csv);
  if (rows.length < 2) return NextResponse.json({ error: 'CSV mestilah mengandungi baris tajuk dan sekurang-kurangnya satu baris data' }, { status: 422 });

  const header = rows[0].map((h) => h.trim());
  const errors: RowError[] = [];
  const valid: { sectionId: string; matric: string; key: string; value: number | null; status: string | null }[] = [];

  if (mode === 'MARKS') {
    const items = offering.assessments.flatMap((a) => a.items);
    const labelToItem = new Map(items.map((i) => [i.label, i]));
    // duplicate label guard (FR-MK-03)
    const seen = new Map<string, number>();
    for (const h of header.slice(1)) seen.set(h, (seen.get(h) ?? 0) + 1);
    for (const [h, count] of seen) if (count > 1 && labelToItem.has(h)) errors.push({ row: 1, matric: '-', error: `Tajuk berulang: ${h}` });
    const unknownCols = header.slice(1).filter((h) => h && !labelToItem.has(h));
    if (unknownCols.length > 0) errors.push({ row: 1, matric: '-', error: `Item tidak dijumpai dalam struktur penilaian: ${unknownCols.join(', ')}` });

    // roster: known matrics per section + option to create new matrics in first section
    const roster = new Map<string, { sectionId: string }>();
    for (const s of offering.sections) {
      const marks = await db.mark.findMany({ where: { sectionId: s.id }, select: { matric: true }, distinct: ['matric'] });
      for (const m of marks) roster.set(m.matric, { sectionId: s.id });
    }

    rows.slice(1).forEach((r, idx) => {
      const rowNum = idx + 2;
      const matric = (r[0] ?? '').trim();
      if (!matric) {
        errors.push({ row: rowNum, matric: '-', error: 'No. Matrik kosong' });
        return;
      }
      let sectionId = roster.get(matric)?.sectionId;
      if (!sectionId) {
        // new student -> assign to first section of the offering
        sectionId = offering.sections[0]?.id;
        if (!sectionId) {
          errors.push({ row: rowNum, matric, error: 'Tiada seksyen untuk pelajar baharu' });
          return;
        }
        roster.set(matric, { sectionId });
      }
      header.slice(1).forEach((label, colIdx) => {
        if (!label) return;
        const item = labelToItem.get(label);
        if (!item) return;
        const raw = (r[colIdx + 1] ?? '').trim();
        if (raw === '') return;
        const upper = raw.toUpperCase();
        if (['TG', 'ABSENT', 'BARRED', 'LARANG', 'BEBAS', 'EXEMPTED'].includes(upper)) {
          const status = ['TG', 'ABSENT'].includes(upper) ? 'ABSENT' : ['BARRED', 'LARANG'].includes(upper) ? 'BARRED' : 'EXEMPTED';
          valid.push({ sectionId, matric, key: item.id, value: null, status });
          return;
        }
        const num = Number(raw);
        if (Number.isNaN(num)) {
          errors.push({ row: rowNum, matric, error: `${label}: bukan nombor (${raw})` });
          return;
        }
        if (num < 0 || num > item.maxMarks) {
          errors.push({ row: rowNum, matric, error: `${label}: di luar julat 0-${item.maxMarks}` });
          return;
        }
        valid.push({ sectionId, matric, key: item.id, value: num, status: null });
      });
    });
  } else {
    // CLO_RESULTS mode (FR-MK-05): already computed per-student CLO results
    const clos = offering.course.clos;
    const cloByCode = new Map(clos.map((c) => [c.code, c]));
    const unknownCols = header.slice(1).filter((h) => h && !cloByCode.has(h));
    if (unknownCols.length > 0) errors.push({ row: 1, matric: '-', error: `Kod CLO tidak dijumpai: ${unknownCols.join(', ')}` });

    const firstSection = offering.sections[0]?.id;
    rows.slice(1).forEach((r, idx) => {
      const rowNum = idx + 2;
      const matric = (r[0] ?? '').trim();
      if (!matric) {
        errors.push({ row: rowNum, matric: '-', error: 'No. Matrik kosong' });
        return;
      }
      header.slice(1).forEach((cloCode, colIdx) => {
        if (!cloCode) return;
        const clo = cloByCode.get(cloCode);
        if (!clo) return;
        const raw = (r[colIdx + 1] ?? '').trim();
        if (raw === '') return;
        const num = Number(raw);
        if (Number.isNaN(num) || num < 0 || num > 100) {
          errors.push({ row: rowNum, matric, error: `${cloCode}: peratus mestilah 0-100 (${raw})` });
          return;
        }
        valid.push({ sectionId: firstSection, matric, key: clo.id, value: num, status: null });
      });
    });
  }

  if (!commit) {
    return NextResponse.json({
      ok: errors.length === 0,
      dryRun: true,
      totalRows: rows.length - 1,
      validRows: valid.length,
      errors: errors.slice(0, 50),
      message: errors.length === 0 ? 'Pengesahan berjaya. Komiti untuk menyimpan. / Validation passed. Commit to save.' : 'Pengesahan gagal. Betulkan baris berikut. / Validation failed.',
    });
  }

  if (errors.length > 0) return NextResponse.json({ error: 'Terdapat ralat pengesahan / Validation errors', errors }, { status: 422 });

  if (mode === 'MARKS') {
    for (const v of valid) {
      await db.mark.upsert({
        where: { sectionId_matric_itemId: { sectionId: v.sectionId, matric: v.matric, itemId: v.key } },
        update: { score: v.value, status: v.status },
        create: { offeringId, sectionId: v.sectionId, matric: v.matric, itemId: v.key, score: v.value, status: v.status },
      });
    }
    for (const s of offering.sections) {
      const distinct = await db.mark.findMany({ where: { sectionId: s.id }, select: { matric: true }, distinct: ['matric'] });
      await db.section.update({ where: { id: s.id }, data: { studentCount: distinct.length } });
    }
  } else {
    for (const v of valid) {
      await db.cloResult.upsert({
        where: { sectionId_matric_cloId: { sectionId: v.sectionId!, matric: v.matric, cloId: v.key } },
        update: { percent: v.value! },
        create: { offeringId, sectionId: v.sectionId!, matric: v.matric, cloId: v.key, percent: v.value! },
      });
    }
  }
  await audit(g.user.id, mode === 'MARKS' ? 'MARKS_IMPORT' : 'CLO_RESULTS_IMPORT', mode === 'MARKS' ? 'marks' : 'cloResults', offeringId, null, { rows: valid.length });
  return NextResponse.json({ ok: true, committed: valid.length });
}
