import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { toCsv } from '@/lib/csv';

/** FR-MK-02: Excel/CSV template download. mode=MARKS (default) or CLO_RESULTS. */
export async function GET(req: NextRequest) {
  const g = await guard('enter_marks');
  if ('error' in g) return g.error;
  const offeringId = req.nextUrl.searchParams.get('offeringId');
  const mode = req.nextUrl.searchParams.get('mode') ?? 'MARKS';
  if (!offeringId) return NextResponse.json({ error: 'offeringId diperlukan' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId);
  if ('error' in access) return access.error;
  const offering = await db.offering.findUnique({
    where: { id: offeringId },
    include: { assessments: { include: { items: { orderBy: { label: 'asc' } } } }, course: { include: { clos: { orderBy: { code: 'asc' } } } } },
  });
  if (!offering) return NextResponse.json({ error: 'Penawaran tidak dijumpai' }, { status: 404 });

  let rows: (string | number | null)[][];
  if (mode === 'CLO_RESULTS') {
    rows = [['No. Matrik', ...offering.course.clos.map((c) => c.code)]];
    rows.push(['Contoh / e.g.', ...offering.course.clos.map(() => '62.5')]);
  } else {
    const items = offering.assessments.flatMap((a) => a.items);
    rows = [['No. Matrik', ...items.map((i) => i.label)]];
    rows.push(['Contoh / e.g.', ...items.map((i) => `0-${Math.round(i.maxMarks)}`)]);
    rows.push(['(TG/BARRED/BEBAS untuk status)', ...items.map(() => '')]);
  }
  const csv = toCsv(rows);
  return new NextResponse(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="templat-markah-${offeringId}-${mode.toLowerCase()}.csv"`,
    },
  });
}
