import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { audit } from '@/lib/audit';

/** GET marks grid data for an offering (FR-MK-01). */
export async function GET(req: NextRequest) {
  const g = await guard('enter_marks');
  if ('error' in g) return g.error;
  const offeringId = req.nextUrl.searchParams.get('offeringId');
  if (!offeringId) return NextResponse.json({ error: 'offeringId diperlukan' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId);
  if ('error' in access) return access.error;
  const offering = await db.offering.findUnique({
    where: { id: offeringId },
    include: {
      session: true,
      programme: true,
      coordinator: { select: { id: true, fullName: true } },
      sections: { orderBy: { code: 'asc' } },
      assessments: { include: { items: { orderBy: { label: 'asc' } } } },
      marks: true,
      course: {
        include: {
          clos: {
            orderBy: { code: 'asc' },
            include: { ploMap: { include: { plo: { select: { code: true } } } } },
          },
        },
      },
    },
  });
  return NextResponse.json({ offering });
}

/** POST saves grid edits: { offeringId, changes: [{sectionId, matric, itemId, score, status}] } */
export async function POST(req: NextRequest) {
  const g = await guard('enter_marks');
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const offeringId = body?.offeringId as string;
  const changes = (body?.changes ?? []) as { sectionId: string; matric: string; itemId: string; score: number | null; status: string | null }[];
  if (!offeringId || !Array.isArray(changes)) return NextResponse.json({ error: 'Permintaan tidak sah' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId, 'enter_marks');
  if ('error' in access) return access.error;

  const offering = await db.offering.findUnique({ where: { id: offeringId }, include: { sections: true, assessments: { include: { items: true } } } });
  if (!offering) return NextResponse.json({ error: 'Penawaran tidak dijumpai' }, { status: 404 });

  const errors: string[] = [];
  const itemById = new Map(offering.assessments.flatMap((a) => a.items).map((i) => [i.id, i]));
  const sectionIds = new Set(offering.sections.map((s) => s.id));
  for (const [idx, c] of changes.entries()) {
    const item = itemById.get(c.itemId);
    if (!item) errors.push(`Baris ${idx + 1}: item tidak dijumpai / item not found`);
    else if (c.score !== null && c.score !== undefined && (c.score < 0 || c.score > item.maxMarks)) {
      errors.push(`${c.matric} · ${item.label}: markah di luar julat 0-${item.maxMarks} / out of range`);
    }
    if (c.matric && !/^[A-Za-z0-9/-]{3,20}$/.test(c.matric)) errors.push(`No. Matrik tidak sah: ${c.matric}`);
    if (!sectionIds.has(c.sectionId)) errors.push(`Baris ${idx + 1}: seksyen tidak sah`);
    if (c.status && !['ABSENT', 'BARRED', 'EXEMPTED'].includes(c.status)) errors.push(`Status tidak sah: ${c.status}`);
  }
  if (errors.length > 0) return NextResponse.json({ error: errors.slice(0, 20), errors }, { status: 422 });

  for (const c of changes) {
    await db.mark.upsert({
      where: { sectionId_matric_itemId: { sectionId: c.sectionId, matric: c.matric, itemId: c.itemId } },
      update: { score: c.score ?? null, status: c.status ?? null, offeringId },
      create: { offeringId, sectionId: c.sectionId, matric: c.matric, itemId: c.itemId, score: c.score ?? null, status: c.status ?? null },
    });
  }
  // maintain roster counts (PRD sections.student_count)
  for (const s of offering.sections) {
    const distinct = await db.mark.findMany({ where: { sectionId: s.id }, select: { matric: true }, distinct: ['matric'] });
    await db.section.update({ where: { id: s.id }, data: { studentCount: distinct.length } });
  }
  await audit(g.user.id, 'MARKS_SAVE', 'marks', offeringId, null, { rows: changes.length });
  return NextResponse.json({ ok: true, saved: changes.length });
}
