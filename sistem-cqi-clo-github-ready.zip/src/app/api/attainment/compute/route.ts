import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { loadWindow, computeComparison } from '@/lib/service';
import { audit } from '@/lib/audit';

/**
 * FR-CLO-01..05: compute the three-session comparison for an offering.
 * save=true persists a working snapshot (not report-locked); the report
 * submission path creates the immutable, report-bound snapshot.
 */
export async function POST(req: NextRequest) {
  const g = await guard('view_attainment');
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => ({}));
  const offeringId = (body?.offeringId ?? req.nextUrl.searchParams.get('offeringId')) as string;
  if (!offeringId) return NextResponse.json({ error: 'offeringId diperlukan' }, { status: 400 });
  const access = await requireOfferingAccess(g.user, offeringId);
  if ('error' in access) return access.error;

  const { current, prevs, settings } = await loadWindow(offeringId);
  const { comparison, suggestions } = computeComparison(current, prevs, settings);
  const overall = suggestions.filter((s) => s.affected && s.suggestedType).map((s) => s.suggestedType);
  const overallType = overall.includes('CORRECTIVE') ? 'CORRECTIVE' : overall.includes('PREVENTIVE') ? 'PREVENTIVE' : overall.length > 0 ? 'ENHANCEMENT' : null;

  if (body?.save === true) {
    await db.attainmentSnapshot.create({
      data: {
        offeringId,
        computedBy: g.user.id,
        settingsUsed: JSON.stringify(settings),
        results: JSON.stringify({ comparison, suggestions, overallType }),
      },
    });
    await audit(g.user.id, 'SNAPSHOT_WORKING', 'attainment_snapshots', offeringId);
  }
  return NextResponse.json({ comparison, suggestions, overallType, settings });
}
