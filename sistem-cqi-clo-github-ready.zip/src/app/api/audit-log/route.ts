import { NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';

/** GET /api/audit-log - read-only audit trail (FR-AD-01). KJ/Quality/Admin only. */
export async function GET() {
  const g = await guard('view_audit_log');
  if ('error' in g) return g.error;
  const rows = await db.auditLog.findMany({
    orderBy: { at: 'desc' },
    take: 200,
    include: { actor: { select: { fullName: true } } },
  });
  return NextResponse.json({
    rows: rows.map((r) => ({ id: r.id, action: r.action, tableName: r.tableName, rowId: r.rowId, at: r.at, actor: r.actor })),
  });
}
