import { NextRequest, NextResponse } from 'next/server';
import { guard, requireOfferingAccess } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { audit } from '@/lib/audit';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { evidenceObjectPath, supabaseStorageConfigured, uploadEvidence } from '@/lib/supabase';

/** POST evidence upload (FR-PCQI-05): PDF/JPG/PNG/DOCX, 5MB cap, private store. */
const ALLOWED: Record<string, string> = {
  'application/pdf': '.pdf',
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
};
const MAX_SIZE = 5 * 1024 * 1024;

export async function POST(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const form = await req.formData().catch(() => null);
  if (!form) return NextResponse.json({ error: ' multipart diperlukan' }, { status: 400 });
  const file = form.get('file') as File | null;
  const actionId = (form.get('actionId') as string) || null;
  if (!file) return NextResponse.json({ error: 'Fail diperlukan' }, { status: 400 });
  if (!ALLOWED[file.type]) return NextResponse.json({ error: 'Jenis fail tidak dibenarkan (PDF/JPG/PNG/DOCX sahaja)' }, { status: 415 });
  if (file.size > MAX_SIZE) return NextResponse.json({ error: 'Fail melebihi 5MB' }, { status: 413 });

  if (actionId) {
    const action = await db.cqiAction.findUnique({ where: { id: actionId }, include: { originReport: { include: { offering: true } } } });
    if (!action) return NextResponse.json({ error: 'Tindakan tidak dijumpai' }, { status: 404 });
    const access = await requireOfferingAccess(g.user, action.originReport.offeringId, 'edit_report');
    if ('error' in access) return access.error;
  }

  const id = randomUUID();
  const buffer = new Uint8Array(await file.arrayBuffer());
  let storagePath: string;

  if (supabaseStorageConfigured()) {
    // Production path (PRD 13.4): private Supabase Storage bucket `evidence`.
    const objectPath = evidenceObjectPath(id, ALLOWED[file.type]);
    try {
      await uploadEvidence(objectPath, buffer, file.type);
      storagePath = `supabase://evidence/${objectPath}`;
    } catch (err) {
      console.error('Supabase Storage upload failed, falling back to disk:', err);
      storagePath = writeToDisk(id, ALLOWED[file.type], buffer);
    }
  } else {
    // Sandbox/local fallback: disk-backed private store.
    storagePath = writeToDisk(id, ALLOWED[file.type], buffer);
  }

  const record = await db.evidenceFile.create({
    data: {
      actionId,
      storagePath,
      fileName: file.name,
      mime: file.type,
      size: file.size,
      uploadedById: g.user.id,
    },
  });
  await audit(g.user.id, 'EVIDENCE_UPLOAD', 'evidence_files', record.id, null, { fileName: file.name, size: file.size });
  return NextResponse.json({ ok: true, id: record.id, fileName: file.name, store: storagePath.startsWith('supabase://') ? 'supabase' : 'disk' });
}

function writeToDisk(id: string, ext: string, buffer: Uint8Array): string {
  const dir = path.join(process.cwd(), 'uploads', 'evidence');
  fs.mkdirSync(dir, { recursive: true });
  const rel = path.join('uploads', 'evidence', `${id}${ext}`);
  fs.writeFileSync(path.join(process.cwd(), rel), buffer);
  return rel;
}
