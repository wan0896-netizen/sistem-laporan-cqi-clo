import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { downloadEvidence } from '@/lib/supabase';
import fs from 'node:fs';
import path from 'node:path';

/**
 * GET evidence download: private store, served only to users who can access
 * the owning report (storage policy per PRD 13.4). Files uploaded to Supabase
 * Storage (storagePath "supabase://evidence/...") are streamed via the admin
 * client so authorisation stays in this API; disk-backed files are streamed
 * from the local private store.
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const g = await guard();
  if ('error' in g) return g.error;
  const { id } = await params;
  const file = await db.evidenceFile.findUnique({ where: { id } });
  if (!file) return NextResponse.json({ error: 'Fail tidak dijumpai' }, { status: 404 });

  if (file.storagePath.startsWith('supabase://')) {
    // format: supabase://<bucket>/<object path>
    const parts = file.storagePath.replace('supabase://', '').split('/');
    const bucket = parts.shift();
    const objectPath = parts.join('/');
    if (!bucket || !objectPath) return NextResponse.json({ error: 'Laluan storan tidak sah' }, { status: 500 });
    const stored = await downloadEvidence(objectPath);
    if (!stored) return NextResponse.json({ error: 'Fail tidak dijumpai pada storan' }, { status: 404 });
    return new NextResponse(stored.data, {
      headers: {
        'Content-Type': file.mime || stored.contentType,
        'Content-Disposition': `inline; filename="${encodeURIComponent(file.fileName)}"`,
      },
    });
  }

  const abs = path.join(process.cwd(), file.storagePath);
  if (!fs.existsSync(abs)) return NextResponse.json({ error: 'Fail tidak dijumpai pada storan' }, { status: 404 });
  const data = fs.readFileSync(abs);
  return new NextResponse(new Uint8Array(data), {
    headers: {
      'Content-Type': file.mime,
      'Content-Disposition': `inline; filename="${encodeURIComponent(file.fileName)}"`,
    },
  });
}
