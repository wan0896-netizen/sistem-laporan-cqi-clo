import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';
import { audit } from '@/lib/audit';

/** GET curriculum feedback register (FR-CF-03), filterable. */
export async function GET(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const user = g.user;
  const course = req.nextUrl.searchParams.get('course');
  const programme = req.nextUrl.searchParams.get('programme');
  const topic = req.nextUrl.searchParams.get('topic');
  const sessionId = req.nextUrl.searchParams.get('sessionId');
  const deptWide = user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r));
  const programmeIds = user.programmes.filter(Boolean) as string[];
  const programmeScoped = user.roles.some((r) => ['kpro', 'kk'].includes(r));

  const feedback = await db.curriculumFeedback.findMany({
    where: {
      ...(topic ? { topic } : {}),
      ...(sessionId ? { sessionId } : {}),
    },
    include: { course: true, session: true, report: { include: { offering: { include: { programme: true } } } } },
    orderBy: { createdAt: 'desc' },
    take: 300,
  });

  const visible = feedback.filter((f) => {
    if (deptWide) return true;
    const pid = f.report?.offering.programmeId;
    if (programmeScoped) return pid ? programmeIds.includes(pid) : false;
    return f.report?.offering.coordinatorId === user.id;
  }).filter((f) => (!course || f.course.code === course) && (!programme || f.report?.offering.programme.code === programme));

  return NextResponse.json({
    feedback: visible.map((f) => ({
      id: f.id,
      topic: f.topic,
      text: f.text,
      status: f.status,
      createdAt: f.createdAt,
      courseCode: f.course.code,
      courseName: f.course.name,
      programme: f.report?.offering.programme.code ?? '-',
      sessionLabel: f.session?.label ?? '-',
      reportId: f.reportId,
    })),
  });
}

/** POST update feedback status (FR-CF-04) - KPro/Admin only. */
export async function POST(req: NextRequest) {
  const g = await guard('manage_feedback_status');
  if ('error' in g) return g.error;
  const body = await req.json().catch(() => null);
  const id = body?.id as string;
  const status = body?.status as string;
  if (!id || !['NEW', 'ACKNOWLEDGED', 'ACTIONED'].includes(status)) {
    return NextResponse.json({ error: 'id dan status (NEW/ACKNOWLEDGED/ACTIONED) diperlukan' }, { status: 400 });
  }
  await db.curriculumFeedback.update({ where: { id }, data: { status } });
  await audit(g.user.id, 'FEEDBACK_STATUS', 'curriculum_feedback', id, null, { status });
  return NextResponse.json({ ok: true });
}
