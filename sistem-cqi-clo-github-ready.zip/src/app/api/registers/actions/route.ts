import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/api-auth';
import { db } from '@/lib/db';

/**
 * GET /api/registers/actions - CQI Action Register: all actions with status,
 * evidence and impact (Problem #4: cannot show impact of CQI on later results).
 * Filterable by course/programme/session/status.
 */
export async function GET(req: NextRequest) {
  const g = await guard();
  if ('error' in g) return g.error;
  const user = g.user;
  const courseCode = req.nextUrl.searchParams.get('course');
  const sessionId = req.nextUrl.searchParams.get('sessionId');
  const status = req.nextUrl.searchParams.get('status');
  const deptWide = user.roles.some((r) => ['kj', 'quality', 'admin'].includes(r));
  const programmeIds = user.programmes.filter(Boolean) as string[];
  const programmeScoped = user.roles.some((r) => ['kpro', 'kk'].includes(r));

  const actions = await db.cqiAction.findMany({
    where: {
      ...(status ? { status } : {}),
      ...(sessionId ? { originReport: { offering: { sessionId } } } : {}),
    },
    include: {
      clo: true,
      owner: true,
      originReport: { include: { offering: { include: { course: true, session: true, programme: true } } } },
      evidenceFiles: true,
      verifiedIn: true,
    },
    orderBy: { updatedAt: 'desc' },
    take: 300,
  });

  const visible = actions.filter((a) => {
    if (deptWide) return true;
    if (programmeScoped) return programmeIds.includes(a.originReport.offering.programmeId);
    return a.originReport.offering.coordinatorId === user.id || a.ownerId === user.id;
  }).filter((a) => !courseCode || a.originReport.offering.course.code === courseCode);

  return NextResponse.json({
    actions: visible.map((a) => ({
      id: a.id,
      description: a.description,
      status: a.status,
      implementedDate: a.implementedDate,
      targetDate: a.targetDate,
      impact: a.impact,
      impactText: a.impactText,
      unplanned: a.unplanned,
      cloCode: a.clo?.code ?? null,
      owner: a.owner?.fullName ?? null,
      courseCode: a.originReport.offering.course.code,
      courseName: a.originReport.offering.course.name,
      programme: a.originReport.offering.programme.code,
      sessionLabel: a.originReport.offering.session.label,
      originReportId: a.originReportId,
      originReportStatus: a.originReport.status,
      evidenceFiles: a.evidenceFiles.map((e) => ({ id: e.id, fileName: e.fileName })),
    })),
  });
}
