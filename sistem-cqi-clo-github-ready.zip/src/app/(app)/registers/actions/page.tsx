'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ActionStatusBadge } from '@/components/shared/ui-bits';
import { fmtDate } from '@/lib/format';

interface ActionItem {
  id: string;
  description: string;
  status: string;
  implementedDate: string | null;
  targetDate: string | null;
  impact: string | null;
  impactText: string | null;
  unplanned: boolean;
  cloCode: string | null;
  owner: string | null;
  courseCode: string;
  courseName: string;
  programme: string;
  sessionLabel: string;
  evidenceFiles: { id: string; fileName: string }[];
}

export default function ActionsRegisterPage() {
  const [actions, setActions] = useState<ActionItem[] | null>(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/registers/actions')
      .then(async (r) => { if (!r.ok) throw new Error((await r.json()).error); return r.json(); })
      .then((d) => setActions(d.actions ?? []))
      .catch((e) => setError(String(e.message)));
  }, []);

  const filtered = (actions ?? []).filter((a) => !statusFilter || a.status === statusFilter);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Daftar Tindakan CQI</h1>
        <p className="text-sm text-muted-foreground">Semua tindakan CQI merentas sesi - bukti hubungan antara tindakan dan impak pencapaian CLO</p>
      </div>
      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Tindakan ({filtered.length})</CardTitle>
          <div className="flex gap-2">
            {['', 'PLANNED', 'IMPLEMENTED', 'PARTIAL', 'NOT_IMPLEMENTED'].map((s) => (
              <button key={s} onClick={() => setStatusFilter(s)} className={`rounded-full border px-2.5 py-1 text-xs ${statusFilter === s ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-accent'}`}>
                {s === '' ? 'Semua' : s}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {!actions ? (
            <div className="space-y-2"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
          ) : filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground">Tiada tindakan.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tindakan/Aktiviti</TableHead>
                  <TableHead>Kursus</TableHead>
                  <TableHead>Sesi</TableHead>
                  <TableHead>CLO</TableHead>
                  <TableHead>Pelaksana</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tarikh</TableHead>
                  <TableHead>Impak</TableHead>
                  <TableHead>Bukti</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell className="max-w-72">
                      <span className="line-clamp-2">{a.description}</span>
                      {a.unplanned && <Badge variant="outline" className="mt-1 text-[10px]">tambahan</Badge>}
                    </TableCell>
                    <TableCell className="text-sm">
                      <Link href={`/offerings`} className="hover:underline">{a.courseCode}</Link>
                      <p className="text-xs text-muted-foreground">{a.programme}</p>
                    </TableCell>
                    <TableCell className="text-sm">{a.sessionLabel}</TableCell>
                    <TableCell className="text-sm">{a.cloCode ?? '-'}</TableCell>
                    <TableCell className="text-sm">{a.owner ?? '-'}</TableCell>
                    <TableCell><ActionStatusBadge status={a.status} /></TableCell>
                    <TableCell className="text-sm">{fmtDate(a.implementedDate)}{a.targetDate && !a.implementedDate ? `(sasaran ${fmtDate(a.targetDate)})` : ''}</TableCell>
                    <TableCell className="max-w-52 text-sm">
                      {a.impact ? <Badge variant="outline">{a.impact}</Badge> : '-'}
                      {a.impactText && <p className="text-xs text-muted-foreground line-clamp-2">{a.impactText}</p>}
                    </TableCell>
                    <TableCell className="text-sm">
                      {a.evidenceFiles.length === 0 ? '-' : a.evidenceFiles.map((e) => (
                        <a key={e.id} href={`/api/evidence/${e.id}`} target="_blank" className="block text-xs text-primary hover:underline">{e.fileName}</a>
                      ))}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
