'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { fmtDateTime } from '@/lib/format';

interface FeedbackItem {
  id: string;
  topic: string;
  text: string;
  status: string;
  createdAt: string;
  courseCode: string;
  courseName: string;
  programme: string;
  sessionLabel: string;
  reportId: string | null;
}

const STATUS_CLASS: Record<string, string> = {
  NEW: 'bg-sky-50 text-sky-900 border-sky-300',
  ACKNOWLEDGED: 'bg-amber-50 text-amber-900 border-amber-300',
  ACTIONED: 'bg-emerald-50 text-emerald-800 border-emerald-300',
};

export default function FeedbackRegisterPage() {
  const [items, setItems] = useState<FeedbackItem[] | null>(null);
  const [topicFilter, setTopicFilter] = useState('ALL');
  const [error, setError] = useState<string | null>(null);
  const [me, setMe] = useState<{ roles: string[] } | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    (async () => {
      const [res, meRes] = await Promise.all([fetch('/api/registers/feedback'), fetch('/api/auth/me')]);
      if (!res.ok) {
        setError('Gagal memuatkan daftar');
        return;
      }
      setItems((await res.json()).feedback ?? []);
      setMe((await meRes.json()).user);
    })();
  }, []);

  const canManage = me?.roles.includes('kpro') || me?.roles.includes('admin');

  async function updateStatus(id: string, status: string) {
    const res = await fetch('/api/registers/feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) });
    if (res.ok) {
      setItems((prev) => (prev ?? []).map((f) => (f.id === id ? { ...f, status } : f)));
      toast({ title: 'Status dikemas kini' });
    } else {
      toast({ title: 'Gagal', variant: 'destructive' });
    }
  }

  const topics = [...new Set((items ?? []).map((f) => f.topic))];
  const filtered = (items ?? []).filter((f) => topicFilter === 'ALL' || f.topic === topicFilter);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Daftar Maklumbalas Kurikulum</h1>
        <p className="text-sm text-muted-foreground">Maklumbalas Seksyen D dalam satu daftar berstruktur, boleh ditapis (masalah #5: maklumbalas terkubur dalam laporan)</p>
      </div>
      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Maklumbalas ({filtered.length})</CardTitle>
          <CardDescription>Status dikemas kini oleh KPro/Admin (FR-CF-04): New → Acknowledged → Actioned</CardDescription>
          <Select value={topicFilter} onValueChange={setTopicFilter}>
            <SelectTrigger className="w-64" aria-label="Perkara"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Semua perkara</SelectItem>
              {topics.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {!items ? (
            <div className="space-y-2"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
          ) : filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground">Tiada maklumbalas.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Perkara</TableHead>
                  <TableHead>Kursus</TableHead>
                  <TableHead>Sesi</TableHead>
                  <TableHead className="min-w-72">Maklumbalas/Cadangan</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Dicipta</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((f) => (
                  <TableRow key={f.id}>
                    <TableCell><Badge variant="outline">{f.topic}</Badge></TableCell>
                    <TableCell className="text-sm">{f.courseCode}<p className="text-xs text-muted-foreground">{f.programme}</p></TableCell>
                    <TableCell className="text-sm">{f.sessionLabel}</TableCell>
                    <TableCell className="text-sm">{f.text}</TableCell>
                    <TableCell>
                      {canManage ? (
                        <Select value={f.status} onValueChange={(v) => updateStatus(f.id, v)}>
                          <SelectTrigger className="w-40" aria-label="Status"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="NEW">New</SelectItem>
                            <SelectItem value="ACKNOWLEDGED">Acknowledged</SelectItem>
                            <SelectItem value="ACTIONED">Actioned</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant="outline" className={STATUS_CLASS[f.status]}>{f.status}</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{fmtDateTime(f.createdAt)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
