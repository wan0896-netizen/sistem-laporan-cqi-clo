import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { AppShell } from '@/components/layout/app-shell';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getSession();
  if (!user) redirect('/login');
  return <AppShell user={{ id: user.id, fullName: user.fullName, email: user.email, roles: user.roles }}>{children}</AppShell>;
}
