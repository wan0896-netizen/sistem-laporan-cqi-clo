'use client';

import { useCallback, useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { fmtDateTime } from '@/lib/format';
import { ROLES, ROLE_LABELS, type Role } from '@/lib/permissions';
import { Bell, CheckCircle2, Cloud, Database, Loader2, Plus, RefreshCw, Save, ShieldAlert, XCircle } from 'lucide-react';

interface MasterData {
  programmes: { id: string; code: string; name: string; level: string; verificationChain: string }[];
  courses: { id: string; code: string; name: string; credit: number; programmes: { programmeId: string }[] }[];
  clos: { id: string; code: string; statement: string; domain: string; version: number; courseId: string; course: { code: string }; ploMap: { plo: { code: string } }[] }[];
  plos: { id: string; code: string; statement: string; programme: { code: string } }[];
  sessions: { id: string; label: string; year: string; term: number; seqNo: number; deadline: string | null; status: string }[];
  offerings: { id: string; courseId: string; sessionId: string; programmeId: string; coordinatorId: string | null; course: { code: string }; session: { label: string }; programme: { code: string }; coordinator: { fullName: string } | null; sections: { code: string; studentCount: number }[] }[];
  users: { id: string; email: string; fullName: string; staffId: string | null; active: boolean; userRoles: { role: string; programmeId: string | null }[] }[];
  lookups: { id: string; type: string; code: string; labelBm: string; labelEn: string; sortOrder: number; active: boolean }[];
  templates: { id: string; versionLabel: string; effectiveDate: string; updatedDate: string; active: boolean }[];
  settings: { key: string; value: string }[];
}

const EDITABLE_SETTINGS = [
  'cloTarget', 'dropThreshold', 'comparisonWindow', 'attainmentMethod', 'cloScoreThresholdPercent',
  'excludeAbsentBarred', 'lowSampleThreshold', 'aiEnabled', 'aiMaxCallsPerUserPerDay', 'aiMonthlyTokenBudget', 'allowedEmailDomains',
];

interface SbStatus {
  url: string | null;
  projectRef: string | null;
  configured: boolean;
  reachable: boolean;
  latencyMs: number | null;
  storageConfigured: boolean;
  dbConfigured: boolean;
  detail: string;
}

export default function AdminPage() {
  const { toast } = useToast();
  const [data, setData] = useState<MasterData | null>(null);
  const [busy, setBusy] = useState(false);
  const [auditRows, setAuditRows] = useState<{ id: string; action: string; tableName: string; rowId: string | null; at: string; actor: { fullName: string } | null }[]>([]);
  // dialogs
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [newUser, setNewUser] = useState({ email: '', fullName: '', staffId: '', password: 'Polisas#2026', role: 'lecturer' as Role, programmeId: '' });
  const [addCourseOpen, setAddCourseOpen] = useState(false);
  const [newCourse, setNewCourse] = useState({ code: '', name: '', credit: 3 });
  const [addSessionOpen, setAddSessionOpen] = useState(false);
  const [newSession, setNewSession] = useState({ label: '', year: '', term: 1, seqNo: 0, deadline: '' });
  const [addOfferingOpen, setAddOfferingOpen] = useState(false);
  const [newOffering, setNewOffering] = useState({ courseId: '', sessionId: '', programmeId: '', coordinatorId: '' });
  const [addLookupOpen, setAddLookupOpen] = useState(false);
  const [newLookup, setNewLookup] = useState({ type: 'ISSUE_CATEGORY', code: '', labelBm: '', labelEn: '', sortOrder: 99 });
  const [addTemplateOpen, setAddTemplateOpen] = useState(false);
  const [newTemplate, setNewTemplate] = useState({ versionLabel: '', effectiveDate: '' });
  const [settingsDraft, setSettingsDraft] = useState<Record<string, string>>({});
  const [sbStatus, setSbStatus] = useState<SbStatus | null>(null);
  const [sbLoading, setSbLoading] = useState(false);

  const loadSupabaseStatus = useCallback(async () => {
    setSbLoading(true);
    try {
      const res = await fetch('/api/system/supabase-status');
      if (res.ok) setSbStatus(await res.json());
    } finally {
      setSbLoading(false);
    }
  }, []);

  const load = useCallback(async () => {
    const res = await fetch('/api/admin/master');
    if (!res.ok) return;
    const d = await res.json();
    setData(d);
    setSettingsDraft(Object.fromEntries((d.settings as { key: string; value: string }[]).map((s) => [s.key, s.value])));
    const auditRes = await fetch('/api/audit-log');
    if (auditRes.ok) setAuditRows((await auditRes.json()).rows ?? []);
  }, []);

  useEffect(() => {
    load();
    loadSupabaseStatus();
  }, [load, loadSupabaseStatus]);

  async function post(entity: string, action: string, payload: Record<string, unknown>) {
    setBusy(true);
    try {
      const res = await fetch('/api/admin/master', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ entity, action, data: payload }) });
      const result = await res.json();
      if (!res.ok) {
        toast({ title: 'Gagal', description: result.error, variant: 'destructive' });
        return false;
      }
      toast({ title: 'Berjaya' });
      await load();
      return true;
    } finally {
      setBusy(false);
    }
  }

  if (!data) return <div className="space-y-3"><div className="h-10 w-64 animate-pulse rounded bg-muted" /><div className="h-96 w-full animate-pulse rounded bg-muted" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold">Pentadbiran Sistem</h1>
          <p className="text-sm text-muted-foreground">Master data, templat borang, senarai dropdown, tetapan peraturan dan log audit (FR-MD-*)</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-4 w-4" /> Muat semula</Button>
      </div>

      <Tabs defaultValue="users">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="users">Pengguna</TabsTrigger>
          <TabsTrigger value="programmes">Program & PLO</TabsTrigger>
          <TabsTrigger value="courses">Kursus & CLO</TabsTrigger>
          <TabsTrigger value="sessions">Sesi</TabsTrigger>
          <TabsTrigger value="offerings">Penawaran</TabsTrigger>
          <TabsTrigger value="templates">Templat Borang</TabsTrigger>
          <TabsTrigger value="lookups">Senarai Dropdown</TabsTrigger>
          <TabsTrigger value="settings">Tetapan</TabsTrigger>
          <TabsTrigger value="audit">Log Audit</TabsTrigger>
          <TabsTrigger value="infra">Supabase</TabsTrigger>
        </TabsList>

        {/* Users (FR-AUTH-02: roles managed by Admin only) */}
        <TabsContent value="users">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Pengguna & Peranan</CardTitle>
              <Button size="sm" onClick={() => setAddUserOpen(true)}><Plus className="h-4 w-4" /> Tambah Pengguna</Button>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Emel</TableHead>
                    <TableHead>Nama</TableHead>
                    <TableHead>No. Staf</TableHead>
                    <TableHead>Peranan</TableHead>
                    <TableHead>Aktif</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.users.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="text-sm">{u.email}</TableCell>
                      <TableCell className="text-sm">{u.fullName}</TableCell>
                      <TableCell className="text-sm">{u.staffId ?? '-'}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {u.userRoles.map((r) => <Badge key={`${r.role}-${r.programmeId}`} variant="outline">{ROLE_LABELS[r.role as Role]?.bm ?? r.role}</Badge>)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => post('user', u.active ? 'delete' : 'update', { id: u.id, active: !u.active })}
                        >
                          {u.active ? 'Nyahaktifkan' : 'Aktifkan'}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Programmes (verification chain configurable - FR-WF-03) */}
        <TabsContent value="programmes">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader><CardTitle className="text-base">Program</CardTitle><CardDescription>Rantai pengesahan boleh dikonfigur per program</CardDescription></CardHeader>
              <CardContent className="space-y-3">
                {data.programmes.map((p) => (
                  <div key={p.id} className="rounded-lg border p-3 space-y-2">
                    <p className="text-sm font-medium">{p.code} - {p.name} <Badge variant="outline">{p.level}</Badge></p>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs text-muted-foreground">Rantai:</span>
                      {(['KK', 'KPRO', 'KJ'] as const).map((role) => {
                        const chain: string[] = JSON.parse(p.verificationChain);
                        const included = chain.includes(role);
                        return (
                          <button
                            key={role}
                            onClick={() => {
                              const current: string[] = JSON.parse(p.verificationChain);
                              const next = included ? current.filter((r) => r !== role) : [...current, role];
                              const order = ['KK', 'KPRO', 'KJ'];
                              next.sort((a, b) => order.indexOf(a) - order.indexOf(b));
                              post('programme', 'update', { id: p.id, verificationChain: next.length > 0 ? next : current });
                            }}
                            className={`rounded-full border px-2.5 py-1 text-xs ${included ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-accent'}`}
                          >
                            {role}
                          </button>
                        );
                      })}
                      <span className="text-xs text-muted-foreground">{(JSON.parse(p.verificationChain) as string[]).join(' → ')}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle className="text-base">PLO</CardTitle></CardHeader>
              <CardContent className="overflow-y-auto max-h-96">
                {data.plos.map((plo) => (
                  <p key={plo.id} className="border-b py-1 text-sm last:border-0">
                    <span className="font-medium">{plo.code}</span> ({plo.programme.code}) - {plo.statement}
                  </p>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Courses & CLOs (FR-MD-01, version bump on statement change - FR-CLO-09) */}
        <TabsContent value="courses">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Kursus & CLO</CardTitle>
              <Button size="sm" onClick={() => setAddCourseOpen(true)}><Plus className="h-4 w-4" /> Tambah Kursus</Button>
            </CardHeader>
            <CardContent className="overflow-y-auto max-h-[32rem]">
              {data.courses.map((course) => (
                <div key={course.id} className="mb-4 rounded-lg border p-3">
                  <p className="text-sm font-medium">{course.code} - {course.name} ({course.credit} kredit)</p>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs">CLO</TableHead>
                        <TableHead className="text-xs">Pernyataan (sunting → versi+1)</TableHead>
                        <TableHead className="text-xs">PLO</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.clos.filter((c) => c.courseId === course.id).map((clo) => (
                        <TableRow key={clo.id}>
                          <TableCell className="text-sm font-medium">v{clo.version} {clo.code}</TableCell>
                          <TableCell>
                            <Input
                              defaultValue={clo.statement}
                              className="h-8"
                              onBlur={(e) => {
                                if (e.target.value !== clo.statement) post('clo', 'update', { id: clo.id, statement: e.target.value });
                              }}
                            />
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">{clo.ploMap.map((m) => m.plo.code).join(', ')}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sessions (FR-MD-02, FR-AD-02 lock) */}
        <TabsContent value="sessions">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Sesi Akademik</CardTitle>
              <Button size="sm" onClick={() => setAddSessionOpen(true)}><Plus className="h-4 w-4" /> Tambah Sesi</Button>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sesi</TableHead>
                    <TableHead>Seq</TableHead>
                    <TableHead>Tarikh akhir</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Kunci/Arkib</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.sessions.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="text-sm font-medium">{s.label}</TableCell>
                      <TableCell className="text-sm">{s.seqNo}</TableCell>
                      <TableCell className="text-sm">
                        <Input
                          type="date"
                          defaultValue={s.deadline ? new Date(s.deadline).toISOString().slice(0, 10) : ''}
                          className="h-8 w-36"
                          onBlur={(e) => {
                            if (e.target.value && new Date(e.target.value).toISOString() !== s.deadline) {
                              post('session', 'update', { id: s.id, deadline: e.target.value });
                            }
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={s.status === 'OPEN' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'bg-stone-100 text-stone-700 border-stone-300'}>
                          {s.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => post('session', 'update', { id: s.id, status: s.status === 'OPEN' ? 'LOCKED' : 'OPEN' })}
                        >
                          {s.status === 'OPEN' ? 'Kunci Sesi (Arkib)' : 'Buka Kunci'}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Offerings (FR-MD-03) */}
        <TabsContent value="offerings">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Penawaran Kursus</CardTitle>
              <Button size="sm" onClick={() => setAddOfferingOpen(true)}><Plus className="h-4 w-4" /> Tambah Penawaran</Button>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Kursus</TableHead>
                    <TableHead>Sesi</TableHead>
                    <TableHead>Program</TableHead>
                    <TableHead>Penyelaras</TableHead>
                    <TableHead>Seksyen</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.offerings.map((o) => (
                    <TableRow key={o.id}>
                      <TableCell className="text-sm font-medium">{o.course.code}</TableCell>
                      <TableCell className="text-sm">{o.session.label}</TableCell>
                      <TableCell className="text-sm">{o.programme.code}</TableCell>
                      <TableCell className="text-sm">{o.coordinator?.fullName ?? '-'}</TableCell>
                      <TableCell className="text-sm">{o.sections.map((s) => `${s.code} (${s.studentCount})`).join(', ')}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Form templates (FR-RPT-02) */}
        <TabsContent value="templates">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Versi Templat Borang</CardTitle>
              <Button size="sm" onClick={() => setAddTemplateOpen(true)}><Plus className="h-4 w-4" /> Terbitkan Versi Baharu</Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Versi</TableHead>
                    <TableHead>Berkuatkuasa</TableHead>
                    <TableHead>Dikemas kini</TableHead>
                    <TableHead>Aktif</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.templates.map((t) => (
                    <TableRow key={t.id}>
                      <TableCell className="font-medium">Ver. {t.versionLabel}</TableCell>
                      <TableCell className="text-sm">{new Date(t.effectiveDate).toLocaleDateString('ms-MY')}</TableCell>
                      <TableCell className="text-sm">{new Date(t.updatedDate).toLocaleDateString('ms-MY')}</TableCell>
                      <TableCell><Badge variant="outline">{t.active ? 'Aktif' : 'Tidak'}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <p className="mt-2 text-xs text-muted-foreground">Laporan lalu kekal setia kepada templat yang digunakan semasa dihantar (Section 3.7).</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Lookups (FR-MD-05) */}
        <TabsContent value="lookups">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Senarai Dropdown (admin-urus)</CardTitle>
              <Button size="sm" onClick={() => setAddLookupOpen(true)}><Plus className="h-4 w-4" /> Tambah</Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {['ISSUE_CATEGORY', 'FEEDBACK_TOPIC', 'CQI_TYPE'].map((type) => (
                <div key={type}>
                  <p className="mb-1 text-sm font-medium">{type === 'ISSUE_CATEGORY' ? 'Isu Pencapaian CLO' : type === 'FEEDBACK_TOPIC' ? 'Perkara Maklumbalas Kurikulum' : 'Jenis CQI'}</p>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs">Kod</TableHead>
                        <TableHead className="text-xs">BM</TableHead>
                        <TableHead className="text-xs">EN</TableHead>
                        <TableHead className="text-xs">Aktif</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.lookups.filter((l) => l.type === type).map((l) => (
                        <TableRow key={l.id}>
                          <TableCell className="text-xs font-mono">{l.code}</TableCell>
                          <TableCell className="text-sm">{l.labelBm}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">{l.labelEn}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={() => post('lookup', 'update', { id: l.id, active: !l.active })}>
                              {l.active ? 'Nyahaktif' : 'Aktifkan'}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings (business parameters, never hard-coded - PRD Section 1) */}
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Tetapan Peraturan Perniagaan</CardTitle>
              <CardDescription>Parameter (55, 5, 2, kaedah pengiraan, AI) dibaca dari jadual settings - bukan dalam kod</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid gap-3 md:grid-cols-2">
                {EDITABLE_SETTINGS.filter((k) => settingsDraft[k] !== undefined).map((key) => {
                  const isBool = ['excludeAbsentBarred', 'aiEnabled'].includes(key);
                  const isNumeric = ['cloTarget', 'dropThreshold', 'comparisonWindow', 'cloScoreThresholdPercent', 'lowSampleThreshold', 'aiMaxCallsPerUserPerDay', 'aiMonthlyTokenBudget'].includes(key);
                  return (
                    <div key={key} className="flex items-center gap-2">
                      <Label className="w-56 text-xs font-mono">{key}</Label>
                      {isBool ? (
                        <Select value={settingsDraft[key]} onValueChange={(v) => setSettingsDraft((prev) => ({ ...prev, [key]: v }))}>
                          <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                          <SelectContent><SelectItem value="true">true</SelectItem><SelectItem value="false">false</SelectItem></SelectContent>
                        </Select>
                      ) : key === 'attainmentMethod' ? (
                        <Select value={settingsDraft[key]} onValueChange={(v) => setSettingsDraft((prev) => ({ ...prev, [key]: v }))}>
                          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="THRESHOLD">THRESHOLD (% pelajar capai paras)</SelectItem>
                            <SelectItem value="AVERAGE">AVERAGE (purata kelas)</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          type={isNumeric ? 'number' : 'text'}
                          value={settingsDraft[key]}
                          onChange={(e) => setSettingsDraft((prev) => ({ ...prev, [key]: e.target.value }))}
                          className="w-40"
                        />
                      )}
                    </div>
                  );
                })}
              </div>
              <Button
                onClick={async () => {
                  setBusy(true);
                  for (const [key, value] of Object.entries(settingsDraft)) {
                    await fetch('/api/admin/master', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ entity: 'setting', action: 'update', data: { key, value } }) });
                  }
                  setBusy(false);
                  toast({ title: 'Tetapan disimpan' });
                }}
                disabled={busy}
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Simpan Tetapan
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Audit log (FR-AD-01) */}
        <TabsContent value="audit">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Log Audit (immutable)</CardTitle>
              <CardDescription>Siapa, apa, bila - ditulis oleh lapisan pelayan; append-only</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto max-h-[32rem]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Masa</TableHead>
                    <TableHead>Pelaku</TableHead>
                    <TableHead>Tindakan</TableHead>
                    <TableHead>Jadual</TableHead>
                    <TableHead>Row</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auditRows.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="text-xs">{fmtDateTime(r.at)}</TableCell>
                      <TableCell className="text-sm">{r.actor?.fullName ?? 'sistem'}</TableCell>
                      <TableCell className="text-xs font-mono">{r.action}</TableCell>
                      <TableCell className="text-xs">{r.tableName}</TableCell>
                      <TableCell className="text-xs">{r.rowId?.slice(0, 12) ?? ''}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Supabase infrastructure (PRD v3.0: Supabase PostgreSQL + Storage) */}
        <TabsContent value="infra">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="text-base flex items-center gap-2"><Cloud className="h-4 w-4" /> Supabase</CardTitle>
                <CardDescription>Status integrasi platform data PRD v3.0 (PostgreSQL + Storage)</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={loadSupabaseStatus} disabled={sbLoading}>
                {sbLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />} Semak semula
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {!sbStatus ? (
                <div className="h-16 w-full animate-pulse rounded bg-muted" />
              ) : (
                <>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-md border p-3 space-y-1">
                      <p className="text-xs text-muted-foreground">Projek</p>
                      <p className="font-mono text-sm break-all">{sbStatus.url ?? 'tidak ditetapkan'}</p>
                      <p className="text-xs text-muted-foreground">ref: {sbStatus.projectRef ?? '-'}</p>
                    </div>
                    <div className="rounded-md border p-3 space-y-1">
                      <p className="text-xs text-muted-foreground">Status sambungan</p>
                      <div className="flex items-center gap-2">
                        {sbStatus.reachable ? (
                          <><CheckCircle2 className="h-5 w-5 text-green-600" /><Badge variant="outline" className="text-green-700">Aktif</Badge></>
                        ) : (
                          <><XCircle className="h-5 w-5 text-destructive" /><Badge variant="outline" className="text-destructive">Tidak aktif</Badge></>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{sbStatus.latencyMs != null ? `${sbStatus.latencyMs} ms` : sbStatus.detail}</p>
                    </div>
                    <div className="rounded-md border p-3 space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1"><Database className="h-3 w-3" /> Pangkalan data langsung (Prisma/PostgreSQL)</p>
                      <Badge variant="outline" className={sbStatus.dbConfigured ? 'text-green-700' : 'text-amber-700'}>
                        {sbStatus.dbConfigured ? 'PostgreSQL aktif (Supabase)' : 'Menunggu kata laluan DB'}
                      </Badge>
                      <p className="text-xs text-muted-foreground">{sbStatus.dbConfigured ? 'Prisma berhubung melalui session pooler (SUPABASE_DATABASE_URL)' : 'Gantikan [YOUR-DATABASE-PASSWORD] dalam .env'}</p>
                    </div>
                    <div className="rounded-md border p-3 space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1"><ShieldAlert className="h-3 w-3" /> Storan bukti (bucket evidence)</p>
                      <Badge variant="outline" className={sbStatus.storageConfigured ? 'text-green-700' : 'text-amber-700'}>
                        {sbStatus.storageConfigured ? 'Supabase Storage' : 'Storan disk (fallback)'}
                      </Badge>
                      <p className="text-xs text-muted-foreground">{sbStatus.storageConfigured ? 'Kunci secret diwujudkan; muat naik FR-PCQI-05 ke Supabase' : 'Tambah SUPABASE_SECRET_KEY dalam .env untuk aktifkan'}</p>
                    </div>
                  </div>
                  {!sbStatus.reachable && <Alert><AlertDescription>{sbStatus.detail}</AlertDescription></Alert>}
                  <p className="text-xs text-muted-foreground">
                    Panduan pengaktifan penuh (kata laluan DB, kunci secret, migrasi): lihat README-supabase.md
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add user dialog */}
      <Dialog open={addUserOpen} onOpenChange={setAddUserOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tambah Pengguna</DialogTitle><DialogDescription>Emel mesti dalam domain dibenarkan. Peranan ditadbir admin sahaja (FR-AUTH-02).</DialogDescription></DialogHeader>
          <div className="space-y-3">
            <div><Label>Emel</Label><Input value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} placeholder="nama@polisas.edu.my" /></div>
            <div><Label>Nama penuh</Label><Input value={newUser.fullName} onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })} /></div>
            <div><Label>No. staf</Label><Input value={newUser.staffId} onChange={(e) => setNewUser({ ...newUser, staffId: e.target.value })} /></div>
            <div><Label>Kata laluan awal</Label><Input value={newUser.password} onChange={(e) => setNewUser({ ...newUser, password: e.target.value })} /></div>
            <div>
              <Label>Peranan</Label>
              <Select value={newUser.role} onValueChange={(v) => setNewUser({ ...newUser, role: v as Role })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => <SelectItem key={r} value={r}>{ROLE_LABELS[r].bm} ({r})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Program (untuk KPro/KK/koordinator)</Label>
              <Select value={newUser.programmeId} onValueChange={(v) => setNewUser({ ...newUser, programmeId: v })}>
                <SelectTrigger><SelectValue placeholder="Tiada / jabatan" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Tiada / jabatan</SelectItem>
                  {data.programmes.map((p) => <SelectItem key={p.id} value={p.id}>{p.code} - {p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddUserOpen(false)}>Batal</Button>
            <Button
              disabled={busy || !newUser.email || !newUser.fullName}
              onClick={async () => {
                const ok = await post('user', 'create', { ...newUser, roles: [newUser.role], programmeId: newUser.programmeId || null });
                if (ok) setAddUserOpen(false);
              }}
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Tambah
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add course dialog */}
      <Dialog open={addCourseOpen} onOpenChange={setAddCourseOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tambah Kursus</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Kod (cth DJA30132)</Label><Input value={newCourse.code} onChange={(e) => setNewCourse({ ...newCourse, code: e.target.value })} /></div>
            <div><Label>Nama</Label><Input value={newCourse.name} onChange={(e) => setNewCourse({ ...newCourse, name: e.target.value })} /></div>
            <div><Label>Kredit</Label><Input type="number" value={newCourse.credit} onChange={(e) => setNewCourse({ ...newCourse, credit: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddCourseOpen(false)}>Batal</Button>
            <Button disabled={busy || !newCourse.code || !newCourse.name} onClick={async () => { const ok = await post('course', 'create', newCourse); if (ok) setAddCourseOpen(false); }}>Tambah</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add session dialog */}
      <Dialog open={addSessionOpen} onOpenChange={setAddSessionOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tambah Sesi (FR-MD-02)</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Label (cth Sesi I 2026/2027)</Label><Input value={newSession.label} onChange={(e) => setNewSession({ ...newSession, label: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Tahun</Label><Input value={newSession.year} onChange={(e) => setNewSession({ ...newSession, year: e.target.value })} placeholder="2026/2027" /></div>
              <div><Label>Term (1/2)</Label><Input type="number" value={newSession.term} onChange={(e) => setNewSession({ ...newSession, term: Number(e.target.value) })} /></div>
            </div>
            <div><Label>Seq (urutan kronologi)</Label><Input type="number" value={newSession.seqNo} onChange={(e) => setNewSession({ ...newSession, seqNo: Number(e.target.value) })} /></div>
            <div><Label>Tarikh akhir laporan</Label><Input type="date" value={newSession.deadline} onChange={(e) => setNewSession({ ...newSession, deadline: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddSessionOpen(false)}>Batal</Button>
            <Button disabled={busy || !newSession.label || !newSession.year} onClick={async () => { const ok = await post('session', 'create', newSession); if (ok) setAddSessionOpen(false); }}>Tambah</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add offering dialog */}
      <Dialog open={addOfferingOpen} onOpenChange={setAddOfferingOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tambah Penawaran (FR-MD-03)</DialogTitle><DialogDescription>Satu penawaran bagi (kursus, sesi, program)</DialogDescription></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Kursus</Label>
              <Select value={newOffering.courseId} onValueChange={(v) => setNewOffering({ ...newOffering, courseId: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih kursus" /></SelectTrigger>
                <SelectContent>{data.courses.map((c) => <SelectItem key={c.id} value={c.id}>{c.code} - {c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Sesi</Label>
              <Select value={newOffering.sessionId} onValueChange={(v) => setNewOffering({ ...newOffering, sessionId: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih sesi" /></SelectTrigger>
                <SelectContent>{data.sessions.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Program</Label>
              <Select value={newOffering.programmeId} onValueChange={(v) => setNewOffering({ ...newOffering, programmeId: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih program" /></SelectTrigger>
                <SelectContent>{data.programmes.map((p) => <SelectItem key={p.id} value={p.id}>{p.code}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Penyelaras Kursus</Label>
              <Select value={newOffering.coordinatorId} onValueChange={(v) => setNewOffering({ ...newOffering, coordinatorId: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih penyelaras" /></SelectTrigger>
                <SelectContent>{data.users.map((u) => <SelectItem key={u.id} value={u.id}>{u.fullName} ({u.email})</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOfferingOpen(false)}>Batal</Button>
            <Button disabled={busy || !newOffering.courseId || !newOffering.sessionId || !newOffering.programmeId} onClick={async () => { const ok = await post('offering', 'create', newOffering); if (ok) setAddOfferingOpen(false); }}>Tambah</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add lookup dialog */}
      <Dialog open={addLookupOpen} onOpenChange={setAddLookupOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tambah Pilihan Dropdown (FR-MD-05)</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Jenis</Label>
              <Select value={newLookup.type} onValueChange={(v) => setNewLookup({ ...newLookup, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ISSUE_CATEGORY">Isu Pencapaian CLO</SelectItem>
                  <SelectItem value="FEEDBACK_TOPIC">Perkara Maklumbalas</SelectItem>
                  <SelectItem value="CQI_TYPE">Jenis CQI</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Kod</Label><Input value={newLookup.code} onChange={(e) => setNewLookup({ ...newLookup, code: e.target.value.toUpperCase() })} /></div>
            <div><Label>Label BM</Label><Input value={newLookup.labelBm} onChange={(e) => setNewLookup({ ...newLookup, labelBm: e.target.value })} /></div>
            <div><Label>Label EN</Label><Input value={newLookup.labelEn} onChange={(e) => setNewLookup({ ...newLookup, labelEn: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddLookupOpen(false)}>Batal</Button>
            <Button disabled={busy || !newLookup.code || !newLookup.labelBm} onClick={async () => { const ok = await post('lookup', 'create', newLookup); if (ok) setAddLookupOpen(false); }}>Tambah</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Publish template dialog */}
      <Dialog open={addTemplateOpen} onOpenChange={setAddTemplateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Terbitkan Versi Templat Baharu (FR-RPT-02)</DialogTitle><DialogDescription>Struktur medan disalin dari templat semasa; laporan lalu kekal versi asalnya.</DialogDescription></DialogHeader>
          <div className="space-y-3">
            <div><Label>Label versi (cth 3.3)</Label><Input value={newTemplate.versionLabel} onChange={(e) => setNewTemplate({ ...newTemplate, versionLabel: e.target.value })} /></div>
            <div><Label>Tarikh berkuatkuasa</Label><Input type="date" value={newTemplate.effectiveDate} onChange={(e) => setNewTemplate({ ...newTemplate, effectiveDate: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddTemplateOpen(false)}>Batal</Button>
            <Button disabled={busy || !newTemplate.versionLabel} onClick={async () => { const ok = await post('template', 'create', { ...newTemplate, layout: undefined }); if (ok) setAddTemplateOpen(false); }}>Terbitkan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
