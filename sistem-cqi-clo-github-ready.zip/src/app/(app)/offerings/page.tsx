'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { useLang } from '@/lib/i18n';
import { ReportStatusBadge, CqiTypeBadge } from '@/components/shared/ui-bits';
import { fmtDate } from '@/lib/format';

interface OfferingRow {
  id: string;
  courseCode: string;
  courseName: string;
  programme: string;
  sessionLabel: string;
  deadline: string | null;
  daysLeft: number | null;
  coordinator: string;
  sections: { code: string; studentCount: number }[];
  rosterStudents: number;
  marksProgress: number;
  reportStatus: string;
  reportId: string | null;
  overallType: string | null;
}

export default function OfferingsPage() {
  const { lang } = useLang();
  const [rows, setRows] = useState<OfferingRow[] | null>(null);

  useEffect(() => {
    fetch('/api/offerings')
      .then((r) => r.json())
      .then((d) => setRows(d.offerings ?? []))
      .catch(() => setRows([]));
  }, []);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Penawaran Kursus</h1>
        <p className="text-sm text-muted-foreground">Semua penawaran kursus dalam skop peranan anda</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Senarai Penawaran</CardTitle>
          <CardDescription>Buka penawaran untuk kemas markah, pencapaian dan laporan CQI</CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {!rows ? (
            <div className="space-y-2"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
          ) : rows.length === 0 ? (
            <p className="text-sm text-muted-foreground">Tiada penawaran kursus diassigned kepada anda.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kursus</TableHead>
                  <TableHead>Program</TableHead>
                  <TableHead>Sesi</TableHead>
                  <TableHead>Seksyen</TableHead>
                  <TableHead>Penyelaras</TableHead>
                  <TableHead>Tarikh akhir</TableHead>
                  <TableHead>Markah</TableHead>
                  <TableHead>Status Laporan</TableHead>
                  <TableHead>Jenis CQI</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((o) => (
                  <TableRow key={o.id}>
                    <TableCell>
                      <Link href={`/offerings/${o.id}`} className="font-medium hover:underline">{o.courseCode}</Link>
                      <p className="text-xs text-muted-foreground">{o.courseName}</p>
                    </TableCell>
                    <TableCell className="text-sm">{o.programme}</TableCell>
                    <TableCell className="text-sm">{o.sessionLabel}</TableCell>
                    <TableCell className="text-sm">{o.sections.map((s) => `${s.code} (${s.studentCount})`).join(', ')}</TableCell>
                    <TableCell className="text-sm">{o.coordinator}</TableCell>
                    <TableCell className="text-sm">
                      {fmtDate(o.deadline)}
                      {o.daysLeft !== null && o.daysLeft < 0 && <span className="ml-1 text-xs text-red-700">(Lewat)</span>}
                    </TableCell>
                    <TableCell className="text-sm">{o.marksProgress}%</TableCell>
                    <TableCell><ReportStatusBadge status={o.reportStatus} /></TableCell>
                    <TableCell><CqiTypeBadge type={o.overallType} /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
