'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BookOpen, CalendarClock, FileDown, FileSpreadsheet, FileText, Users } from 'lucide-react';
import { MarksGrid } from '@/components/offering/marks-grid';
import { AssessmentEditor } from '@/components/offering/assessment-editor';
import { AttainmentView } from '@/components/offering/attainment-view';
import { ReportStatusBadge, CqiTypeBadge } from '@/components/shared/ui-bits';
import { fmtDate, fmtDateTime } from '@/lib/format';

interface OfferingData {
  id: string;
  course: { code: string; name: string; credit: number; clos: { id: string; code: string; statement: string; domain: string; version: number; ploMap: { plo: { code: string } }[] }[] };
  session: { id: string; label: string; deadline: string | null; status: string };
  programme: { code: string; name: string; verificationChain: string };
  coordinator: { fullName: string } | null;
  sections: { id: string; code: string; studentCount: number }[];
  assessments: { id: string; name: string; type: string; weight: number; items: { id: string; label: string; maxMarks: number; cloId: string | null }[] }[];
  marks: { matric: string; itemId: string; score: number | null; status: string | null; sectionId: string }[];
}

interface OfferingMeta {
  reportStatus: string;
  reportId: string | null;
  reportVersion: number | null;
  overallType: string | null;
  marksProgress: number;
  daysLeft: number | null;
  deadline: string | null;
}

function CreateReportButton({ offeringId }: { offeringId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  return (
    <Button
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        try {
          const res = await fetch(`/api/cqi/report?offeringId=${offeringId}`);
          const d = await res.json();
          if (d?.report?.id) router.push(`/reports/${d.report.id}`);
        } finally {
          setBusy(false);
        }
      }}
    >
      <FileText className="h-4 w-4" /> Cipta &amp; Buka Laporan
    </Button>
  );
}

export default function OfferingDetailPage() {
  const params = useParams<{ id: string }>();
  const offeringId = params.id;
  const [data, setData] = useState<OfferingData | null>(null);
  const [meta, setMeta] = useState<OfferingMeta | null>(null);
  const [history, setHistory] = useState<{ id: string; version: number; status: string; overallType: string | null; submittedAt: string | null; submittedBy: { fullName: string } | null; amendedFromId: string | null; verifications: { role: string; decision: string; comment: string | null; signedAt: string; user: { fullName: string } }[]; snapshots: { id: string; computedAt: string; reportId: string | null }[] }[]>([]);
  const [prevOfferingId, setPrevOfferingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [me, setMe] = useState<{ roles: string[]; id: string } | null>(null);

  const loadAll = useCallback(async () => {
    try {
      const [offRes, listRes, meRes] = await Promise.all([
        fetch(`/api/marks?offeringId=${offeringId}`),
        fetch('/api/offerings'),
        fetch('/api/auth/me'),
      ]);
      if (offRes.status === 404) throw new Error('Penawaran tidak dijumpai / Offering not found');
      if (!offRes.ok || !listRes.ok) throw new Error('Gagal memuatkan penawaran / Failed to load');
      const offData = await offRes.json();
      setData(offData.offering);
      const listData = await listRes.json();
      const row = (listData.offerings ?? []).find((o: { id: string }) => o.id === offeringId);
      setMeta(row ?? null);
      const meData = await meRes.json();
      setMe(meData.user);
      // previous offering of the same course+programme (for FR-AS-03 clone)
      const sameCourse = (listData.offerings ?? []).filter((o: { courseCode: string }) => o.courseCode === row?.courseCode);
      setPrevOfferingId(sameCourse.length > 1 ? sameCourse[sameCourse.length - 2]?.id ?? null : null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Kesalahan');
    }
  }, [offeringId]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const loadHistory = useCallback(async () => {
    const res = await fetch(`/api/cqi/history?offeringId=${offeringId}`);
    if (res.ok) {
      const d = await res.json();
      setHistory(d.reports ?? []);
    }
  }, [offeringId]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  if (error) return <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>;
  if (!data) return <div className="space-y-3"><Skeleton className="h-10 w-1/2" /><Skeleton className="h-64 w-full" /></div>;

  // write permissions enforced server-side; UI only gates obvious cases
  const editable = true;

  return (
    <div className="space-y-4">
      {/* Header card (Maklumat Kursus - form header) */}
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="flex flex-wrap items-center gap-2 text-xl">
                <BookOpen className="h-5 w-5 text-primary" />
                {data.course.code} - {data.course.name}
              </CardTitle>
              <CardDescription>
                {data.programme.code} ({data.programme.name}) · {data.session.label} · Penyelaras: {data.coordinator?.fullName ?? '-'} · Kredit: {data.course.credit}
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {meta && <ReportStatusBadge status={meta.reportStatus} />}
              {meta?.overallType && <CqiTypeBadge type={meta.overallType} />}
              {meta?.deadline && (
                <Badge variant="outline" className="gap-1">
                  <CalendarClock className="h-3 w-3" /> {fmtDate(meta.deadline)}
                  {meta.daysLeft !== null && (meta.daysLeft < 0 ? ` (Lewat ${Math.abs(meta.daysLeft)}h)` : ` (${meta.daysLeft}h lagi)`)}
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3 text-sm">
          <span className="inline-flex items-center gap-1"><Users className="h-4 w-4 text-muted-foreground" /> {data.sections.map((s) => `${s.code}: ${s.studentCount}`).join(', ')} pelajar</span>
          <span className="inline-flex items-center gap-1">Kemajuan markah: {meta?.marksProgress ?? 0}%</span>
          <span className="inline-flex items-center gap-1">Rantai pengesahan: {JSON.parse(data.programme.verificationChain).join(' → ')}</span>
          {meta?.reportId && (
            <>
              <a href={`/api/reports/pdf?reportId=${meta.reportId}`}><Button variant="outline" size="sm"><FileDown className="h-4 w-4" /> PDF Ver. 3.2</Button></a>
              <a href={`/api/reports/excel?reportId=${meta.reportId}`}><Button variant="outline" size="sm"><FileSpreadsheet className="h-4 w-4" /> Excel</Button></a>
            </>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="ringkasan" className="space-y-4">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="ringkasan">Ringkasan</TabsTrigger>
          <TabsTrigger value="penilaian">Penilaian</TabsTrigger>
          <TabsTrigger value="markah">Markah</TabsTrigger>
          <TabsTrigger value="pencapaian">Pencapaian</TabsTrigger>
          <TabsTrigger value="laporan">Laporan CQI</TabsTrigger>
          <TabsTrigger value="sejarah">Sejarah</TabsTrigger>
        </TabsList>

        <TabsContent value="ringkasan">
          <Card>
            <CardHeader><CardTitle className="text-base">Ringkasan</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm font-medium">CLO Kursus (dengan pemetaan PLO)</p>
                <ul className="mt-1 space-y-1 text-sm">
                  {data.course.clos.map((c) => (
                    <li key={c.id}>
                      <span className="font-medium">{c.code}</span> ({c.domain}, v{c.version}) - {c.statement}
                      <span className="ml-1 text-xs text-muted-foreground">[{c.ploMap.map((m) => m.plo.code).join(', ')}]</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-sm font-medium">Jadual Laporan CQI</p>
                <ol className="mt-1 list-decimal pl-5 text-sm">
                  <li>Masukkan struktur penilaian (tab Penilaian)</li>
                  <li>Masukkan/markah pelajar (tab Markah)</li>
                  <li>Periksa pencapaian dan perbandingan 3 sesi (tab Pencapaian)</li>
                  <li>Lengkapkan Seksyen A-E dan hantar (tab Laporan CQI)</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="penilaian">
          <AssessmentEditor offeringId={offeringId} data={data} editable={meta?.marksProgress !== undefined} previousOfferingId={prevOfferingId} />
        </TabsContent>

        <TabsContent value="markah">
          <MarksGrid offeringId={offeringId} data={data} editable={true} />
        </TabsContent>

        <TabsContent value="pencapaian">
          <AttainmentView offeringId={offeringId} settings={{ cloTarget: 55, dropThreshold: 5 }} />
        </TabsContent>

        <TabsContent value="laporan">
          <Card>
            <CardHeader><CardTitle className="text-base">Laporan CQI (Seksyen A-E)</CardTitle></CardHeader>
            <CardContent>
              {meta?.reportId ? (
                <div className="space-y-3">
                  <p className="text-sm">Status laporan: <ReportStatusBadge status={meta.reportStatus} /> versi {meta.reportVersion}</p>
                  <Link href={`/reports/${meta.reportId}`}>
                    <Button><FileText className="h-4 w-4" /> Buka Editor Laporan</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">Laporan draf akan dicipta secara automatik dengan baris CQI yang disarankan sistem (FR-CQI-01) apabila editor dibuka.</p>
                  <CreateReportButton offeringId={offeringId} />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sejarah">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Sejarah Laporan</CardTitle>
              <CardDescription>Setiap versi laporan + snapshot pengiraan (FR-CLO-08)</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              {history.length === 0 ? (
                <p className="text-sm text-muted-foreground">Tiada laporan lagi.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Versi</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Jenis CQI</TableHead>
                      <TableHead>Dihantar</TableHead>
                      <TableHead>Pengesahan</TableHead>
                      <TableHead>Snapshot</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {history.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell className="font-medium">
                          v{r.version}
                          {r.amendedFromId && <span className="ml-1 text-xs text-muted-foreground">(pindaan)</span>}
                        </TableCell>
                        <TableCell><ReportStatusBadge status={r.status} /></TableCell>
                        <TableCell><CqiTypeBadge type={r.overallType} /></TableCell>
                        <TableCell className="text-sm">{r.submittedAt ? `${fmtDateTime(r.submittedAt)} · ${r.submittedBy?.fullName ?? ''}` : '-'}</TableCell>
                        <TableCell className="text-sm">
                          {r.verifications.length === 0 ? '-' : r.verifications.map((v) => (
                            <span key={v.role} className="block">{v.role}: {v.decision === 'VERIFIED' ? 'Disahkan' : 'Pulang'} oleh {v.user.fullName}</span>
                          ))}
                        </TableCell>
                        <TableCell className="text-sm">{r.snapshots.length > 0 ? `${r.snapshots.length} snapshot (tetap)` : '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
