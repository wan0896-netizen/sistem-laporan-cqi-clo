'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ClipboardCheck, Eye } from 'lucide-react';
import { ReportStatusBadge, CqiTypeBadge } from '@/components/shared/ui-bits';
import { fmtDateTime } from '@/lib/format';

interface QueueItem {
  reportId: string;
  status: string;
  version: number;
  submittedAt: string | null;
  submittedBy: string;
  courseCode: string;
  courseName: string;
  programme: string;
  sessionLabel: string;
  overallType: string | null;
  chain: string[];
  verifiedRoles: string[];
  requiredRole: string | null;
  myTurn: boolean;
  returnedComment: string | null;
  returnedRole: string | null;
}

export default function VerificationPage() {
  const [queue, setQueue] = useState<QueueItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/verification/queue')
      .then(async (r) => {
        if (!r.ok) throw new Error((await r.json()).error ?? 'Gagal');
        return r.json();
      })
      .then((d) => setQueue(d.queue ?? []))
      .catch((e) => setError(String(e.message ?? e)));
  }, []);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><ClipboardCheck className="h-6 w-6 text-primary" /> Barisan Pengesahan</h1>
        <p className="text-sm text-muted-foreground">Laporan menunggu pengesahan KK / KPro / KJ mengikut rantai program</p>
      </div>
      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Laporan untuk semakan</CardTitle>
          <CardDescription>Buka laporan untuk melihat snapshot pengiraan, menulis Ulasan, mengesahkan atau memulangkan</CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {!queue ? (
            <div className="space-y-2"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
          ) : queue.length === 0 ? (
            <p className="text-sm text-muted-foreground">Tiada laporan menunggu pengesahan.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kursus</TableHead>
                  <TableHead>Sesi</TableHead>
                  <TableHead>Disediakan oleh</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Rantai pengesahan</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {queue.map((q) => (
                  <TableRow key={q.reportId}>
                    <TableCell>
                      <span className="font-medium">{q.courseCode}</span>
                      <p className="text-xs text-muted-foreground">{q.courseName} · {q.programme}</p>
                    </TableCell>
                    <TableCell className="text-sm">{q.sessionLabel}</TableCell>
                    <TableCell className="text-sm">{q.submittedBy}{q.submittedAt ? <p className="text-xs text-muted-foreground">{fmtDateTime(q.submittedAt)}</p> : null}</TableCell>
                    <TableCell><ReportStatusBadge status={q.status} /></TableCell>
                    <TableCell className="text-sm">
                      <div className="flex flex-wrap items-center gap-1">
                        {q.chain.map((r) => (
                          <Badge key={r} variant="outline" className={q.verifiedRoles.includes(r) ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : r === q.requiredRole ? 'bg-sky-50 text-sky-900 border-sky-300' : ''}>
                            {r}{q.verifiedRoles.includes(r) ? ' ✓' : ''}
                          </Badge>
                        ))}
                      </div>
                      {q.status === 'RETURNED' && <p className="mt-1 text-xs text-amber-800">Dipulangkan oleh {q.returnedRole}: {q.returnedComment}</p>}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {q.myTurn && <Badge className="bg-sky-600">Giliran anda ({q.requiredRole})</Badge>}
                        <Link href={`/reports/${q.reportId}`}>
                          <Button variant="outline" size="sm"><Eye className="h-4 w-4" /> Buka</Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
