'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { CalendarClock, ClipboardList, Download, FileCheck2, TriangleAlert } from 'lucide-react';
import { useLang } from '@/lib/i18n';
import { AttainmentBadge, CqiTypeBadge, ReportStatusBadge } from '@/components/shared/ui-bits';
import { fmtDate } from '@/lib/format';

interface OfferingRow {
  id: string;
  courseCode: string;
  courseName: string;
  programme: string;
  sessionLabel: string;
  deadline: string | null;
  daysLeft: number | null;
  coordinator: string;
  sections: { code: string; studentCount: number }[];
  rosterStudents: number;
  marksProgress: number;
  reportStatus: string;
  reportId: string | null;
  overallType: string | null;
}

interface DeptData {
  programmes: { id: string; code: string; name: string }[];
  sessions: { id: string; label: string; seqNo: number }[];
  activeSessionId: string;
  rows: {
    offeringId: string;
    programme: string;
    courseCode: string;
    courseName: string;
    studentCount: number;
    clos: { cloId: string; code: string; attainment: number | null; met: boolean | null; delta: number | null; declined: boolean; lowSample: boolean }[];
    reportStatus: string;
    overallType: string | null;
    daysLeft: number | null;
  }[];
  summary: {
    totalOfferings: number;
    submitted: number;
    verified: number;
    completionRate: number;
    complianceRate: number | null;
    cqiTypeCounts: Record<string, number>;
    belowTarget: typeof rows;
    declined: typeof rows;
  };
}

interface QueueItem {
  reportId: string;
  status: string;
  courseCode: string;
  courseName: string;
  programme: string;
  sessionLabel: string;
  chain: string[];
  requiredRole: string | null;
  myTurn: boolean;
  submittedBy: string;
}

function heatmapColor(v: number | null, met: boolean | null, declined: boolean): string {
  if (v === null || met === null) return 'bg-muted text-muted-foreground';
  if (!met) return 'bg-red-100 text-red-900';
  if (declined) return 'bg-amber-100 text-amber-900';
  if (v >= 80) return 'bg-emerald-200 text-emerald-950';
  return 'bg-emerald-100 text-emerald-900';
}

export default function DashboardPage() {
  const { lang } = useLang();
  const router = useRouter();
  const [offerings, setOfferings] = useState<OfferingRow[] | null>(null);
  const [dept, setDept] = useState<DeptData | null>(null);
  const [sessionFilter, setSessionFilter] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [me, setMe] = useState<{ roles: string[]; fullName: string } | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const meRes = await fetch('/api/auth/me');
        if (meRes.status === 401) {
          router.push('/login');
          return;
        }
        const meData = await meRes.json();
        setMe(meData.user);
        const offRes = await fetch('/api/offerings');
        const offData = await offRes.json();
        setOfferings(offData.offerings ?? []);
      } catch {
        setError('Gagal memuatkan data / Failed to load data');
      }
    })();
  }, [router]);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/reports/department${sessionFilter ? `?sessionId=${sessionFilter}` : ''}`);
        if (!res.ok) return;
        setDept(await res.json());
      } catch {
        /* department view may be unavailable for this role */
      }
    })();
  }, [sessionFilter]);

  const tasks = (offerings ?? []).filter((o) => {
    if (['VERIFIED', 'CLOSED'].includes(o.reportStatus)) return false;
    if (o.marksProgress < 100) return true;
    return ['NOT_STARTED', 'DRAFT', 'RETURNED'].includes(o.reportStatus);
  });

  // verifiers (KK/KPro/KJ) see verification tasks instead of coordinator tasks
  const isVerifier = me?.roles.some((r) => ['kk', 'kpro', 'kj'].includes(r)) ?? false;
  const [verQueue, setVerQueue] = useState<QueueItem[] | null>(null);
  useEffect(() => {
    if (!isVerifier) return;
    fetch('/api/verification/queue')
      .then((r) => (r.ok ? r.json() : { queue: [] }))
      .then((d) => setVerQueue(d.queue ?? []))
      .catch(() => setVerQueue([]));
  }, [isVerifier]);

  const canDepartment = me?.roles.some((r) => ['kj', 'quality', 'admin', 'kpro', 'kk'].includes(r)) ?? false;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{me?.fullName ?? '...'}</h1>
        <p className="text-sm text-muted-foreground">Papan Pemuka / Dashboard - Laporan CQI Pencapaian CLO (Borang Ver. 3.2)</p>
      </div>

      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}

      {/* Tugasan Saya (PRD 14) */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ClipboardList className="h-5 w-5" /> Tugasan Saya</CardTitle>
          <CardDescription>
            {isVerifier
              ? 'Laporan menunggu pengesahan anda / Reports awaiting your verification'
              : 'Markah belum lengkap, laporan belum dihantar / dipulangkan'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!offerings ? (
            <div className="space-y-2"><Skeleton className="h-12 w-full" /><Skeleton className="h-12 w-full" /></div>
          ) : isVerifier ? (
            !verQueue ? (
              <div className="space-y-2"><Skeleton className="h-12 w-full" /></div>
            ) : verQueue.length === 0 ? (
              <p className="text-sm text-muted-foreground">Tiada laporan menunggu pengesahan.</p>
            ) : (
              <div className="space-y-2">
                {verQueue.map((q) => (
                  <Link key={q.reportId} href={q.myTurn ? `/reports/${q.reportId}` : '/verification'} className="block rounded-lg border p-3 hover:bg-accent transition-colors">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold">{q.courseCode}</span>
                      <span className="text-sm text-muted-foreground">{q.courseName}</span>
                      <ReportStatusBadge status={q.status} />
                      {q.myTurn && <Badge className="bg-sky-600">Giliran anda ({q.requiredRole})</Badge>}
                      <span className="ml-auto text-xs text-muted-foreground">{q.sessionLabel} · {q.programme}</span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">Disediakan oleh {q.submittedBy} · Rantai: {q.chain.join(' → ')}</p>
                  </Link>
                ))}
              </div>
            )
          ) : tasks.length === 0 ? (
            <p className="text-sm text-muted-foreground">Tiada tugasan tertanggung. Semua laporan telah disahkan.</p>
          ) : (
            <div className="space-y-2">
              {tasks.map((o) => (
                <Link key={o.id} href={`/offerings/${o.id}`} className="block rounded-lg border p-3 hover:bg-accent transition-colors">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold">{o.courseCode}</span>
                    <span className="text-sm text-muted-foreground">{o.courseName}</span>
                    <ReportStatusBadge status={o.reportStatus} />
                    <span className="ml-auto text-xs text-muted-foreground">{o.sessionLabel} · {o.programme}</span>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-3 text-xs">
                    <span className="inline-flex items-center gap-1 text-muted-foreground w-48">
                      <CalendarClock className="h-3.5 w-3.5" />
                      {o.daysLeft === null ? '-' : o.daysLeft < 0 ? `Lewat ${Math.abs(o.daysLeft)} hari` : `${o.daysLeft} hari lagi`}
                    </span>
                    <span className="w-40">{lang === 'bm' ? 'Markah' : 'Marks'} {o.marksProgress}%</span>
                    <Progress value={o.marksProgress} className="h-1.5 w-40" aria-label="Kemajuan markah" />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Penawaran kursus */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Penawaran Kursus Saya
            <Badge variant="outline">{offerings?.length ?? 0}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Kursus</TableHead>
                <TableHead>Sesi</TableHead>
                <TableHead>Seksyen</TableHead>
                <TableHead>Tarikh akhir</TableHead>
                <TableHead>Status Laporan</TableHead>
                <TableHead>Jenis CQI</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(offerings ?? []).map((o) => (
                <TableRow key={o.id}>
                  <TableCell>
                    <Link href={`/offerings/${o.id}`} className="font-medium hover:underline">{o.courseCode}</Link>
                    <p className="text-xs text-muted-foreground">{o.courseName}</p>
                  </TableCell>
                  <TableCell className="text-sm">{o.sessionLabel}</TableCell>
                  <TableCell className="text-sm">
                    {o.sections.map((s) => `${s.code} (${s.studentCount})`).join(', ')}
                  </TableCell>
                  <TableCell className="text-sm">
                    {fmtDate(o.deadline)}
                    {o.daysLeft !== null && o.daysLeft < 0 && <Badge variant="outline" className="ml-1 bg-red-50 text-red-800 border-red-300">Lewat</Badge>}
                  </TableCell>
                  <TableCell><ReportStatusBadge status={o.reportStatus} /></TableCell>
                  <TableCell><CqiTypeBadge type={o.overallType} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Programme / Department dashboards (FR-RPT-05/06) */}
      {canDepartment && dept && (
        <>
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Papan Pemuka Program & Jabatan</CardTitle>
                <CardDescription>Peta haba pencapaian CLO · kursus di bawah sasaran · kursus menurun ≥ 5 mata</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Select value={sessionFilter} onValueChange={setSessionFilter}>
                  <SelectTrigger className="w-52" aria-label="Sesi"><SelectValue placeholder="Sesi" /></SelectTrigger>
                  <SelectContent>
                    {dept.sessions.map((s) => (
                      <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" asChild>
                  <a href={`/api/reports/excel?sessionId=${dept.activeSessionId}`}>
                    <Download className="h-4 w-4" /> Excel Konsolidated
                  </a>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <Card className="p-4">
                  <p className="text-xs text-muted-foreground">Jumlah penawaran</p>
                  <p className="text-2xl font-bold">{dept.summary.totalOfferings}</p>
                </Card>
                <Card className="p-4">
                  <p className="text-xs text-muted-foreground">Kadar penyempurnaan</p>
                  <p className="text-2xl font-bold">{dept.summary.completionRate}%</p>
                </Card>
                <Card className="p-4">
                  <p className="text-xs text-muted-foreground">Disahkan</p>
                  <p className="text-2xl font-bold">{dept.summary.verified}</p>
                </Card>
                <Card className="p-4">
                  <p className="text-xs text-muted-foreground">Patuhan tarikh akhir</p>
                  <p className="text-2xl font-bold">{dept.summary.complianceRate ?? '-'}%</p>
                </Card>
              </div>

              {/* CLO heatmap */}
              <div className="overflow-x-auto">
                <p className="text-sm font-medium mb-2">Peta haba pencapaian CLO (sesi aktif)</p>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Kursus</TableHead>
                      {dept.rows[0]?.clos.map((c) => <TableHead key={c.cloId} className="text-center">{c.code}</TableHead>)}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dept.rows.map((r) => (
                      <TableRow key={r.offeringId}>
                        <TableCell>
                          <span className="font-medium">{r.courseCode}</span>
                          <span className="ml-2 text-xs text-muted-foreground">{r.programme} · n={r.studentCount}</span>
                        </TableCell>
                        {r.clos.map((c) => (
                          <TableCell key={c.cloId} className="text-center">
                            <span className={`inline-block min-w-14 rounded px-2 py-1 text-xs font-medium ${heatmapColor(c.attainment, c.met, c.declined)}`}>
                              {c.attainment === null ? '-' : `${c.attainment}%`}
                            </span>
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <p className="text-xs text-muted-foreground mt-1">Warna + teks: emerald = mencapai sasaran, merah = tidak mencapai, amber = menurun ≥ 5%, kelabu = tiada data.</p>
              </div>

              {/* Below target + declined */}
              <div className="grid gap-4 lg:grid-cols-2">
                <Card className="p-4">
                  <p className="text-sm font-medium flex items-center gap-2"><TriangleAlert className="h-4 w-4 text-red-600" /> Kursus ada CLO di bawah sasaran ({dept.summary.belowTarget.length})</p>
                  <ul className="mt-2 space-y-1 text-sm">
                    {dept.summary.belowTarget.length === 0 && <li className="text-muted-foreground">Tiada / None</li>}
                    {dept.summary.belowTarget.map((r) => (
                      <li key={r.offeringId}>
                        <Link href={`/offerings/${r.offeringId}`} className="hover:underline">
                          {r.courseCode} <span className="text-xs text-muted-foreground">({r.clos.filter((c) => c.met === false).map((c) => `${c.code} ${c.attainment}%`).join(', ')})</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </Card>
                <Card className="p-4">
                  <p className="text-sm font-medium flex items-center gap-2"><TriangleAlert className="h-4 w-4 text-amber-600" /> Kursus menurun ≥ 5 mata ({dept.summary.declined.length})</p>
                  <ul className="mt-2 space-y-1 text-sm">
                    {dept.summary.declined.length === 0 && <li className="text-muted-foreground">Tiada / None</li>}
                    {dept.summary.declined.map((r) => (
                      <li key={r.offeringId}>
                        <Link href={`/offerings/${r.offeringId}`} className="hover:underline">
                          {r.courseCode} <span className="text-xs text-muted-foreground">({r.clos.filter((c) => c.declined).map((c) => `${c.code} ${c.delta} m.p.`).join(', ')})</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>

              {/* CQI type distribution */}
              <Card className="p-4">
                <p className="text-sm font-medium">Agihan Jenis CQI (laporan sesi aktif)</p>
                <div className="mt-2 flex flex-wrap gap-3">
                  {(['CORRECTIVE', 'PREVENTIVE', 'ENHANCEMENT'] as const).map((t) => (
                    <div key={t} className="flex items-center gap-2 rounded-lg border px-3 py-2">
                      <CqiTypeBadge type={t} />
                      <span className="text-lg font-bold">{dept.summary.cqiTypeCounts[t] ?? 0}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
