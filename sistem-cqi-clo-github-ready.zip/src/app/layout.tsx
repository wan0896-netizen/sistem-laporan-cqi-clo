import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { LangProvider } from "@/lib/i18n";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Sistem Laporan CQI Pencapaian CLO - JKM POLISAS",
  description:
    "Laporan Penambahbaikan Kualiti Berterusan (CQI) Pencapaian CLO - Jabatan Kejuruteraan Mekanikal, Politeknik Sultan Haji Ahmad Shah (POLISAS), Kuantan, Malaysia.",
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ms" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <LangProvider>{children}</LangProvider>
        <Toaster />
      </body>
    </html>
  );
}
