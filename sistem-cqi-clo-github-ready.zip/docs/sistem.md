# Sistem Laporan CQI Pencapaian CLO - JKM POLISAS

Implementation of PRD v3.0 (Sistem Laporan CQI Pencapaian CLO, Jabatan
Kejuruteraan Mekanikal, Politeknik Sultan Haji Ahmad Shah), aligned to
**Borang Laporan CQI Kursus Ver. 3.2** (effective Jan 2026, updated Jun 2026).

## Run

Database: **Supabase PostgreSQL active** since 2026-11-19 (session pooler,
port 5432). Set `SUPABASE_DATABASE_URL` in `.env` first (see `.env.example`).

```bash
npm run db:generate    # generate Prisma Client
npm run db:push        # apply Prisma schema (27 tables -> Supabase PostgreSQL)
npx tsx scripts/seed.ts  # seed demo data (idempotent; wipes + reseeds)
npm run dev            # Next.js on port 3000
npx vitest run         # unit tests for the calculation engine (PRD Section 16)
npm run lint
```

Local SQLite fallback: swap `prisma/schema.sqlite.bak.prisma` in as
`schema.prisma` and point `DATABASE_URL` at `file:./db/custom.db`
(see docs/supabase.md §3).

## Demo accounts (password for all: `Polisas#2026`)

| Role | Email |
| --- | --- |
| Penyelaras Kursus (Coordinator) | penyelaras.dja@polisas.edu.my |
| Ketua Kursus (KK) | kk.dja@polisas.edu.my |
| Ketua Program (KPro, DAD) | kpro.dad@polisas.edu.my |
| Ketua Jabatan (KJ) | kj.jkm@polisas.edu.my |
| Unit Kualiti | quality@polisas.edu.my |
| Pentadbir Sistem | admin@polisas.edu.my |

Demo story: DJA30132 (DAD) - Sesi II 2024/2025 no data ("-"), Sesi I
2025/2026 = 74 students with a VERIFIED report and CQI actions, Sesi II
2025/2026 = 12 students with marks done and a report already submitted
(awaiting KPro after KK verification). CLO 2 = 41.7% (< 55% -> Corrective),
CLO 3 = 72.7% with a -8.1 point drop (>= 5 -> Preventive).

## Architecture (PRD Section 13) and sandbox adaptations

| PRD | This build | Production swap |
| --- | --- | --- |
| Supabase PostgreSQL | Prisma + SQLite, same relational model (PRD 13.3) | Change datasource to `postgresql` + Supabase URL; add RLS policies mirroring `src/lib/permissions.ts` |
| Supabase Auth + JWT roles | HMAC-signed session cookie, roles from `user_roles`, allow-list, forced re-login on role change (FR-AUTH-01/02/03) | Replace `verifyCredentials`/`getSession` with Supabase Auth; permission matrix stays |
| RLS deny-by-default | Server-side guards in `src/lib/api-auth.ts` with the same visibility rules (PRD 13.4) | Mirror as RLS policies; keep the guard layer |
| Supabase Storage (evidence) | Disk-backed private store + authorised streaming route | Swap `storagePath` handling for signed URLs |
| Supabase Realtime notifications | In-app notifications with 15 s polling (FR-NT-01) | Socket.io/Realtime channel |
| Z.ai GLM 5.3 runtime AI | `src/lib/ai/provider.ts` - provider-agnostic `AiProvider`, Zod-validated output, anonymiser, rate limit + budget + feature flag, rule-based fallback (PRD Section 11) | Set `ZAI_MODEL`/keys; confirm base URL in official docs |
| Vercel Cron reminders | `/api/cron/reminders` (T-7/T-3/T-1, overdue + escalation) with `x-cron-secret` or admin "run now" | Schedule in Vercel Cron with `CRON_SECRET` |

## PRD traceability (Phase 1 P0 complete)

- FR-AUTH-01/02/03, FR-MD-01..05, FR-AS-01/02/03, FR-MK-01..05
- FR-CLO-01..09 (attainment, 3-session comparison, 55%/5-point rules, chart,
  below-target record, snapshots at submission, like-for-like warning)
- FR-PCQI-01..05 (carry-forward, impact suggestion, unplanned actions, evidence)
- FR-CQI-01..09 (auto rows, type suggestion + override, six cause factors,
  mandatory Cadangan/Punca, owner/date/outcome seeding Section B, AI draft,
  BM/EN toggle)
- FR-CF-01..04 (feedback rows, register, status by KPro/Admin)
- FR-WF-01..06 (states, Disediakan oleh, configurable verification chain per
  programme, Ulasan, read-only after verification + amend as new version,
  deadline reminders + escalation)
- FR-RPT-01..07 (Ver. 3.2 PDF incl. footer version line + chart, template
  versioning, Excel, lecturer/programme/department dashboards, consolidated export)
- FR-NT-01, FR-AD-01/02 (in-app notifications, immutable audit log, session lock)
- NFRs: settings-driven rules (55/5/2/method), PDPA (matric + marks only,
  no IC), colour never the only status indicator, WCAG-minded labels,
  TypeScript shared calculation module.

Open questions from PRD Section 19 are handled as configurable settings or
admin-managed lookups (attainment method THRESHOLD/AVERAGE, Isu Pencapaian
categories, verification chain per programme, low-sample threshold, AI flag).

## Sample outputs (docs/contoh/)

- `docs/contoh/Contoh-Laporan-CQI-DJA30132-SesiI-Ver3.2.pdf` - exported Form Ver. 3.2 PDF
- `docs/contoh/Laporan-Konsolidated-SesiII-2025-2026.xlsx` - consolidated semester Excel
