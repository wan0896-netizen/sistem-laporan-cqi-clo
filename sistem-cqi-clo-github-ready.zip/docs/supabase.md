# Integrasi Supabase — Sistem Laporan CQI Pencapaian CLO (JKM POLISAS)

Status: **Pangkalan data Supabase PostgreSQL AKTIF** (dikuatkuasakan 19 November 2026) | PRD v3.0 stack: Z.ai (GLM) + Supabase (PostgreSQL) + Vercel

## 1. Maklumat projek yang telah ditetapkan

| Pembolehubah | Nilai | Status |
| --- | --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | `https://pqvdalbvqkkvbjsddisr.supabase.co` | Aktif |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | `sb_publishable_X-1HVJ6BJ_...` | Aktif |
| `SUPABASE_PROJECT_REF` | `pqvdalbvqkkvbjsddisr` | Aktif |
| `SUPABASE_DATABASE_URL` | `postgres.pqvdalbvqkkvbjsddisr@aws-1-ap-northeast-1.pooler.supabase.com:5432` + `sslmode=require&connection_limit=10` | **Aktif — sambungan aplikasi & migrasi** |
| `SUPABASE_DB_URL` | `postgres@db.pqvdalbvqkkvbjsddisr.supabase.co:5432` | Simpanan rujukan (endpoint IPv6 sahaja) |
| `SUPABASE_POOLER_URL` | `aws-1-ap-northeast-1...:6543` + `pgbouncer=true&connection_limit=1` | Untuk Vercel/serverless (runtime) |
| `SUPABASE_SECRET_KEY` | (belum ditetapkan) | **Tinggal: kunci `sb_secret_...` untuk Storage** |

### Nota teknikal penting

1. **Nama pembolehubah khusus `SUPABASE_DATABASE_URL`**: `prisma/schema.prisma` sengaja membaca pembolehubah ini dan bukannya `DATABASE_URL`, kerana sesetengah perumah menyuntik `DATABASE_URL` lama ke dalam persekitaran proses — dan pembolehubah proses *sentiasa menewaskan* fail `.env`. Pada Vercel, set `SUPABASE_DATABASE_URL` (bukan `DATABASE_URL`).
2. **Pooler region `aws-1-ap-northeast-1`**: endpoint terus (`db.*.supabase.co`) kini IPv6 sahaja dan tidak boleh dihubungi dari rangkaian IPv4. Region pooler dijumpai melalui probe penyewa (`scripts/find-pooler-region.ts`) — alamat pelayan yang dipulangkan sepadan dengan alamat IPv6 projek, membuktikan routing yang betul. Kesilapan region menghasilkan ralat mengelirukan `P1001: Can't reach database server` daripada Prisma.
3. **Session pooler (5432)** dipilih untuk migrasi dan pelayan berumur panjang (Prisma mengesyorkannya berbanding transaction pooler untuk operasi skema); **transaction pooler (6543 + `pgbouncer=true`)** disimpan untuk runtime serverless Vercel.
4. `DATABASE_URL` turut ditetapkan kepada rentetan yang sama dalam `.env` untuk keserasian alat generik.

## 2. Apa yang telah dilaksanakan

| Komponen | Fail | Status |
| --- | --- | --- |
| Klien Supabase (browser/server/admin + Storage + probe) | `src/lib/supabase.ts` | Aktif |
| Status endpoint (admin-only) | `src/app/api/system/supabase-status/route.ts` | Aktif |
| Tab Supabase (halaman Pentadbiran) | `src/app/(app)/admin/page.tsx` | Aktif — badge DB hijau |
| Migrasi skema (27 jadual, constraint, index) | `bun run db:push` ke Supabase | **Selesai** — 8.6s, tiada ralat |
| Data rujukan/demo (PRD v3.0: DJA30132 3-sesi, DJM20063, peranan, tetapan, templat 3.2) | `bun scripts/seed.ts` | **Selesai** — 10 profil, 7 penawaran, 756 markah, 3 laporan |
| Migrasi DDL SQL (rujukan / laluan alternatif) | `supabase/migrations/0001_init.sql` | Sedia |
| Konfigurasi CLI | `supabase/config.toml` | Sedia |
| Ujian keselamatan boot (`db:push` gagal tidak mematikan boot) | `package.json` | Aktif |
| Pengesahan pelayar (log masuk, papan pemuka, senarai penawaran, tab Supabase) | — | **Lulus** |

## 3. Rollback ke SQLite tempatan (jika diperlukan)

```bash
cp prisma/schema.prisma prisma/schema.postgres.prisma
cp prisma/schema.sqlite.bak.prisma prisma/schema.prisma
# dalam .env: komen SUPABASE_DATABASE_URL & DATABASE_URL postgres, uncomment baris file:
bun run db:generate && bun run db:push && bun scripts/seed.ts
```

Fail `db/custom.db` masih menyimpan keadaan sandbox sebelum pertukaran.

## 4. Pengaktifan Storan bukti Supabase (FR-PCQI-05) — tinggal 2 langkah

1. Kunci secret: **Dashboard → Settings → API Keys → `sb_secret_...`** (Reveal). Dalam `.env`: `SUPABASE_SECRET_KEY=sb_secret_...`
2. Wujudkan bucket: jalankan blok terakhir `0001_init.sql` (bahagian Storage) dalam SQL Editor — bucket `evidence` peribadi, had 5MB, MIME PDF/JPG/PNG/DOCX.

Selepas itu, muat naik bukti disimpan ke Supabase Storage (`supabase://evidence/<yyyy>/<mm>/<id>.<ext>`) dan badge Storan pada tab Supabase bertukar hijau. Tiada polisi anon diwujudkan: semua akses melalui API sistem (matriks kebenaran), kunci secret hanya di pelayan.

## 5. Persediaan CLI

```bash
npm i -g supabase        # atau: brew install supabase/tap/supabase
supabase login           # buka pelayar, tampal token akses
supabase init            # sudah siap — supabase/config.toml wujud
supabase link --project-ref pqvdalbvqkkvbjsddisr
supabase db push         # pilihan: gunakan migrasi SQL ke cloud (skema sudah di-push via Prisma)
supabase gen types typescript --linked > src/types/supabase.ts
```

Nota: `supabase start` (stack tempatan) tidak diperlukan; sistem menyasar instance Supabase cloud secara langsung.

## 6. Senarai semak penghantaran (Vercel)

- [x] Skema 27 jadual di Supabase (via Prisma db push)
- [x] Data rujukan JKM di-seed
- [ ] Env Vercel: `SUPABASE_DATABASE_URL` = nilai `SUPABASE_POOLER_URL` (port 6543, `pgbouncer=true`), `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SECRET_KEY` (selepas dapat kunci)
- [ ] Bucket `evidence` peribadi + kunci secret ditetapkan
- [ ] RLS diaktifkan pada jadual public (klien publishable tidak boleh baca terus; akses hanya melalui API sistem)
- [ ] Backup harian Supabase / Point-in-time recovery (pelan Pro)
